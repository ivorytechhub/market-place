<?php
/**
 * Kalerwe Market - User Profile
 * 
 * Allows users to view and update their own profile information
 * and change their password.
 */

require_once __DIR__ . '/includes/header.php';
auth()->requireAuth();

$pageTitle = 'My Profile';
$db = getDB();
$userId = auth()->getUserId();

$user = $db->fetchOne("SELECT * FROM users WHERE id = ?", [$userId]);
$vendor = $db->fetchOne("SELECT * FROM vendors WHERE user_id = ?", [$userId]);

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        $errors[] = 'Invalid form submission.';
    } else {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'update_profile') {
            $fullName = cleanInput($_POST['full_name'] ?? '');
            $email = cleanInput($_POST['email'] ?? '');
            $phone = cleanInput($_POST['phone'] ?? '');
            
            if (empty($fullName)) {
                $errors[] = 'Full name is required.';
            } else {
                $db->execute(
                    "UPDATE users SET full_name = ?, email = ?, phone = ?, updated_at = NOW() WHERE id = ?",
                    [$fullName, $email, $phone, $userId]
                );
                setFlash('success', 'Profile updated successfully.');
                redirect(currentUrl());
            }
        }
        
        if ($action === 'change_password') {
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
                $errors[] = 'All password fields are required.';
            } elseif ($newPassword !== $confirmPassword) {
                $errors[] = 'New passwords do not match.';
            } elseif (strlen($newPassword) < 6) {
                $errors[] = 'New password must be at least 6 characters.';
            } else {
                $result = auth()->changePassword($userId, $currentPassword, $newPassword);
                if ($result['success']) {
                    setFlash('success', 'Password changed successfully.');
                    redirect(currentUrl());
                } else {
                    $errors[] = $result['message'];
                }
            }
        }
    }
}
?>

<div class="max-w-3xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="dashboard.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">My Profile</h2>
            <p class="text-sm text-gray-500">Manage your account information</p>
        </div>
    </div>
    
    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm"><?php foreach ($errors as $e): ?><li><?php echo sanitize($e); ?></li><?php endforeach; ?></ul>
    </div>
    <?php endif; ?>
    
    <!-- User Info Card -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
        <div class="flex items-center space-x-4 mb-6">
            <div class="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                <span class="text-2xl font-bold text-emerald-700"><?php echo strtoupper(substr($user['full_name'], 0, 2)); ?></span>
            </div>
            <div>
                <h3 class="text-lg font-semibold text-gray-800"><?php echo sanitize($user['full_name']); ?></h3>
                <p class="text-sm text-gray-500"><?php echo ucfirst($user['role']); ?></p>
                <p class="text-xs text-gray-400">Member since <?php echo formatDate($user['created_at'], 'M Y'); ?></p>
            </div>
        </div>
        
        <?php if ($vendor): ?>
        <div class="border-t border-gray-100 pt-4 grid grid-cols-2 gap-4">
            <div>
                <p class="text-xs text-gray-500">Business</p>
                <p class="text-sm font-medium text-gray-800"><?php echo sanitize($vendor['business_name']); ?></p>
            </div>
            <div>
                <p class="text-xs text-gray-500">Stall</p>
                <p class="text-sm font-medium text-gray-800"><?php echo sanitize($vendor['stall_number']); ?></p>
            </div>
            <div>
                <p class="text-xs text-gray-500">Vendor Code</p>
                <p class="text-sm font-medium text-gray-800"><?php echo sanitize($vendor['vendor_code']); ?></p>
            </div>
            <div>
                <p class="text-xs text-gray-500">Status</p>
                <p class="text-sm font-medium"><?php echo statusBadge($vendor['status']); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Edit Profile -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Edit Profile</h3>
        <form method="POST" action="" class="space-y-4">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="update_profile">
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
                    <input type="text" value="<?php echo sanitize($user['username']); ?>" disabled class="w-full px-4 py-2.5 bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                    <input type="text" name="full_name" value="<?php echo sanitize($user['full_name']); ?>" required class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" value="<?php echo sanitize($user['email'] ?? ''); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="tel" name="phone" value="<?php echo sanitize($user['phone'] ?? ''); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
            </div>
            <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">Update Profile</button>
        </form>
    </div>
    
    <!-- Change Password -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Change Password</h3>
        <form method="POST" action="" class="space-y-4">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="change_password">
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                    <input type="password" name="current_password" required class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">New Password (min 6 chars)</label>
                    <input type="password" name="new_password" required class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                    <input type="password" name="confirm_password" required class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
            </div>
            <button type="submit" class="px-6 py-2.5 bg-gray-800 hover:bg-gray-900 text-white rounded-lg text-sm font-medium transition touch-target">Change Password</button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
