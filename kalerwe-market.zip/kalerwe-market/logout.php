<?php
/**
 * Kalerwe Market - Logout
 * 
 * Securely logs out the user and redirects to login page.
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

// Perform logout
auth()->logout();

// Set flash message
setFlash('info', 'You have been logged out successfully.');

// Redirect to login
redirect(APP_URL . '/login.php');
