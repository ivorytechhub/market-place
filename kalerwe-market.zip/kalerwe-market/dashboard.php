<?php
/**
 * Kalerwe Market - Dashboard
 * 
 * Main dashboard with KPI cards, sales charts, recent transactions,
 * low stock alerts, and quick action buttons.
 */

require_once __DIR__ . '/includes/header.php';

$pageTitle = 'Dashboard';

$db = getDB();
$userRole = auth()->getRole();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

// Base WHERE clause for vendor-specific filtering
$vendorFilter = $isAdmin ? '' : ($vendorId ? "WHERE vendor_id = {$vendorId}" : 'WHERE 1=0');
$vendorAnd = $isAdmin ? '' : ($vendorId ? "AND vendor_id = {$vendorId}" : 'AND 1=0');

// ============================================================
// KPI CALCULATIONS
// ============================================================

// Total Sales Today
$todaySales = $db->fetchOne(
    "SELECT COALESCE(SUM(net_amount), 0) as total, COUNT(*) as count 
     FROM sales_transactions 
     WHERE DATE(created_at) = CURDATE() {$vendorAnd} AND status = 'completed'"
);

// Total Sales This Month
$monthSales = $db->fetchOne(
    "SELECT COALESCE(SUM(net_amount), 0) as total, COUNT(*) as count 
     FROM sales_transactions 
     WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) {$vendorAnd} AND status = 'completed'"
);

// Total Products
$productCount = $db->count('products', $isAdmin ? 'is_active = 1' : 'vendor_id = ? AND is_active = 1', $isAdmin ? [] : [$vendorId]);

// Low Stock Items
$lowStockWhere = $isAdmin ? 'quantity <= min_stock_level AND is_active = 1' : 'vendor_id = ? AND quantity <= min_stock_level AND is_active = 1';
$lowStockCount = $db->count('products', $lowStockWhere, $isAdmin ? [] : [$vendorId]);

// Pending Orders
$pendingOrders = $db->count('customer_orders', $isAdmin ? "status = 'pending'" : "vendor_id = ? AND status = 'pending'", $isAdmin ? [] : [$vendorId]);

// Total Vendors (admin only)
$vendorCount = $isAdmin ? $db->count('vendors', "status = 'active'") : 0;

// Monthly Contributions (admin)
$monthContributions = $isAdmin ? ($db->fetchOne(
    "SELECT COALESCE(SUM(amount), 0) as total FROM member_contributions WHERE MONTH(contribution_date) = MONTH(CURDATE()) AND YEAR(contribution_date) = YEAR(CURDATE()) AND status = 'confirmed'"
)['total'] ?? 0) : 0;

// Total Expenses This Month
$monthExpenses = $db->fetchOne(
    "SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE MONTH(expense_date) = MONTH(CURDATE()) AND YEAR(expense_date) = YEAR(CURDATE()) {$vendorAnd}"
)['total'] ?? 0;

// ============================================================
// CHART DATA - Last 7 Days Sales
// ============================================================
$salesChartData = $db->fetchAll(
    "SELECT DATE(created_at) as date, COALESCE(SUM(net_amount), 0) as total, COUNT(*) as transactions
     FROM sales_transactions 
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) {$vendorAnd} AND status = 'completed'
     GROUP BY DATE(created_at)
     ORDER BY date ASC"
);

// Fill in missing dates
$chartLabels = [];
$chartValues = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $chartLabels[] = date('D', strtotime($date));
    $found = false;
    foreach ($salesChartData as $row) {
        if ($row['date'] === $date) {
            $chartValues[] = (float)$row['total'];
            $found = true;
            break;
        }
    }
    if (!$found) {
        $chartValues[] = 0;
    }
}

// ============================================================
// CHART DATA - Sales by Category
// ============================================================
$categoryChartData = $db->fetchAll(
    "SELECT c.name as category, COALESCE(SUM(ti.total_amount), 0) as total
     FROM transaction_items ti
     JOIN sales_transactions st ON ti.transaction_id = st.id
     JOIN products p ON ti.product_id = p.id
     JOIN categories c ON p.category_id = c.id
     WHERE st.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND st.status = 'completed'
     " . ($isAdmin ? "" : "AND st.vendor_id = {$vendorId}") . "
     GROUP BY c.id, c.name
     ORDER BY total DESC
     LIMIT 5"
);

// ============================================================
// RECENT TRANSACTIONS
// ============================================================
$recentTransactions = $db->fetchAll(
    "SELECT st.*, v.business_name, v.stall_number
     FROM sales_transactions st
     LEFT JOIN vendors v ON st.vendor_id = v.id
     WHERE 1=1 {$vendorAnd}
     ORDER BY st.created_at DESC
     LIMIT 10"
);

// ============================================================
// LOW STOCK ALERTS
// ============================================================
$lowStockItems = $db->fetchAll(
    "SELECT p.*, v.business_name, c.name as category_name
     FROM products p
     LEFT JOIN vendors v ON p.vendor_id = v.id
     LEFT JOIN categories c ON p.category_id = c.id
     WHERE " . ($isAdmin ? "p.quantity <= p.min_stock_level" : "p.vendor_id = ? AND p.quantity <= p.min_stock_level") . "
     AND p.is_active = 1
     ORDER BY (p.quantity / p.min_stock_level) ASC
     LIMIT 5",
    $isAdmin ? [] : [$vendorId]
);

// ============================================================
// RECENT ANNOUNCEMENTS
// ============================================================
$recentAnnouncements = $db->fetchAll(
    "SELECT * FROM announcements 
     WHERE is_active = 1 AND (valid_until IS NULL OR valid_until >= CURDATE())
     ORDER BY created_at DESC
     LIMIT 3"
);

// ============================================================
// TOP SELLING PRODUCTS
// ============================================================
$topProducts = $db->fetchAll(
    "SELECT p.name, p.sku, SUM(ti.quantity) as total_qty, SUM(ti.total_amount) as total_revenue
     FROM transaction_items ti
     JOIN products p ON ti.product_id = p.id
     JOIN sales_transactions st ON ti.transaction_id = st.id
     WHERE st.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND st.status = 'completed'
     " . ($isAdmin ? "" : "AND st.vendor_id = {$vendorId}") . "
     GROUP BY p.id, p.name, p.sku
     ORDER BY total_qty DESC
     LIMIT 5"
);
?>

<!-- Chart.js for dashboard charts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<!-- ========== KPI CARDS ========== -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <!-- Today's Sales -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 card-hover">
        <div class="flex items-center justify-between mb-3">
            <div class="p-2 bg-emerald-100 rounded-lg">
                <?php echo icon('dollar-sign', 5, 'text-emerald-600'); ?>
            </div>
            <span class="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">Today</span>
        </div>
        <p class="text-2xl font-bold text-gray-800"><?php echo formatCurrency($todaySales['total'] ?? 0); ?></p>
        <p class="text-xs text-gray-500 mt-1"><?php echo $todaySales['count'] ?? 0; ?> transactions</p>
    </div>
    
    <!-- Monthly Sales -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 card-hover">
        <div class="flex items-center justify-between mb-3">
            <div class="p-2 bg-blue-100 rounded-lg">
                <?php echo icon('trending-up', 5, 'text-blue-600'); ?>
            </div>
            <span class="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">This Month</span>
        </div>
        <p class="text-2xl font-bold text-gray-800"><?php echo formatCurrency($monthSales['total'] ?? 0); ?></p>
        <p class="text-xs text-gray-500 mt-1"><?php echo $monthSales['count'] ?? 0; ?> transactions</p>
    </div>
    
    <!-- Products -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 card-hover">
        <div class="flex items-center justify-between mb-3">
            <div class="p-2 bg-purple-100 rounded-lg">
                <?php echo icon('package', 5, 'text-purple-600'); ?>
            </div>
            <span class="text-xs font-medium text-purple-600 bg-purple-50 px-2 py-1 rounded-full">Inventory</span>
        </div>
        <p class="text-2xl font-bold text-gray-800"><?php echo formatNumber($productCount); ?></p>
        <p class="text-xs text-gray-500 mt-1"><?php echo $lowStockCount; ?> low stock</p>
    </div>
    
    <!-- Pending Orders / Vendors -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 card-hover">
        <div class="flex items-center justify-between mb-3">
            <div class="p-2 bg-orange-100 rounded-lg">
                <?php echo icon($isAdmin ? 'users' : 'clipboard-copy', 5, 'text-orange-600'); ?>
            </div>
            <span class="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded-full">
                <?php echo $isAdmin ? 'Vendors' : 'Pending'; ?>
            </span>
        </div>
        <p class="text-2xl font-bold text-gray-800">
            <?php echo $isAdmin ? formatNumber($vendorCount) : formatNumber($pendingOrders); ?>
        </p>
        <p class="text-xs text-gray-500 mt-1">
            <?php echo $isAdmin ? 'active vendors' : 'pending orders'; ?>
        </p>
    </div>
</div>

<!-- Admin: Contributions & Expenses Row -->
<?php if ($isAdmin): ?>
<div class="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 card-hover">
        <div class="flex items-center justify-between mb-3">
            <div class="p-2 bg-teal-100 rounded-lg">
                <?php echo icon('hand-coins', 5, 'text-teal-600'); ?>
            </div>
            <span class="text-xs font-medium text-teal-600 bg-teal-50 px-2 py-1 rounded-full">Contributions</span>
        </div>
        <p class="text-2xl font-bold text-gray-800"><?php echo formatCurrency($monthContributions); ?></p>
        <p class="text-xs text-gray-500 mt-1">This month</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 card-hover">
        <div class="flex items-center justify-between mb-3">
            <div class="p-2 bg-red-100 rounded-lg">
                <?php echo icon('receipt', 5, 'text-red-600'); ?>
            </div>
            <span class="text-xs font-medium text-red-600 bg-red-50 px-2 py-1 rounded-full">Expenses</span>
        </div>
        <p class="text-2xl font-bold text-gray-800"><?php echo formatCurrency($monthExpenses); ?></p>
        <p class="text-xs text-gray-500 mt-1">This month</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 card-hover">
        <div class="flex items-center justify-between mb-3">
            <div class="p-2 bg-green-100 rounded-lg">
                <?php echo icon('banknote', 5, 'text-green-600'); ?>
            </div>
            <span class="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">Net</span>
        </div>
        <p class="text-2xl font-bold text-gray-800"><?php echo formatCurrency(($monthSales['total'] ?? 0) - $monthExpenses); ?></p>
        <p class="text-xs text-gray-500 mt-1">Sales minus expenses</p>
    </div>
</div>
<?php endif; ?>

<!-- ========== CHARTS & DATA ROW ========== -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
    
    <!-- Sales Chart (spans 2 columns) -->
    <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-800">Sales Trend (Last 7 Days)</h3>
            <a href="<?php echo APP_URL; ?>/modules/reports/index.php" class="text-sm text-emerald-600 hover:text-emerald-700 font-medium">
                View Reports
            </a>
        </div>
        <div class="h-64">
            <canvas id="salesChart"></canvas>
        </div>
    </div>
    
    <!-- Category Breakdown -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Sales by Category</h3>
        <div class="h-48 mb-4">
            <canvas id="categoryChart"></canvas>
        </div>
        <div class="space-y-2">
            <?php foreach (array_slice($categoryChartData, 0, 5) as $cat): ?>
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-600 truncate max-w-[60%]"><?php echo sanitize($cat['category']); ?></span>
                <span class="font-medium text-gray-800"><?php echo formatCurrency($cat['total']); ?></span>
            </div>
            <?php endforeach; ?>
            <?php if (empty($categoryChartData)): ?>
            <p class="text-sm text-gray-400 text-center py-4">No data available</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ========== SECOND ROW: RECENT TRANSACTIONS & ALERTS ========== -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
    
    <!-- Recent Transactions -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-800">Recent Transactions</h3>
            <a href="<?php echo APP_URL; ?>/modules/sales/index.php" class="text-sm text-emerald-600 hover:text-emerald-700 font-medium">
                View All
            </a>
        </div>
        <div class="table-wrapper">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b border-gray-200">
                        <th class="text-left py-3 px-2 text-gray-500 font-medium">Transaction</th>
                        <?php if ($isAdmin): ?>
                        <th class="text-left py-3 px-2 text-gray-500 font-medium">Vendor</th>
                        <?php endif; ?>
                        <th class="text-right py-3 px-2 text-gray-500 font-medium">Amount</th>
                        <th class="text-center py-3 px-2 text-gray-500 font-medium">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTransactions as $txn): ?>
                    <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                        <td class="py-3 px-2">
                            <p class="font-medium text-gray-800"><?php echo sanitize($txn['transaction_number']); ?></p>
                            <p class="text-xs text-gray-500"><?php echo formatDateTime($txn['created_at']); ?></p>
                        </td>
                        <?php if ($isAdmin): ?>
                        <td class="py-3 px-2">
                            <p class="text-gray-700"><?php echo sanitize($txn['business_name'] ?? 'N/A'); ?></p>
                            <p class="text-xs text-gray-500"><?php echo sanitize($txn['stall_number'] ?? ''); ?></p>
                        </td>
                        <?php endif; ?>
                        <td class="py-3 px-2 text-right font-medium text-gray-800">
                            <?php echo formatCurrency($txn['net_amount']); ?>
                        </td>
                        <td class="py-3 px-2 text-center">
                            <?php echo statusBadge($txn['status']); ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($recentTransactions)): ?>
                    <tr>
                        <td colspan="<?php echo $isAdmin ? 4 : 3; ?>" class="py-8 text-center text-gray-400">
                            No transactions found
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Low Stock Alerts -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-800">Low Stock Alerts</h3>
            <a href="<?php echo APP_URL; ?>/modules/inventory/index.php?filter=low_stock" class="text-sm text-red-600 hover:text-red-700 font-medium">
                View All
            </a>
        </div>
        <div class="space-y-3">
            <?php foreach ($lowStockItems as $item): 
                $stockPercent = min(100, ($item['quantity'] / max(1, $item['min_stock_level'])) * 100);
                $barColor = $stockPercent <= 25 ? 'bg-red-500' : ($stockPercent <= 50 ? 'bg-yellow-500' : 'bg-emerald-500');
            ?>
            <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-800 truncate"><?php echo sanitize($item['name']); ?></p>
                    <p class="text-xs text-gray-500"><?php echo sanitize($item['category_name'] ?? 'Uncategorized'); ?> 
                        <?php if ($isAdmin): ?>| <?php echo sanitize($item['business_name'] ?? ''); ?><?php endif; ?></p>
                    <div class="mt-2 w-full bg-gray-200 rounded-full h-2">
                        <div class="<?php echo $barColor; ?> h-2 rounded-full transition-all" style="width: <?php echo $stockPercent; ?>%"></div>
                    </div>
                </div>
                <div class="text-right flex-shrink-0">
                    <p class="text-sm font-bold text-gray-800"><?php echo $item['quantity']; ?></p>
                    <p class="text-xs text-gray-500">/ <?php echo $item['min_stock_level']; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (empty($lowStockItems)): ?>
            <div class="py-8 text-center text-gray-400">
                <?php echo icon('check-circle', 8, 'mx-auto mb-2 text-emerald-400'); ?>
                <p>All stock levels are healthy!</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ========== THIRD ROW: TOP PRODUCTS & ANNOUNCEMENTS ========== -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    
    <!-- Top Selling Products -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Top Selling Products (30 Days)</h3>
        <div class="space-y-3">
            <?php foreach ($topProducts as $idx => $product): 
                $rankColors = ['text-yellow-500', 'text-gray-400', 'text-amber-600'];
                $rankColor = $idx < 3 ? $rankColors[$idx] : 'text-gray-300';
            ?>
            <div class="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg transition">
                <span class="text-lg font-bold <?php echo $rankColor; ?> w-6 text-center"><?php echo $idx + 1; ?></span>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-800 truncate"><?php echo sanitize($product['name']); ?></p>
                    <p class="text-xs text-gray-500"><?php echo sanitize($product['sku']); ?></p>
                </div>
                <div class="text-right flex-shrink-0">
                    <p class="text-sm font-medium text-gray-800"><?php echo $product['total_qty']; ?> sold</p>
                    <p class="text-xs text-gray-500"><?php echo formatCurrency($product['total_revenue']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (empty($topProducts)): ?>
            <p class="text-sm text-gray-400 text-center py-4">No sales data available</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Announcements -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-800">Announcements</h3>
            <a href="<?php echo APP_URL; ?>/modules/announcements/index.php" class="text-sm text-emerald-600 hover:text-emerald-700 font-medium">
                View All
            </a>
        </div>
        <div class="space-y-3">
            <?php foreach ($recentAnnouncements as $ann): 
                $priorityColors = [
                    'low' => 'border-l-green-400 bg-green-50',
                    'normal' => 'border-l-blue-400 bg-blue-50',
                    'high' => 'border-l-orange-400 bg-orange-50',
                    'urgent' => 'border-l-red-400 bg-red-50'
                ];
                $priorityColor = $priorityColors[$ann['priority']] ?? $priorityColors['normal'];
            ?>
            <div class="border-l-4 <?php echo $priorityColor; ?> p-3 rounded-r-lg">
                <div class="flex items-center justify-between mb-1">
                    <h4 class="text-sm font-medium text-gray-800"><?php echo sanitize($ann['title']); ?></h4>
                    <?php echo statusBadge($ann['priority']); ?>
                </div>
                <p class="text-xs text-gray-600 line-clamp-2"><?php echo sanitize($ann['content']); ?></p>
                <p class="text-xs text-gray-400 mt-1"><?php echo formatDate($ann['created_at']); ?></p>
            </div>
            <?php endforeach; ?>
            <?php if (empty($recentAnnouncements)): ?>
            <p class="text-sm text-gray-400 text-center py-4">No announcements</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ========== CHART SCRIPTS ========== -->
<script>
// Sales Line Chart
const salesCtx = document.getElementById('salesChart').getContext('2d');
new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($chartLabels); ?>,
        datasets: [{
            label: 'Sales (<?php echo DEFAULT_CURRENCY_SYMBOL; ?>)',
            data: <?php echo json_encode($chartValues); ?>,
            borderColor: '#059669',
            backgroundColor: 'rgba(5, 150, 105, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointRadius: 4,
            pointBackgroundColor: '#059669',
            pointBorderColor: '#fff',
            pointBorderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { color: '#f3f4f6' },
                ticks: {
                    callback: function(value) {
                        return '<?php echo DEFAULT_CURRENCY_SYMBOL; ?> ' + value.toLocaleString();
                    }
                }
            },
            x: {
                grid: { display: false }
            }
        }
    }
});

// Category Doughnut Chart
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_column($categoryChartData, 'category')); ?>,
        datasets: [{
            data: <?php echo json_encode(array_map('floatval', array_column($categoryChartData, 'total'))); ?>,
            backgroundColor: ['#059669', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false }
        },
        cutout: '70%'
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
