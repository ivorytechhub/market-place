<?php
/**
 * Kalerwe Market - Authentication & Authorization Module
 * 
 * Handles user login/logout, session management, role-based
 * access control, and permission checking.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

class Auth {
    private static $instance = null;
    private $currentUser = null;
    private $currentVendor = null;
    private $db;
    
    /**
     * Private constructor - singleton
     */
    private function __construct() {
        $this->db = getDB();
        $this->loadUserFromSession();
    }
    
    /**
     * Get singleton instance
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Load user from session
     */
    private function loadUserFromSession() {
        if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
            $user = $this->db->fetchOne(
                "SELECT * FROM users WHERE id = ? AND is_active = 1",
                [$_SESSION['user_id']]
            );
            
            if ($user) {
                $this->currentUser = $user;
                
                // Load vendor profile if user is a vendor
                if ($user['role'] === 'vendor') {
                    $this->currentVendor = $this->db->fetchOne(
                        "SELECT * FROM vendors WHERE user_id = ?",
                        [$user['id']]
                    );
                }
            } else {
                // User no longer exists or inactive - clear session
                $this->logout();
            }
        }
    }
    
    /**
     * Authenticate user with username and password
     */
    public function login($username, $password) {
        // Check for brute force
        if ($this->isLockedOut()) {
            return ['success' => false, 'message' => 'Too many failed attempts. Please try again in 15 minutes.'];
        }
        
        // Find user by username
        $user = $this->db->fetchOne(
            "SELECT * FROM users WHERE username = ?",
            [$username]
        );
        
        if (!$user) {
            $this->recordFailedAttempt();
            return ['success' => false, 'message' => 'Invalid username or password.'];
        }
        
        // Check if user is active
        if (!$user['is_active']) {
            return ['success' => false, 'message' => 'Your account has been deactivated. Contact the administrator.'];
        }
        
        // Verify password
        if (!verifyPassword($password, $user['password_hash'])) {
            $this->recordFailedAttempt();
            return ['success' => false, 'message' => 'Invalid username or password.'];
        }
        
        // Successful login - clear failed attempts
        $this->clearFailedAttempts();
        
        // Update last login
        $this->db->execute(
            "UPDATE users SET last_login = NOW() WHERE id = ?",
            [$user['id']]
        );
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['login_time'] = time();
        
        // Load user data
        $this->currentUser = $user;
        
        // Load vendor profile if applicable
        if ($user['role'] === 'vendor') {
            $this->currentVendor = $this->db->fetchOne(
                "SELECT * FROM vendors WHERE user_id = ?",
                [$user['id']]
            );
        }
        
        // Log activity
        $this->logActivity('login', 'auth', 'User logged in successfully');
        
        return ['success' => true, 'user' => $user];
    }
    
    /**
     * Logout user
     */
    public function logout() {
        if ($this->currentUser) {
            $this->logActivity('logout', 'auth', 'User logged out');
        }
        
        // Clear session
        session_unset();
        session_destroy();
        
        // Reset instance
        $this->currentUser = null;
        $this->currentVendor = null;
        self::$instance = null;
        
        return true;
    }
    
    /**
     * Check if user is logged in
     */
    public function isLoggedIn() {
        return $this->currentUser !== null;
    }
    
    /**
     * Check if session is valid (not expired)
     */
    public function isSessionValid() {
        if (!$this->isLoggedIn()) return false;
        
        // Check session timeout
        if (isset($_SESSION['login_time'])) {
            $elapsed = time() - $_SESSION['login_time'];
            if ($elapsed > SESSION_TIMEOUT) {
                $this->logout();
                return false;
            }
            // Refresh session time on activity
            $_SESSION['login_time'] = time();
        }
        
        return true;
    }
    
    /**
     * Get current user
     */
    public function getUser() {
        return $this->currentUser;
    }
    
    /**
     * Get current vendor profile
     */
    public function getVendor() {
        return $this->currentVendor;
    }
    
    /**
     * Get user role
     */
    public function getRole() {
        return $this->currentUser ? $this->currentUser['role'] : null;
    }
    
    /**
     * Get user ID
     */
    public function getUserId() {
        return $this->currentUser ? $this->currentUser['id'] : null;
    }
    
    /**
     * Get vendor ID
     */
    public function getVendorId() {
        return $this->currentVendor ? $this->currentVendor['id'] : null;
    }
    
    /**
     * Check if user has specific role
     */
    public function hasRole($role) {
        return $this->currentUser && $this->currentUser['role'] === $role;
    }
    
    /**
     * Check if user has any of the given roles
     */
    public function hasAnyRole($roles) {
        if (!$this->currentUser) return false;
        return in_array($this->currentUser['role'], (array)$roles);
    }
    
    /**
     * Check if user is admin
     */
    public function isAdmin() {
        return $this->hasRole('admin');
    }
    
    /**
     * Check permission
     */
    public function hasPermission($permission) {
        global $USER_ROLES;
        
        if (!$this->currentUser) return false;
        
        $role = $this->currentUser['role'];
        
        // Admin has all permissions
        if ($role === 'admin') return true;
        
        // Check role permissions
        if (isset($USER_ROLES[$role]['permissions'])) {
            $permissions = $USER_ROLES[$role]['permissions'];
            // Wildcard permission
            if (in_array('*', $permissions)) return true;
            // Exact permission
            if (in_array($permission, $permissions)) return true;
            // Wildcard module permission (e.g., 'product.*' matches 'product.view')
            foreach ($permissions as $p) {
                if (strpos($p, '.*') !== false) {
                    $module = str_replace('.*', '', $p);
                    if (strpos($permission, $module . '.') === 0) return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Require authentication - redirect to login if not logged in
     */
    public function requireAuth() {
        if (!$this->isSessionValid()) {
            setFlash('error', 'Please log in to access this page.');
            redirect(APP_URL . '/login.php');
        }
    }
    
    /**
     * Require specific role
     */
    public function requireRole($role) {
        $this->requireAuth();
        if (!$this->hasRole($role)) {
            setFlash('error', 'You do not have permission to access this page.');
            redirect(APP_URL . '/dashboard.php');
        }
    }
    
    /**
     * Require any of specified roles
     */
    public function requireAnyRole($roles) {
        $this->requireAuth();
        if (!$this->hasAnyRole($roles)) {
            setFlash('error', 'You do not have permission to access this page.');
            redirect(APP_URL . '/dashboard.php');
        }
    }
    
    /**
     * Require specific permission
     */
    public function requirePermission($permission) {
        $this->requireAuth();
        if (!$this->hasPermission($permission)) {
            setFlash('error', 'You do not have permission to perform this action.');
            redirect(APP_URL . '/dashboard.php');
        }
    }
    
    /**
     * Check if user is locked out (brute force protection)
     */
    private function isLockedOut() {
        $key = 'login_attempts_' . getClientIP();
        $attempts = $_SESSION[$key]['count'] ?? 0;
        $lastAttempt = $_SESSION[$key]['time'] ?? 0;
        
        if ($attempts >= MAX_LOGIN_ATTEMPTS) {
            if (time() - $lastAttempt < LOGIN_LOCKOUT_TIME) {
                return true;
            }
            // Lockout period expired, reset
            $this->clearFailedAttempts();
        }
        
        return false;
    }
    
    /**
     * Record failed login attempt
     */
    private function recordFailedAttempt() {
        $key = 'login_attempts_' . getClientIP();
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['count' => 0, 'time' => time()];
        }
        $_SESSION[$key]['count']++;
        $_SESSION[$key]['time'] = time();
    }
    
    /**
     * Clear failed attempts
     */
    private function clearFailedAttempts() {
        $key = 'login_attempts_' . getClientIP();
        unset($_SESSION[$key]);
    }
    
    /**
     * Log activity
     */
    public function logActivity($action, $module, $description = '') {
        if (!$this->db) return;
        
        $userId = $this->currentUser ? $this->currentUser['id'] : null;
        $ip = getClientIP();
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $this->db->execute(
            "INSERT INTO activity_logs (user_id, action, module, description, ip_address, user_agent, created_at) 
             VALUES (?, ?, ?, ?, ?, ?, NOW())",
            [$userId, $action, $module, $description, $ip, $userAgent]
        );
    }
    
    /**
     * Create new user (admin function)
     */
    public function createUser($data) {
        // Check if username exists
        if ($this->db->exists('users', 'username = ?', [$data['username']])) {
            return ['success' => false, 'message' => 'Username already exists.'];
        }
        
        // Check if email exists (if provided)
        if (!empty($data['email']) && $this->db->exists('users', 'email = ?', [$data['email']])) {
            return ['success' => false, 'message' => 'Email already in use.'];
        }
        
        // Hash password
        $passwordHash = hashPassword($data['password']);
        
        // Insert user
        $userId = $this->db->insert(
            "INSERT INTO users (username, password_hash, full_name, email, phone, role, is_active, created_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW())",
            [
                $data['username'],
                $passwordHash,
                $data['full_name'],
                $data['email'] ?? null,
                $data['phone'] ?? null,
                $data['role'] ?? 'vendor',
                isset($data['is_active']) ? 1 : 0
            ]
        );
        
        if ($userId) {
            $this->logActivity('create', 'users', "Created user: {$data['username']}");
            return ['success' => true, 'user_id' => $userId, 'message' => 'User created successfully.'];
        }
        
        return ['success' => false, 'message' => 'Failed to create user.'];
    }
    
    /**
     * Change password
     */
    public function changePassword($userId, $currentPassword, $newPassword) {
        $user = $this->db->fetchOne("SELECT * FROM users WHERE id = ?", [$userId]);
        
        if (!$user || !verifyPassword($currentPassword, $user['password_hash'])) {
            return ['success' => false, 'message' => 'Current password is incorrect.'];
        }
        
        $newHash = hashPassword($newPassword);
        $result = $this->db->execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            [$newHash, $userId]
        );
        
        if ($result !== false) {
            $this->logActivity('password_change', 'auth', "Password changed for user ID: {$userId}");
            return ['success' => true, 'message' => 'Password changed successfully.'];
        }
        
        return ['success' => false, 'message' => 'Failed to change password.'];
    }
}

/**
 * Helper: Get Auth instance
 */
function auth() {
    return Auth::getInstance();
}
