<?php
/**
 * Kalerwe Market Vendors' Association - Configuration File
 * Location: Gayaza Road, Kampala, Uganda
 * 
 * This file contains all system configuration settings.
 * Modify these values for your deployment environment.
 */

// Prevent direct access
if (!defined('KALERWE_APP')) {
    define('KALERWE_APP', true);
}

// ============================================================
// DATABASE CONFIGURATION
// ============================================================
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'kalerwe_market');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

// ============================================================
// APPLICATION SETTINGS
// ============================================================
define('APP_NAME', 'Kalerwe Market Vendors Association');
define('APP_SHORT_NAME', 'KMVA');
define('APP_VERSION', '1.0.0');
define('APP_URL', getenv('APP_URL') ?: 'http://localhost/kalerwe-market');
define('APP_ENV', getenv('APP_ENV') ?: 'development'); // development | production

// ============================================================
// PATH CONFIGURATION
// ============================================================
define('BASE_PATH', dirname(__DIR__));
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('MODULES_PATH', BASE_PATH . '/modules');
define('ASSETS_PATH', BASE_PATH . '/assets');
define('UPLOADS_PATH', BASE_PATH . '/uploads');
define('RECEIPTS_PATH', UPLOADS_PATH . '/receipts');
define('DOCUMENTS_PATH', UPLOADS_PATH . '/documents');

// URL paths (for web references)
define('ASSETS_URL', APP_URL . '/assets');
define('UPLOADS_URL', APP_URL . '/uploads');

// ============================================================
// SECURITY SETTINGS
// ============================================================
define('SESSION_NAME', 'kalerwe_session');
define('SESSION_TIMEOUT', 1800); // 30 minutes in seconds
define('COOKIE_LIFETIME', 86400); // 24 hours
define('CSRF_TOKEN_NAME', 'kalerwe_csrf_token');
define('PASSWORD_MIN_LENGTH', 6);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes

// ============================================================
// PAGINATION & DISPLAY
// ============================================================
define('ITEMS_PER_PAGE', 10);
define('MAX_FILE_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_FILE_TYPES', ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png']);

// ============================================================
// FINANCIAL SETTINGS
// ============================================================
define('DEFAULT_TAX_RATE', 18.0); // Uganda VAT rate
define('DEFAULT_CURRENCY', 'UGX');
define('DEFAULT_CURRENCY_SYMBOL', 'UGX');
define('NUMBER_FORMAT_DECIMALS', 0); // UGX typically has no decimals

// ============================================================
// DATE/TIME SETTINGS
// ============================================================
define('DEFAULT_TIMEZONE', 'Africa/Kampala');
define('DATE_FORMAT', 'd/m/Y');
define('DATETIME_FORMAT', 'd/m/Y H:i');
define('TIME_FORMAT', 'H:i');

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// ============================================================
// ERROR HANDLING
// ============================================================
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// ============================================================
// START SESSION
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_lifetime', COOKIE_LIFETIME);
    ini_set('session.gc_maxlifetime', SESSION_TIMEOUT);
    session_name(SESSION_NAME);
    session_start();
}

// ============================================================
// USER ROLES DEFINITION
// ============================================================
$USER_ROLES = [
    'admin' => [
        'label' => 'Administrator',
        'description' => 'Full system access',
        'permissions' => ['*'] // All permissions
    ],
    'vendor' => [
        'label' => 'Vendor',
        'description' => 'Market seller',
        'permissions' => [
            'dashboard.view',
            'vendor.own_profile',
            'vendor.own_edit',
            'product.view_own',
            'product.create',
            'product.edit_own',
            'product.delete_own',
            'sale.create',
            'sale.view_own',
            'inventory.view_own',
            'order.view_own',
            'order.create',
            'payment.view_own',
            'payment.create',
            'report.view_own',
            'contribution.view_own',
            'expense.view_own',
            'expense.create',
            'announcement.view',
            'po.view_assigned',
            'po.create',
            'po.update_status'
        ]
    ],
    'supplier' => [
        'label' => 'Supplier',
        'description' => 'Goods supplier',
        'permissions' => [
            'dashboard.view',
            'po.view_assigned',
            'po.update_status',
            'payment.view_own'
        ]
    ],
    'buyer' => [
        'label' => 'Buyer',
        'description' => 'Customer/Purchaser',
        'permissions' => [
            'dashboard.view',
            'product.view_public',
            'order.create',
            'order.view_own',
            'receipt.view_own'
        ]
    ],
    'cashier' => [
        'label' => 'Cashier',
        'description' => 'Payment processor',
        'permissions' => [
            'dashboard.view',
            'sale.create',
            'sale.view',
            'payment.create',
            'payment.view',
            'receipt.generate',
            'product.view'
        ]
    ]
];

// ============================================================
// MODULES DEFINITION (for navigation)
// ============================================================
$APP_MODULES = [
    'dashboard' => [
        'label' => 'Dashboard',
        'icon' => 'layout-dashboard',
        'route' => '/dashboard.php',
        'roles' => ['admin', 'vendor', 'supplier', 'buyer', 'cashier']
    ],
    'vendors' => [
        'label' => 'Vendors',
        'icon' => 'users',
        'route' => '/modules/vendors/index.php',
        'roles' => ['admin']
    ],
    'products' => [
        'label' => 'Products',
        'icon' => 'package',
        'route' => '/modules/products/index.php',
        'roles' => ['admin', 'vendor', 'cashier']
    ],
    'sales' => [
        'label' => 'Sales',
        'icon' => 'shopping-cart',
        'route' => '/modules/sales/index.php',
        'roles' => ['admin', 'vendor', 'cashier']
    ],
    'inventory' => [
        'label' => 'Inventory',
        'icon' => 'warehouse',
        'route' => '/modules/inventory/index.php',
        'roles' => ['admin', 'vendor']
    ],
    'purchases' => [
        'label' => 'Purchases',
        'icon' => 'clipboard-list',
        'route' => '/modules/purchases/index.php',
        'roles' => ['admin', 'vendor']
    ],
    'orders' => [
        'label' => 'Orders',
        'icon' => 'clipboard-copy',
        'route' => '/modules/orders/index.php',
        'roles' => ['admin', 'vendor', 'buyer']
    ],
    'payments' => [
        'label' => 'Payments',
        'icon' => 'banknote',
        'route' => '/modules/payments/index.php',
        'roles' => ['admin', 'vendor', 'cashier']
    ],
    'expenses' => [
        'label' => 'Expenses',
        'icon' => 'receipt',
        'route' => '/modules/expenses/index.php',
        'roles' => ['admin', 'vendor']
    ],
    'contributions' => [
        'label' => 'Contributions',
        'icon' => 'hand-coins',
        'route' => '/modules/contributions/index.php',
        'roles' => ['admin']
    ],
    'reports' => [
        'label' => 'Reports',
        'icon' => 'bar-chart-3',
        'route' => '/modules/reports/index.php',
        'roles' => ['admin', 'vendor']
    ],
    'announcements' => [
        'label' => 'Announcements',
        'icon' => 'megaphone',
        'route' => '/modules/announcements/index.php',
        'roles' => ['admin', 'vendor', 'supplier', 'buyer', 'cashier']
    ],
    'settings' => [
        'label' => 'Settings',
        'icon' => 'settings',
        'route' => '/modules/settings/index.php',
        'roles' => ['admin']
    ]
];
