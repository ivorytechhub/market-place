<?php
/**
 * Kalerwe Market - Database Connection & Query Handler
 * 
 * Provides secure database connectivity using PDO with
 * prepared statements for all queries to prevent SQL injection.
 */

require_once __DIR__ . '/config.php';

class Database {
    private static $instance = null;
    private $pdo;
    private $lastError = null;
    
    /**
     * Private constructor - singleton pattern
     */
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            if (APP_ENV === 'development') {
                die("Database Connection Failed: " . $e->getMessage());
            } else {
                die("System temporarily unavailable. Please try again later.");
            }
        }
    }
    
    /**
     * Get singleton instance
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Get PDO connection
     */
    public function getConnection() {
        return $this->pdo;
    }
    
    /**
     * Get last error message
     */
    public function getLastError() {
        return $this->lastError;
    }
    
    /**
     * Execute a SELECT query and return all results
     */
    public function fetchAll($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log("fetchAll Error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Execute a SELECT query and return single row
     */
    public function fetchOne($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch();
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log("fetchOne Error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Execute INSERT query and return last insert ID
     */
    public function insert($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $this->pdo->lastInsertId();
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log("Insert Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Execute UPDATE/DELETE query and return affected rows
     */
    public function execute($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log("Execute Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Begin transaction
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }
    
    /**
     * Commit transaction
     */
    public function commit() {
        return $this->pdo->commit();
    }
    
    /**
     * Rollback transaction
     */
    public function rollback() {
        return $this->pdo->rollBack();
    }
    
    /**
     * Check if in transaction
     */
    public function inTransaction() {
        return $this->pdo->inTransaction();
    }
    
    /**
     * Get count of records
     */
    public function count($table, $where = '', $params = []) {
        $sql = "SELECT COUNT(*) as count FROM {$table}";
        if ($where) {
            $sql .= " WHERE {$where}";
        }
        $result = $this->fetchOne($sql, $params);
        return $result ? (int)$result['count'] : 0;
    }
    
    /**
     * Check if record exists
     */
    public function exists($table, $where, $params = []) {
        return $this->count($table, $where, $params) > 0;
    }
    
    /**
     * Build paginated query - Enhanced to handle complex queries with subqueries
     */
    public function paginate($sql, $params = [], $page = 1, $perPage = ITEMS_PER_PAGE) {
        $page = max(1, (int)$page);
        $offset = ($page - 1) * $perPage;
        
        // Get total count using a subquery approach that works with complex queries
        $total = 0;
        
        try {
            // Method 1: Wrap the entire query as a subquery for counting
            // This works for ANY SELECT query regardless of complexity
            $countSql = "SELECT COUNT(*) as total FROM (" . $sql . ") as count_subquery";
            
            // Remove ORDER BY from the count query (not needed for counting)
            $countSql = preg_replace('/ORDER BY\s+.*?(?=LIMIT|$)/is', '', $countSql);
            
            // Remove any LIMIT clauses from the count query
            $countSql = preg_replace('/LIMIT\s+\d+\s*(,\s*\d+)?$/i', '', $countSql);
            
            $countResult = $this->fetchOne($countSql, $params);
            $total = $countResult ? (int)$countResult['total'] : 0;
            
        } catch (Exception $e) {
            // Method 2 (Fallback): If subquery approach fails, try regex replacement
            error_log("Count query (subquery) failed: " . $e->getMessage());
            
            try {
                $fallbackSql = preg_replace('/SELECT.*?FROM/i', 'SELECT COUNT(*) as total FROM', $sql, 1);
                $fallbackSql = preg_replace('/ORDER BY\s+.*?(?=LIMIT|$)/is', '', $fallbackSql);
                $fallbackSql = preg_replace('/LIMIT\s+\d+\s*(,\s*\d+)?$/i', '', $fallbackSql);
                
                // If GROUP BY exists, wrap in subquery
                if (stripos($fallbackSql, 'GROUP BY') !== false) {
                    $fallbackSql = "SELECT COUNT(*) as total FROM (" . $fallbackSql . ") as count_subquery";
                }
                
                $countResult = $this->fetchOne($fallbackSql, $params);
                $total = $countResult ? (int)$countResult['total'] : 0;
                
            } catch (Exception $e2) {
                // Method 3 (Last resort): Manual count attempt
                error_log("Fallback count query also failed: " . $e2->getMessage());
                
                // Try to get count by simplifying the query further
                try {
                    $simpleSql = preg_replace('/SELECT.*?FROM/i', 'SELECT COUNT(*) as total FROM', $sql, 1);
                    $simpleSql = preg_replace('/\s+LEFT\s+JOIN.*?(?=WHERE|GROUP BY|ORDER BY|LIMIT|$)/is', '', $simpleSql);
                    $simpleSql = preg_replace('/ORDER BY\s+.*?(?=LIMIT|$)/is', '', $simpleSql);
                    $simpleSql = preg_replace('/LIMIT\s+\d+\s*(,\s*\d+)?$/i', '', $simpleSql);
                    $simpleSql = preg_replace('/GROUP BY\s+.*?(?=ORDER BY|LIMIT|$)/is', '', $simpleSql);
                    
                    $countResult = $this->fetchOne($simpleSql, $params);
                    $total = $countResult ? (int)$countResult['total'] : 0;
                    
                } catch (Exception $e3) {
                    error_log("All count query methods failed: " . $e3->getMessage());
                    $total = 0;
                }
            }
        }
        
        // Add LIMIT and OFFSET to the original query
        $sql .= " LIMIT {$perPage} OFFSET {$offset}";
        $data = $this->fetchAll($sql, $params);
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => $total > 0 ? ceil($total / $perPage) : 1,
            'has_next' => ($page * $perPage) < $total,
            'has_prev' => $page > 1
        ];
    }
}

/**
 * Helper function to get DB instance
 */
function getDB() {
    return Database::getInstance();
}