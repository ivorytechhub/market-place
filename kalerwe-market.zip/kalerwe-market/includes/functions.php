<?php
/**
 * Kalerwe Market - Helper Functions
 * 
 * Common utility functions used throughout the application.
 * Includes formatting, validation, security, and UI helpers.
 */

require_once __DIR__ . '/config.php';

// ============================================================
// SECURITY FUNCTIONS
// ============================================================

/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Validate CSRF token
 */
function validateCSRFToken($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * Get CSRF token field HTML
 */
function csrfField() {
    $token = generateCSRFToken();
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . htmlspecialchars($token) . '">';
}

/**
 * Sanitize input string
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Clean input for database (prevent SQL injection via PDO is primary defense)
 */
function cleanInput($input) {
    if (is_array($input)) {
        return array_map('cleanInput', $input);
    }
    return trim(strip_tags($input));
}

/**
 * Hash password securely
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate secure random string
 */
function generateRandomString($length = 16) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Generate unique code with prefix
 */
function generateCode($prefix, $id = null) {
    if ($id) {
        return $prefix . str_pad($id, 6, '0', STR_PAD_LEFT);
    }
    return $prefix . date('Y') . strtoupper(generateRandomString(6));
}

// ============================================================
// FORMATTING FUNCTIONS
// ============================================================

/**
 * Format currency amount
 */
function formatCurrency($amount, $symbol = true) {
    $formatted = number_format((float)$amount, NUMBER_FORMAT_DECIMALS);
    return $symbol ? DEFAULT_CURRENCY_SYMBOL . ' ' . $formatted : $formatted;
}

/**
 * Format date
 */
function formatDate($date, $format = DATE_FORMAT) {
    if (empty($date)) return '-';
    $timestamp = strtotime($date);
    return $timestamp ? date($format, $timestamp) : $date;
}

/**
 * Format datetime
 */
function formatDateTime($datetime, $format = DATETIME_FORMAT) {
    if (empty($datetime)) return '-';
    $timestamp = strtotime($datetime);
    return $timestamp ? date($format, $timestamp) : $datetime;
}

/**
 * Format time
 */
function formatTime($time, $format = TIME_FORMAT) {
    if (empty($time)) return '-';
    $timestamp = strtotime($time);
    return $timestamp ? date($format, $timestamp) : $time;
}

/**
 * Format number
 */
function formatNumber($number, $decimals = 0) {
    return number_format((float)$number, $decimals);
}

/**
 * Format phone number (Uganda format)
 */
function formatPhone($phone) {
    if (empty($phone)) return '-';
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    return $phone;
}

// ============================================================
// VALIDATION FUNCTIONS
// ============================================================

/**
 * Validate required field
 */
function required($value, $fieldName = 'Field') {
    if (empty(trim($value))) {
        return $fieldName . ' is required.';
    }
    return true;
}

/**
 * Validate email
 */
function validEmail($email) {
    if (empty($email)) return true; // Optional
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? true : 'Invalid email address.';
}

/**
 * Validate phone number
 */
function validPhone($phone) {
    if (empty($phone)) return true;
    // Uganda phone: +256XXXXXXXXX or 07XXXXXXXX or 0XXXXXXXX
    $pattern = '/^(\+256|0)[0-9]{9}$/';
    return preg_match($pattern, $phone) ? true : 'Invalid phone number format.';
}

/**
 * Validate numeric value
 */
function validNumber($value, $min = null, $max = null) {
    if (!is_numeric($value)) {
        return 'Must be a valid number.';
    }
    $num = (float)$value;
    if ($min !== null && $num < $min) {
        return "Must be at least {$min}.";
    }
    if ($max !== null && $num > $max) {
        return "Must not exceed {$max}.";
    }
    return true;
}

/**
 * Validate date
 */
function validDate($date, $format = 'Y-m-d') {
    if (empty($date)) return true;
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date ? true : 'Invalid date format.';
}

// ============================================================
// SESSION & FLASH MESSAGES
// ============================================================

/**
 * Set flash message
 */
function setFlash($type, $message) {
    $_SESSION['flash_messages'][] = [
        'type' => $type, // success, error, warning, info
        'message' => $message
    ];
}

/**
 * Get and clear flash messages
 */
function getFlash() {
    $messages = $_SESSION['flash_messages'] ?? [];
    unset($_SESSION['flash_messages']);
    return $messages;
}

/**
 * Check if flash messages exist
 */
function hasFlash() {
    return !empty($_SESSION['flash_messages']);
}

/**
 * Render flash messages HTML
 */
function renderFlash() {
    $messages = getFlash();
    if (empty($messages)) return '';
    
    $html = '';
    foreach ($messages as $msg) {
        $iconClass = [
            'success' => 'check-circle',
            'error' => 'x-circle',
            'warning' => 'alert-triangle',
            'info' => 'info'
        ][$msg['type']] ?? 'info';
        
        $colorClass = [
            'success' => 'bg-green-50 border-green-400 text-green-800',
            'error' => 'bg-red-50 border-red-400 text-red-800',
            'warning' => 'bg-yellow-50 border-yellow-400 text-yellow-800',
            'info' => 'bg-blue-50 border-blue-400 text-blue-800'
        ][$msg['type']] ?? 'bg-blue-50 border-blue-400 text-blue-800';
        
        $html .= '<div class="' . $colorClass . ' border-l-4 p-4 mb-4 rounded-r shadow-sm animate-fade-in" role="alert">';
        $html .= '<div class="flex items-start">';
        $html .= '<svg class="w-5 h-5 mr-2 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">';
        $html .= '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="' . getIconPath($iconClass) . '"/>';
        $html .= '</svg>';
        $html .= '<span class="text-sm font-medium">' . sanitize($msg['message']) . '</span>';
        $html .= '</div></div>';
    }
    return $html;
}

// ============================================================
// ICON PATHS (Lucide-style SVG paths)
// ============================================================
function getIconPath($icon) {
    $paths = [
        'check-circle' => 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
        'x-circle' => 'M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z',
        'alert-triangle' => 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z',
        'info' => 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
        'layout-dashboard' => 'M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z',
        'users' => 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z',
        'package' => 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4',
        'shopping-cart' => 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z',
        'warehouse' => 'M3 21h18M5 21V7l8-4 8 4v14M9 21v-6h6v6',
        'clipboard-list' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01',
        'clipboard-copy' => 'M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3',
        'banknote' => 'M4 10h16M4 14h16M4 6h16a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V8a2 2 0 012-2z',
        'receipt' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2',
        'hand-coins' => 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
        'bar-chart-3' => 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
        'megaphone' => 'M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z',
        'settings' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
        'plus' => 'M12 4v16m8-8H4',
        'edit' => 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z',
        'trash' => 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16',
        'eye' => 'M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z',
        'search' => 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z',
        'filter' => 'M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z',
        'download' => 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4',
        'printer' => 'M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm4-12V4a2 2 0 00-2-2h-2a2 2 0 00-2 2v4',
        'arrow-left' => 'M10 19l-7-7m0 0l7-7m-7 7h18',
        'arrow-right' => 'M14 5l7 7m0 0l-7 7m7-7H3',
        'chevron-left' => 'M15 19l-7-7 7-7',
        'chevron-right' => 'M9 5l7 7-7 7',
        'x' => 'M6 18L18 6M6 6l12 12',
        'menu' => 'M4 6h16M4 12h16M4 18h16',
        'user' => 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
        'log-out' => 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1',
        'trending-up' => 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6',
        'trending-down' => 'M13 17h8m0 0V9m0 8l-8-8-4 4-6-6',
        'dollar-sign' => 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
        'calendar' => 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
        'phone' => 'M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z',
        'mail' => 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z',
        'map-pin' => 'M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z M15 11a3 3 0 11-6 0 3 3 0 016 0z',
        'bell' => 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9',
        'refresh-cw' => 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
        'shield' => 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
        'circle' => 'M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z',
        'check' => 'M5 13l4 4L19 7',
    ];
    
    return $paths[$icon] ?? $paths['circle'];
}

/**
 * Render SVG icon
 */
function icon($name, $size = 5, $class = '') {
    $sizeClass = is_numeric($size) ? "w-{$size} h-{$size}" : $size;
    $path = getIconPath($name);
    return '<svg class="' . $sizeClass . ' ' . $class . '" fill="none" stroke="currentColor" viewBox="0 0 24 24">' .
           '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="' . $path . '"/>' .
           '</svg>';
}

// ============================================================
// STATUS BADGE HELPERS
// ============================================================

/**
 * Get status badge HTML
 */
function statusBadge($status) {
    $styles = [
        'active' => 'bg-green-100 text-green-800 border-green-200',
        'inactive' => 'bg-gray-100 text-gray-800 border-gray-200',
        'suspended' => 'bg-red-100 text-red-800 border-red-200',
        'completed' => 'bg-green-100 text-green-800 border-green-200',
        'pending' => 'bg-yellow-100 text-yellow-800 border-yellow-200',
        'partial' => 'bg-orange-100 text-orange-800 border-orange-200',
        'paid' => 'bg-green-100 text-green-800 border-green-200',
        'draft' => 'bg-gray-100 text-gray-800 border-gray-200',
        'sent' => 'bg-blue-100 text-blue-800 border-blue-200',
        'received' => 'bg-green-100 text-green-800 border-green-200',
        'cancelled' => 'bg-red-100 text-red-800 border-red-200',
        'refunded' => 'bg-purple-100 text-purple-800 border-purple-200',
        'processing' => 'bg-blue-100 text-blue-800 border-blue-200',
        'ready' => 'bg-teal-100 text-teal-800 border-teal-200',
        'confirmed' => 'bg-green-100 text-green-800 border-green-200',
        'rejected' => 'bg-red-100 text-red-800 border-red-200',
        'low' => 'bg-green-100 text-green-800 border-green-200',
        'normal' => 'bg-blue-100 text-blue-800 border-blue-200',
        'high' => 'bg-orange-100 text-orange-800 border-orange-200',
        'urgent' => 'bg-red-100 text-red-800 border-red-200',
    ];
    
    $style = $styles[strtolower($status)] ?? 'bg-gray-100 text-gray-800 border-gray-200';
    $label = ucfirst($status);
    
    return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ' . $style . '">' . $label . '</span>';
}

// ============================================================
// PAGINATION HELPER
// ============================================================

/**
 * Render pagination links
 */
function renderPagination($pagination, $baseUrl) {
    if ($pagination['total_pages'] <= 1) return '';
    
    $page = $pagination['page'];
    $totalPages = $pagination['total_pages'];
    
    // Parse URL and add page param
    $separator = strpos($baseUrl, '?') !== false ? '&' : '?';
    
    $html = '<nav class="flex items-center justify-between mt-6">';
    $html .= '<div class="text-sm text-gray-600">';
    $html .= 'Showing <span class="font-medium">' . (($page - 1) * $pagination['per_page'] + 1) . '</span> to ';
    $html .= '<span class="font-medium">' . min($page * $pagination['per_page'], $pagination['total']) . '</span> of ';
    $html .= '<span class="font-medium">' . $pagination['total'] . '</span> results';
    $html .= '</div>';
    
    $html .= '<div class="flex items-center space-x-2">';
    
    // Previous
    if ($pagination['has_prev']) {
        $html .= '<a href="' . $baseUrl . $separator . 'page=' . ($page - 1) . '" class="px-3 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 transition">';
        $html .= icon('chevron-left', 4) . '</a>';
    } else {
        $html .= '<span class="px-3 py-2 rounded-lg border border-gray-200 text-gray-400 cursor-not-allowed">';
        $html .= icon('chevron-left', 4) . '</span>';
    }
    
    // Page numbers
    $start = max(1, $page - 2);
    $end = min($totalPages, $page + 2);
    
    if ($start > 1) {
        $html .= '<a href="' . $baseUrl . $separator . 'page=1" class="px-3 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 transition">1</a>';
        if ($start > 2) $html .= '<span class="px-2 text-gray-400">...</span>';
    }
    
    for ($i = $start; $i <= $end; $i++) {
        if ($i == $page) {
            $html .= '<span class="px-3 py-2 rounded-lg bg-emerald-600 text-white font-medium">' . $i . '</span>';
        } else {
            $html .= '<a href="' . $baseUrl . $separator . 'page=' . $i . '" class="px-3 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 transition">' . $i . '</a>';
        }
    }
    
    if ($end < $totalPages) {
        if ($end < $totalPages - 1) $html .= '<span class="px-2 text-gray-400">...</span>';
        $html .= '<a href="' . $baseUrl . $separator . 'page=' . $totalPages . '" class="px-3 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 transition">' . $totalPages . '</a>';
    }
    
    // Next
    if ($pagination['has_next']) {
        $html .= '<a href="' . $baseUrl . $separator . 'page=' . ($page + 1) . '" class="px-3 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 transition">';
        $html .= icon('chevron-right', 4) . '</a>';
    } else {
        $html .= '<span class="px-3 py-2 rounded-lg border border-gray-200 text-gray-400 cursor-not-allowed">';
        $html .= icon('chevron-right', 4) . '</span>';
    }
    
    $html .= '</div></nav>';
    
    return $html;
}

// ============================================================
// UTILITY FUNCTIONS
// ============================================================

/**
 * Redirect to URL - Fixed version with output buffering
 */
function redirect($url) {
    // Clean any output buffers that might have been started
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // If headers haven't been sent, do a proper redirect
    if (!headers_sent()) {
        header("Location: " . $url);
        exit();
    } else {
        // Fallback: use JavaScript redirect
        echo '<script>window.location.href = "' . $url . '";</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . $url . '"></noscript>';
        exit();
    }
}

/**
 * Get current URL
 */
function currentUrl() {
    return strtok($_SERVER['REQUEST_URI'], '?');
}

/**
 * Check if current page matches
 */
function isActivePage($page) {
    return strpos($_SERVER['REQUEST_URI'], $page) !== false;
}

/**
 * Generate select dropdown HTML
 */
function selectDropdown($name, $options, $selected = '', $attributes = '') {
    $html = '<select name="' . $name . '" ' . $attributes . ' class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition">';
    $html .= '<option value="">-- Select --</option>';
    foreach ($options as $value => $label) {
        $isSelected = $selected == $value ? 'selected' : '';
        $html .= '<option value="' . $value . '" ' . $isSelected . '>' . sanitize($label) . '</option>';
    }
    $html .= '</select>';
    return $html;
}

/**
 * Truncate text
 */
function truncate($text, $length = 50) {
    if (strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}

/**
 * Get client IP address
 */
function getClientIP() {
    $ipKeys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            return $_SERVER[$key];
        }
    }
    return '0.0.0.0';
}

/**
 * Calculate tax amount
 */
function calculateTax($amount, $taxRate = null) {
    $rate = $taxRate ?? DEFAULT_TAX_RATE;
    return round($amount * ($rate / 100), 2);
}

/**
 * Calculate total with tax
 */
function calculateTotalWithTax($amount, $taxRate = null) {
    return $amount + calculateTax($amount, $taxRate);
}

/**
 * Generate receipt number
 */
function generateReceiptNumber() {
    return 'RCP-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Generate transaction number
 */
function generateTransactionNumber() {
    return 'TXN-' . date('Y') . strtoupper(substr(uniqid(), -6));
}

/**
 * Generate PO number
 */
function generatePONumber() {
    return 'PO-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Generate order number
 */
function generateOrderNumber() {
    return 'ORD-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Generate expense number
 */
function generateExpenseNumber() {
    return 'EXP-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Generate contribution number
 */
function generateContributionNumber() {
    return 'CON-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Generate payment number
 */
function generatePaymentNumber() {
    return 'PAY-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Format file size
 */
function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $unitIndex = 0;
    while ($bytes >= 1024 && $unitIndex < count($units) - 1) {
        $bytes /= 1024;
        $unitIndex++;
    }
    return round($bytes, 2) . ' ' . $units[$unitIndex];
}