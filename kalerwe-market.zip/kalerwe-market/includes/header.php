<?php
/**
 * Kalerwe Market - Main Layout Header
 * 
 * This is included at the top of every page. It handles:
 * - Authentication check
 * - HTML head section
 * - Navigation sidebar
 * - Top header bar
 */

// Ensure config is loaded
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

// Auth check for protected pages
$publicPages = ['login.php', 'register.php', 'forgot-password.php', 'install.php'];
$currentPage = basename($_SERVER['PHP_SELF']);

if (!in_array($currentPage, $publicPages)) {
    auth()->requireAuth();
}

// Get current user info
$currentUser = auth()->getUser();
$currentVendor = auth()->getVendor();
$userRole = auth()->getRole();
$isAdmin = auth()->isAdmin();

// Load company settings
$db = getDB();
$settings = $db->fetchOne("SELECT * FROM company_settings LIMIT 1");
if (!$settings) {
    $settings = [
        'association_name' => APP_NAME,
        'currency_symbol' => DEFAULT_CURRENCY_SYMBOL,
        'logo' => ''
    ];
}

// Count low stock items for vendors
$lowStockCount = 0;
if ($userRole === 'vendor' && $currentVendor) {
    $lowStockCount = $db->count(
        'products', 
        'vendor_id = ? AND quantity <= min_stock_level AND is_active = 1', 
        [$currentVendor['id']]
    );
} elseif ($isAdmin) {
    $lowStockCount = $db->count(
        'products', 
        'quantity <= min_stock_level AND is_active = 1'
    );
}

// Count unread announcements
$announcementCount = $db->count(
    'announcements',
    'is_active = 1 AND (valid_until IS NULL OR valid_until >= CURDATE())'
);

// Get accessible modules for current user
$accessibleModules = [];
foreach ($APP_MODULES as $key => $module) {
    if (in_array($userRole, $module['roles'])) {
        $accessibleModules[$key] = $module;
    }
}

// Check if mobile menu is open
$mobileMenuOpen = isset($_COOKIE['mobile_menu_open']) && $_COOKIE['mobile_menu_open'] === 'true';

// Check if this is a redirect page (no output should be sent)
$isRedirectPage = isset($_SESSION['_redirect_pending']) && $_SESSION['_redirect_pending'] === true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="<?php echo APP_NAME; ?> - Web-Based Information System">
    <meta name="theme-color" content="#059669">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' . APP_SHORT_NAME : APP_NAME; ?></title>
    
    <!-- Tailwind CSS CDN (optimized for low-bandwidth) -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Tailwind Config -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        emerald: {
                            50: '#ecfdf5',
                            100: '#d1fae5',
                            200: '#a7f3d0',
                            300: '#6ee7b7',
                            400: '#34d399',
                            500: '#10b981',
                            600: '#059669',
                            700: '#047857',
                            800: '#065f46',
                            900: '#064e3b',
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.3s ease-in-out',
                        'slide-in': 'slideIn 0.3s ease-out',
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                    },
                    keyframes: {
                        fadeIn: {
                            '0%': { opacity: '0' },
                            '100%': { opacity: '1' },
                        },
                        slideIn: {
                            '0%': { transform: 'translateX(-10px)', opacity: '0' },
                            '100%': { transform: 'translateX(0)', opacity: '1' },
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Custom Styles -->
    <style>
        /* Inter Font - Loaded via @import */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        * { 
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
        }
        
        body { 
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        
        /* Smooth scrolling */
        html { scroll-behavior: smooth; }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #10b981; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #059669; }
        
        /* Mobile touch optimizations */
        .touch-target { min-height: 44px; min-width: 44px; }
        
        /* Form focus states */
        input:focus, select:focus, textarea:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }
        
        /* Loading spinner */
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #10b981;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        
        /* Print styles for receipts */
        @media print {
            .no-print { display: none !important; }
            .print-only { display: block !important; }
            body { background: white; }
            .sidebar, .topbar { display: none; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
        }
        
        /* Receipt styling */
        .receipt {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.4;
        }
        
        /* Card hover effect */
        .card-hover {
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        /* Status dot animation */
        .status-dot {
            animation: pulse-slow 2s infinite;
        }
        
        /* Modal backdrop */
        .modal-backdrop {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }
        
        /* Table responsive wrapper */
        .table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        
        /* Gradient backgrounds */
        .bg-gradient-emerald {
            background: linear-gradient(135deg, #059669 0%, #10b981 100%);
        }
        
        /* Skeleton loading */
        .skeleton {
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: skeleton-loading 1.5s infinite;
        }
        @keyframes skeleton-loading {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
    </style>
    
    <!-- Chart.js for Reports -->
    <?php if (isset($pageTitle) && strpos($pageTitle, 'Report') !== false): ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <?php endif; ?>
</head>
<body class="bg-gray-50 text-gray-800 min-h-screen">

<?php if (!in_array($currentPage, $publicPages)): ?>
<!-- ========== SIDEBAR ========== -->
<aside id="sidebar" class="fixed inset-y-0 left-0 z-50 w-64 bg-emerald-800 text-white transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out flex flex-col">
    
    <!-- Logo Area -->
    <div class="flex items-center justify-center h-16 bg-emerald-900 border-b border-emerald-700 px-4">
        <div class="flex items-center space-x-3">
            <div class="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
            </div>
            <div class="overflow-hidden">
                <h1 class="text-sm font-bold leading-tight truncate"><?php echo APP_SHORT_NAME; ?></h1>
                <p class="text-xs text-emerald-300 truncate"><?php echo $settings['association_name']; ?></p>
            </div>
        </div>
    </div>
    
    <!-- User Info Card -->
    <div class="px-4 py-3 bg-emerald-700/50 border-b border-emerald-700">
        <div class="flex items-center space-x-3">
            <div class="w-10 h-10 rounded-full bg-emerald-600 flex items-center justify-center flex-shrink-0">
                <span class="text-sm font-bold"><?php echo strtoupper(substr($currentUser['full_name'], 0, 2)); ?></span>
            </div>
            <div class="overflow-hidden">
                <p class="text-sm font-medium truncate"><?php echo sanitize($currentUser['full_name']); ?></p>
                <p class="text-xs text-emerald-300 truncate"><?php echo ucfirst($userRole); ?></p>
            </div>
        </div>
    </div>
    
    <!-- Navigation -->
    <nav class="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        <?php foreach ($accessibleModules as $key => $module): 
            $isActive = isActivePage(basename($module['route'])) || 
                       (basename($module['route']) === 'index.php' && isActivePage(dirname($module['route'])));
            $activeClass = $isActive ? 'bg-emerald-700 text-white' : 'text-emerald-100 hover:bg-emerald-700/50 hover:text-white';
        ?>
        <a href="<?php echo APP_URL . $module['route']; ?>" 
           class="flex items-center px-3 py-2.5 rounded-lg text-sm font-medium transition-colors touch-target <?php echo $activeClass; ?>">
            <?php echo icon($module['icon'], 5, 'mr-3 flex-shrink-0'); ?>
            <span class="truncate"><?php echo $module['label']; ?></span>
            
            <!-- Badges -->
            <?php if ($key === 'inventory' && $lowStockCount > 0): ?>
                <span class="ml-auto bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full"><?php echo $lowStockCount; ?></span>
            <?php endif; ?>
            <?php if ($key === 'announcements' && $announcementCount > 0): ?>
                <span class="ml-auto bg-emerald-500 text-white text-xs font-bold px-2 py-0.5 rounded-full"><?php echo $announcementCount; ?></span>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </nav>
    
    <!-- Bottom Actions -->
    <div class="border-t border-emerald-700 p-3 space-y-1">
        <a href="<?php echo APP_URL; ?>/profile.php" class="flex items-center px-3 py-2.5 rounded-lg text-sm font-medium text-emerald-100 hover:bg-emerald-700/50 transition-colors touch-target">
            <?php echo icon('user', 5, 'mr-3 flex-shrink-0'); ?>
            <span>My Profile</span>
        </a>
        <a href="<?php echo APP_URL; ?>/logout.php" class="flex items-center px-3 py-2.5 rounded-lg text-sm font-medium text-red-300 hover:bg-red-600/20 transition-colors touch-target"
           onclick="return confirm('Are you sure you want to logout?');">
            <?php echo icon('log-out', 5, 'mr-3 flex-shrink-0'); ?>
            <span>Logout</span>
        </a>
    </div>
</aside>

<!-- ========== MOBILE OVERLAY ========== -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black/50 z-40 hidden lg:hidden backdrop-blur-sm" onclick="toggleSidebar()"></div>

<!-- ========== TOP HEADER ========== -->
<header class="fixed top-0 right-0 left-0 lg:left-64 z-30 bg-white border-b border-gray-200 h-16 flex items-center px-4 lg:px-6">
    <div class="flex items-center justify-between w-full">
        <!-- Left: Menu Toggle + Page Title -->
        <div class="flex items-center">
            <button onclick="toggleSidebar()" class="lg:hidden p-2 rounded-lg hover:bg-gray-100 mr-3 touch-target">
                <?php echo icon('menu', 6); ?>
            </button>
            <div>
                <h2 class="text-lg font-semibold text-gray-800"><?php echo isset($pageTitle) ? $pageTitle : 'Dashboard'; ?></h2>
                <p class="text-xs text-gray-500 hidden sm:block"><?php echo date(DATE_FORMAT); ?></p>
            </div>
        </div>
        
        <!-- Right: Actions -->
        <div class="flex items-center space-x-3">
            <!-- Low Stock Alert (vendors/admin) -->
            <?php if ($lowStockCount > 0): ?>
            <a href="<?php echo APP_URL; ?>/modules/inventory/index.php?filter=low_stock" class="relative p-2 rounded-lg hover:bg-gray-100 text-red-500 touch-target" title="Low Stock Alert">
                <?php echo icon('alert-triangle', 5); ?>
                <span class="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center"><?php echo $lowStockCount; ?></span>
            </a>
            <?php endif; ?>
            
            <!-- Announcements -->
            <a href="<?php echo APP_URL; ?>/modules/announcements/index.php" class="relative p-2 rounded-lg hover:bg-gray-100 text-gray-600 touch-target" title="Announcements">
                <?php echo icon('bell', 5); ?>
                <?php if ($announcementCount > 0): ?>
                <span class="absolute top-1 right-1 w-4 h-4 bg-emerald-500 text-white text-xs rounded-full flex items-center justify-center"><?php echo $announcementCount; ?></span>
                <?php endif; ?>
            </a>
            
            <!-- Quick Actions Dropdown -->
            <div class="relative" id="quickActionsDropdown">
                <button onclick="toggleDropdown('quickActionsMenu')" class="hidden sm:flex items-center space-x-2 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition-colors touch-target">
                    <?php echo icon('plus', 4, 'mr-1'); ?>
                    <span>Quick Add</span>
                </button>
                <div id="quickActionsMenu" class="hidden absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-50">
                    <?php if (auth()->hasPermission('sale.create')): ?>
                    <a href="<?php echo APP_URL; ?>/modules/sales/create.php" class="flex items-center px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50">
                        <?php echo icon('shopping-cart', 4, 'mr-3 text-emerald-600'); ?> New Sale
                    </a>
                    <?php endif; ?>
                    <?php if (auth()->hasPermission('product.create')): ?>
                    <a href="<?php echo APP_URL; ?>/modules/products/create.php" class="flex items-center px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50">
                        <?php echo icon('package', 4, 'mr-3 text-emerald-600'); ?> New Product
                    </a>
                    <?php endif; ?>
                    <?php if (auth()->hasPermission('expense.create')): ?>
                    <a href="<?php echo APP_URL; ?>/modules/expenses/create.php" class="flex items-center px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50">
                        <?php echo icon('receipt', 4, 'mr-3 text-emerald-600'); ?> New Expense
                    </a>
                    <?php endif; ?>
                    <?php if (auth()->hasPermission('order.create')): ?>
                    <a href="<?php echo APP_URL; ?>/modules/orders/create.php" class="flex items-center px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50">
                        <?php echo icon('clipboard-copy', 4, 'mr-3 text-emerald-600'); ?> New Order
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- ========== MAIN CONTENT AREA ========== -->
<main class="lg:ml-64 pt-16 min-h-screen">
    <div class="p-4 lg:p-6 max-w-7xl mx-auto">
        
        <!-- Flash Messages -->
        <?php echo renderFlash(); ?>
        
<?php endif; // End protected page check ?>

<!-- Include quick actions dropdown handler -->
<script>
function toggleDropdown(id) {
    const el = document.getElementById(id);
    if (el) {
        el.classList.toggle('hidden');
        // Close when clicking outside
        document.addEventListener('click', function close(e) {
            if (!el.contains(e.target) && !e.target.closest('[onclick*="' + id + '"')) {
                el.classList.add('hidden');
                document.removeEventListener('click', close);
            }
        });
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (sidebar && overlay) {
        sidebar.classList.toggle('-translate-x-full');
        overlay.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    }
}

// Auto-hide sidebar on route change (mobile)
if (window.innerWidth < 1024) {
    document.querySelectorAll('#sidebar a').forEach(link => {
        link.addEventListener('click', () => {
            toggleSidebar();
        });
    });
}
</script>