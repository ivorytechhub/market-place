<?php
/**
 * Kalerwe Market - Main Layout Footer
 * 
 * Closes the main content area and HTML document.
 * Includes common JavaScript functionality.
 */

// Only close if this is a protected page
$publicPages = ['login.php', 'register.php', 'forgot-password.php', 'install.php'];
$currentPage = basename($_SERVER['PHP_SELF']);

if (!in_array($currentPage, $publicPages)):
?>
    </div><!-- End max-w-7xl -->
</main><!-- End main -->

<!-- ========== MOBILE BOTTOM NAV ========== -->
<nav class="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40 pb-safe">
    <div class="flex justify-around items-center h-16">
        <?php 
        $mobileModules = array_slice($accessibleModules, 0, 5, true);
        foreach ($mobileModules as $key => $module): 
            $isActive = isActivePage(basename($module['route']));
            $activeClass = $isActive ? 'text-emerald-600' : 'text-gray-500';
        ?>
        <a href="<?php echo APP_URL . $module['route']; ?>" class="flex flex-col items-center justify-center py-2 px-3 <?php echo $activeClass; ?> touch-target">
            <?php echo icon($module['icon'], 5); ?>
            <span class="text-xs mt-1 truncate max-w-[60px]"><?php echo $module['label']; ?></span>
        </a>
        <?php endforeach; ?>
    </div>
</nav>

<!-- Mobile bottom padding for content -->
<div class="lg:hidden h-16"></div>

<?php endif; ?>

<!-- ========== COMMON SCRIPTS ========== -->
<script>
/**
 * Kalerwe Market - Common JavaScript Functions
 */

// Confirm delete action
function confirmDelete(message) {
    return confirm(message || 'Are you sure you want to delete this item? This action cannot be undone.');
}

// Confirm action
function confirmAction(message) {
    return confirm(message || 'Are you sure?');
}

// Print element
function printElement(elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>Print</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background: #f5f5f5; }
                .text-right { text-align: right; }
                .text-center { text-align: center; }
                .font-bold { font-weight: bold; }
                .mt-4 { margin-top: 16px; }
                .mb-4 { margin-bottom: 16px; }
                .border-t { border-top: 2px solid #333; }
            </style>
        </head>
        <body>${element.innerHTML}</body>
        </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 250);
}

// Format number as currency
function formatCurrency(amount) {
    return '<?php echo DEFAULT_CURRENCY_SYMBOL; ?> ' + parseFloat(amount).toLocaleString('en-UG', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
}

// Calculate totals in forms
function calculateTotals() {
    document.querySelectorAll('[data-calculate]').forEach(input => {
        input.addEventListener('input', function() {
            const form = this.closest('form');
            if (!form) return;
            
            const quantity = parseFloat(form.querySelector('[name="quantity"]')?.value) || 0;
            const unitPrice = parseFloat(form.querySelector('[name="unit_price"]')?.value) || 0;
            const discount = parseFloat(form.querySelector('[name="discount"]')?.value) || 0;
            const taxRate = parseFloat(form.querySelector('[name="tax_rate"]')?.value) || <?php echo DEFAULT_TAX_RATE; ?>;
            
            const subtotal = quantity * unitPrice - discount;
            const tax = subtotal * (taxRate / 100);
            const total = subtotal + tax;
            
            const totalEl = form.querySelector('[data-total]');
            if (totalEl) totalEl.textContent = formatCurrency(total);
        });
    });
}

// Auto-dismiss flash messages
setTimeout(() => {
    document.querySelectorAll('[role="alert"]').forEach(el => {
        el.style.transition = 'opacity 0.5s';
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 500);
    });
}, 5000);

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', function() {
    calculateTotals();
    
    // Close dropdowns on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('[id$="Menu"]').forEach(el => el.classList.add('hidden'));
        }
    });
});

// Service Worker registration for PWA (if supported)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // PWA support can be added here
    });
}
</script>

</body>
</html>
