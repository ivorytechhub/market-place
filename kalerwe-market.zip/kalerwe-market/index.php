<?php
/**
 * Kalerwe Market Vendors' Association - Landing Page
 * 
 * Redirects to dashboard if authenticated, otherwise to login page.
 * Also serves as the application entry point.
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

if (auth()->isLoggedIn()) {
    redirect(APP_URL . '/dashboard.php');
} else {
    redirect(APP_URL . '/login.php');
}
