<?php
/**
 * Kalerwe Market - Installation Script
 * 
 * One-click installer that:
 * 1. Creates the database if it doesn't exist
 * 2. Imports the full schema with all tables
 * 3. Seeds sample data
 * 4. Verifies the installation
 */

require_once __DIR__ . '/includes/config.php';

// Only allow installation if not already completed
if (file_exists(__DIR__ . '/.installed') && !isset($_GET['force'])) {
    die('<!DOCTYPE html><html><head><title>Already Installed</title><script src="https://cdn.tailwindcss.com"></script></head><body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-lg border border-gray-100 p-8 max-w-md w-full text-center">
        <div class="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        </div>
        <h2 class="text-xl font-bold text-gray-800 mb-2">Already Installed</h2>
        <p class="text-gray-500 mb-4">The system is already installed. To reinstall, add <code class="bg-gray-100 px-2 py-1 rounded">?force=1</code> to the URL.</p>
        <a href="index.php" class="inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition">Go to Login</a>
    </div></body></html>');
}

$step = $_GET['step'] ?? 'check';
$error = '';
$success = '';

// Check database connection
try {
    $dsn = "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    $error = "Cannot connect to MySQL server: " . $e->getMessage();
    $step = 'error';
}

// Process installation steps
if ($step === 'install' && !$error) {
    try {
        // Create database if not exists
        $pdo->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE " . DB_NAME);
        
        // Read and execute schema
        $sql = file_get_contents(__DIR__ . '/install/database.sql');
        
        // Split and execute statements
        $pdo->exec($sql);
        
        // Create installed marker
        file_put_contents(__DIR__ . '/.installed', date('Y-m-d H:i:s'));
        
        $success = 'Installation completed successfully!';
        $step = 'complete';
        
    } catch (PDOException $e) {
        $error = "Installation failed: " . $e->getMessage();
        $step = 'error';
    }
}

$pageTitle = 'Installation';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install | <?php echo APP_SHORT_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'); body { font-family: 'Inter', system-ui, sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">
    <div class="max-w-lg w-full">
        <!-- Logo -->
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
            </div>
            <h1 class="text-2xl font-bold text-gray-800"><?php echo APP_SHORT_NAME; ?></h1>
            <p class="text-gray-500">Installation Wizard</p>
        </div>
        
        <div class="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
            <?php if ($step === 'check'): ?>
            <!-- Pre-installation Check -->
            <div class="p-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4">Pre-Installation Check</h2>
                
                <div class="space-y-3 mb-6">
                    <?php
                    $checks = [
                        'PHP Version >= 7.4' => PHP_VERSION_ID >= 70400,
                        'PDO Extension' => extension_loaded('pdo'),
                        'PDO MySQL Driver' => extension_loaded('pdo_mysql'),
                        'Database Connection' => isset($pdo) && $pdo instanceof PDO,
                        'Schema File Exists' => file_exists(__DIR__ . '/install/database.sql'),
                        'Write Permissions' => is_writable(__DIR__),
                    ];
                    $allPassed = true;
                    foreach ($checks as $label => $passed):
                        $allPassed = $allPassed && $passed;
                    ?>
                    <div class="flex items-center justify-between p-3 rounded-lg <?php echo $passed ? 'bg-green-50' : 'bg-red-50'; ?>">
                        <span class="text-sm <?php echo $passed ? 'text-green-800' : 'text-red-800'; ?>"><?php echo $label; ?></span>
                        <svg class="w-5 h-5 <?php echo $passed ? 'text-green-500' : 'text-red-500'; ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <?php if ($passed): ?>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                            <?php else: ?>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                            <?php endif; ?>
                        </svg>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if ($allPassed): ?>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                    <p class="text-sm text-blue-800">All checks passed! Click below to install the database and sample data.</p>
                </div>
                <a href="?step=install" class="block w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-center transition shadow-lg touch-target">
                    Install Now
                </a>
                <?php else: ?>
                <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p class="text-sm text-red-800">Some checks failed. Please fix the issues above and refresh this page.</p>
                </div>
                <?php endif; ?>
            </div>
            
            <?php elseif ($step === 'complete'): ?>
            <!-- Complete -->
            <div class="p-8 text-center">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                </div>
                <h2 class="text-xl font-bold text-gray-800 mb-2">Installation Complete!</h2>
                <p class="text-gray-500 mb-6">The system has been installed with sample data.</p>
                
                <div class="bg-gray-50 rounded-lg p-4 mb-6 text-left text-sm">
                    <p class="font-medium text-gray-700 mb-2">Default Login Credentials:</p>
                    <div class="space-y-1 text-gray-600">
                        <p><span class="font-medium">Username:</span> <code class="bg-gray-200 px-2 py-0.5 rounded">admin</code></p>
                        <p><span class="font-medium">Password:</span> <code class="bg-gray-200 px-2 py-0.5 rounded">password</code></p>
                    </div>
                    <p class="text-xs text-red-600 mt-2">Please change the default password after first login.</p>
                </div>
                
                <a href="login.php" class="block w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-center transition shadow-lg touch-target">
                    Go to Login
                </a>
            </div>
            
            <?php elseif ($step === 'error'): ?>
            <!-- Error -->
            <div class="p-8 text-center">
                <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <h2 class="text-xl font-bold text-gray-800 mb-2">Installation Failed</h2>
                <p class="text-red-600 text-sm mb-4"><?php echo sanitize($error); ?></p>
                <a href="?step=check" class="inline-flex items-center px-4 py-2 bg-gray-800 text-white rounded-lg text-sm font-medium hover:bg-gray-900 transition">Try Again</a>
            </div>
            <?php endif; ?>
        </div>
        
        <p class="text-center text-xs text-gray-400 mt-6">&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> v<?php echo APP_VERSION; ?></p>
    </div>
</body>
</html>
