<?php
/**
 * Kalerwe Market - Inventory & Stock Management Module
 * 
 * Real-time stock tracking, low stock alerts, stock movement history,
 * and inventory adjustment capabilities.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('inventory.view_own');

$pageTitle = 'Inventory';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

$filter = $_GET['filter'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

$params = [];
$where = ["p.is_active = 1"];

if (!$isAdmin && $vendorId) {
    $where[] = "p.vendor_id = ?";
    $params[] = $vendorId;
}

if ($filter === 'low_stock') {
    $where[] = "p.quantity <= p.min_stock_level";
} elseif ($filter === 'out_of_stock') {
    $where[] = "p.quantity = 0";
}

$whereSql = implode(' AND ', $where);

// Get inventory with movement data
$inventory = $db->paginate(
    "SELECT p.id, p.sku, p.name, p.quantity, p.min_stock_level, p.unit, p.cost_price, p.selling_price,
            c.name as category_name, v.business_name, v.stall_number,
            (SELECT COALESCE(SUM(quantity), 0) FROM transaction_items ti JOIN sales_transactions st ON ti.transaction_id = st.id WHERE ti.product_id = p.id AND st.status = 'completed' AND MONTH(st.created_at) = MONTH(CURDATE())) as sold_this_month,
            (SELECT COALESCE(SUM(quantity), 0) FROM inventory_movements WHERE product_id = p.id AND movement_type = 'purchase' AND MONTH(created_at) = MONTH(CURDATE())) as purchased_this_month
     FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     LEFT JOIN vendors v ON p.vendor_id = v.id
     WHERE {$whereSql}
     ORDER BY (p.quantity / p.min_stock_level) ASC, p.name ASC",
    $params, $page
);

// Summary stats
$totalItems = $db->count('products', $isAdmin ? 'is_active = 1' : 'vendor_id = ? AND is_active = 1', $isAdmin ? [] : [$vendorId]);
$lowStockItems = $db->count('products', ($isAdmin ? '' : 'vendor_id = ? AND ') . 'quantity <= min_stock_level AND is_active = 1', $isAdmin ? [] : [$vendorId]);
$outOfStock = $db->count('products', ($isAdmin ? '' : 'vendor_id = ? AND ') . 'quantity = 0 AND is_active = 1', $isAdmin ? [] : [$vendorId]);
$totalValue = $db->fetchOne("SELECT COALESCE(SUM(quantity * cost_price), 0) as total FROM products WHERE " . ($isAdmin ? "is_active = 1" : "vendor_id = {$vendorId} AND is_active = 1"))['total'] ?? 0;
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Inventory Management</h2>
        <p class="text-sm text-gray-500 mt-1">Track stock levels and movements</p>
    </div>
</div>

<!-- Summary Cards -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Total Items</p>
        <p class="text-xl font-bold text-blue-600"><?php echo formatNumber($totalItems); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Low Stock</p>
        <p class="text-xl font-bold text-orange-600"><?php echo formatNumber($lowStockItems); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Out of Stock</p>
        <p class="text-xl font-bold text-red-600"><?php echo formatNumber($outOfStock); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Inventory Value</p>
        <p class="text-xl font-bold text-emerald-600"><?php echo formatCurrency($totalValue); ?></p>
    </div>
</div>

<!-- Filter Tabs -->
<div class="flex flex-wrap gap-2 mb-6">
    <a href="?" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo !$filter ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>">All Items</a>
    <a href="?filter=low_stock" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo $filter === 'low_stock' ? 'bg-orange-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>">Low Stock</a>
    <a href="?filter=out_of_stock" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo $filter === 'out_of_stock' ? 'bg-red-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>">Out of Stock</a>
</div>

<!-- Inventory Table -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Product</th>
                    <?php if ($isAdmin): ?><th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th><?php endif; ?>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Current Stock</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Min Level</th>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Unit Cost</th>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Value</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Sold (MTD)</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($inventory['data'] as $item): 
                    $stockPercent = min(100, ($item['quantity'] / max(1, $item['min_stock_level'])) * 100);
                    $stockColor = $stockPercent <= 25 ? 'bg-red-500' : ($stockPercent <= 50 ? 'bg-orange-500' : 'bg-emerald-500');
                    $status = $item['quantity'] == 0 ? 'Out of Stock' : ($item['quantity'] <= $item['min_stock_level'] ? 'Low Stock' : 'OK');
                    $statusClass = $item['quantity'] == 0 ? 'bg-red-100 text-red-800' : ($item['quantity'] <= $item['min_stock_level'] ? 'bg-orange-100 text-orange-800' : 'bg-green-100 text-green-800');
                ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4">
                        <p class="font-medium text-gray-800"><?php echo sanitize($item['name']); ?></p>
                        <p class="text-xs text-gray-500"><?php echo sanitize($item['sku']); ?> | <?php echo sanitize($item['category_name'] ?? ''); ?></p>
                    </td>
                    <?php if ($isAdmin): ?>
                    <td class="py-3 px-4 text-gray-600"><?php echo sanitize($item['business_name'] ?? ''); ?></td>
                    <?php endif; ?>
                    <td class="py-3 px-4 text-center">
                        <span class="font-bold text-gray-800"><?php echo formatNumber($item['quantity']); ?></span>
                        <span class="text-xs text-gray-500"><?php echo $item['unit']; ?></span>
                    </td>
                    <td class="py-3 px-4 text-center text-gray-600"><?php echo $item['min_stock_level']; ?></td>
                    <td class="py-3 px-4 text-right"><?php echo formatCurrency($item['cost_price']); ?></td>
                    <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($item['quantity'] * $item['cost_price']); ?></td>
                    <td class="py-3 px-4 text-center text-gray-600"><?php echo $item['sold_this_month'] ?? 0; ?></td>
                    <td class="py-3 px-4 text-center">
                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium <?php echo $statusClass; ?>">
                            <?php echo $status; ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($inventory['data'])): ?>
                <tr><td colspan="<?php echo $isAdmin ? 8 : 7; ?>" class="py-12 text-center text-gray-400">No inventory items found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo renderPagination($inventory, '?' . ($filter ? "filter={$filter}&" : '')); ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
