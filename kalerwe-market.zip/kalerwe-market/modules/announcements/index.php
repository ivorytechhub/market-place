<?php
/**
 * Kalerwe Market - Announcements Module
 * 
 * Communication board for association announcements and notices.
 * All authenticated users can view; only admins can create/edit.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requireAuth();

$pageTitle = 'Announcements';
$db = getDB();
$isAdmin = auth()->isAdmin();

$announcements = $db->fetchAll(
    "SELECT a.*, u.full_name as created_by_name
     FROM announcements a
     LEFT JOIN users u ON a.created_by = u.id
     WHERE a.is_active = 1 AND (a.valid_until IS NULL OR a.valid_until >= CURDATE())
     ORDER BY a.priority DESC, a.created_at DESC"
);

// Handle delete (admin only)
if ($isAdmin && isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $db->execute("UPDATE announcements SET is_active = 0 WHERE id = ?", [$id]);
    auth()->logActivity('delete', 'announcements', "Deleted announcement #{$id}");
    setFlash('success', 'Announcement removed.');
    redirect(currentUrl());
}

// Handle create (admin only)
if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        $title = cleanInput($_POST['title'] ?? '');
        $content = cleanInput($_POST['content'] ?? '');
        $priority = cleanInput($_POST['priority'] ?? 'normal');
        $validFrom = cleanInput($_POST['valid_from'] ?? date('Y-m-d'));
        $validUntil = cleanInput($_POST['valid_until'] ?? '');
        
        if ($title && $content) {
            $db->insert(
                "INSERT INTO announcements (title, content, priority, valid_from, valid_until, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                [$title, $content, $priority, $validFrom, $validUntil ?: null, auth()->getUserId()]
            );
            auth()->logActivity('create', 'announcements', "Created announcement: {$title}");
            setFlash('success', 'Announcement posted successfully.');
            redirect(currentUrl());
        }
    }
}
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Announcements</h2>
        <p class="text-sm text-gray-500 mt-1">Association notices and communications</p>
    </div>
</div>

<?php if ($isAdmin): ?>
<!-- Create Form -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6">
    <h3 class="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">Post New Announcement</h3>
    <form method="POST" action="" class="space-y-4">
        <?php echo csrfField(); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="md:col-span-2">
                <input type="text" name="title" required placeholder="Announcement title..." class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div class="md:col-span-2">
                <textarea name="content" required rows="3" placeholder="Announcement content..." class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"></textarea>
            </div>
            <div>
                <select name="priority" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="low">Low Priority</option>
                    <option value="normal" selected>Normal</option>
                    <option value="high">High Priority</option>
                    <option value="urgent">Urgent</option>
                </select>
            </div>
            <div class="flex gap-3">
                <input type="date" name="valid_from" value="<?php echo date('Y-m-d'); ?>" class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm">
                <input type="date" name="valid_until" placeholder="Valid until (optional)" class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm">
            </div>
        </div>
        <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">Post Announcement</button>
    </form>
</div>
<?php endif; ?>

<!-- Announcements List -->
<div class="space-y-4">
    <?php foreach ($announcements as $ann): 
        $priorityConfig = [
            'urgent' => ['border' => 'border-l-red-500', 'bg' => 'bg-red-50', 'badge' => 'bg-red-100 text-red-800', 'icon' => 'text-red-500'],
            'high' => ['border' => 'border-l-orange-500', 'bg' => 'bg-orange-50', 'badge' => 'bg-orange-100 text-orange-800', 'icon' => 'text-orange-500'],
            'normal' => ['border' => 'border-l-blue-500', 'bg' => 'bg-blue-50', 'badge' => 'bg-blue-100 text-blue-800', 'icon' => 'text-blue-500'],
            'low' => ['border' => 'border-l-green-500', 'bg' => 'bg-green-50', 'badge' => 'bg-green-100 text-green-800', 'icon' => 'text-green-500'],
        ];
        $cfg = $priorityConfig[$ann['priority']] ?? $priorityConfig['normal'];
    ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 border-l-4 <?php echo $cfg['border']; ?> p-5">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <div class="flex items-center gap-2 mb-2">
                    <h3 class="text-lg font-semibold text-gray-800"><?php echo sanitize($ann['title']); ?></h3>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo $cfg['badge']; ?>"><?php echo ucfirst($ann['priority']); ?></span>
                </div>
                <p class="text-sm text-gray-600 mb-3 whitespace-pre-line"><?php echo nl2br(sanitize($ann['content'])); ?></p>
                <div class="flex items-center gap-4 text-xs text-gray-500">
                    <span class="flex items-center gap-1"><?php echo icon('user', 3, 'mr-1'); ?> <?php echo sanitize($ann['created_by_name'] ?? 'Admin'); ?></span>
                    <span class="flex items-center gap-1"><?php echo icon('calendar', 3, 'mr-1'); ?> <?php echo formatDateTime($ann['created_at']); ?></span>
                    <?php if ($ann['valid_until']): ?>
                    <span class="flex items-center gap-1"><?php echo icon('calendar', 3, 'mr-1'); ?> Valid until: <?php echo formatDate($ann['valid_until']); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ($isAdmin): ?>
            <a href="?delete=<?php echo $ann['id']; ?>" onclick="return confirm('Remove this announcement?')" class="p-2 text-red-500 hover:bg-red-50 rounded-lg transition ml-4 touch-target" title="Remove">
                <?php echo icon('trash', 4); ?>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if (empty($announcements)): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
        <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <?php echo icon('megaphone', 8, 'text-gray-400'); ?>
        </div>
        <h3 class="text-lg font-medium text-gray-800 mb-2">No Announcements</h3>
        <p class="text-sm text-gray-500">Check back later for updates from the association.</p>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
