<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('expense.create');

$pageTitle = 'Record Expense';
$db = getDB();
$isAdmin = auth()->isAdmin();
$vendorId = auth()->getVendorId();

$categories = $db->fetchAll("SELECT id, name FROM expense_categories WHERE is_active = 1 ORDER BY name");
$vendors = $isAdmin ? $db->fetchAll("SELECT id, business_name, vendor_code FROM vendors WHERE status = 'active' ORDER BY business_name") : [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }

    $categoryId = intval($_POST['category_id'] ?? 0);
    $amount = floatval($_POST['amount'] ?? 0);
    $description = cleanInput($_POST['description'] ?? '');
    $expenseDate = cleanInput($_POST['expense_date'] ?? date('Y-m-d'));
    $receiptReference = cleanInput($_POST['receipt_reference'] ?? '');
    $selectedVendorId = $isAdmin ? intval($_POST['vendor_id'] ?? 0) : $vendorId;

    if ($selectedVendorId <= 0) {
        $errors[] = 'Please select a vendor.';
    }
    if ($amount <= 0) {
        $errors[] = 'Amount must be greater than zero.';
    }
    if (!validDate($expenseDate)) {
        $errors[] = 'Please enter a valid expense date.';
    }

    if (empty($errors)) {
        $expenseNumber = generateExpenseNumber();
        $insertId = $db->insert(
            "INSERT INTO expenses (expense_number, category_id, vendor_id, amount, description, expense_date, receipt_reference, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
            [$expenseNumber, $categoryId ?: null, $selectedVendorId, $amount, $description, $expenseDate, $receiptReference, auth()->getUserId()]
        );

        if ($insertId) {
            auth()->logActivity('create', 'expenses', "Recorded expense: {$expenseNumber}");
            setFlash('success', 'Expense recorded successfully.');
            redirect(APP_URL . '/modules/expenses/index.php');
        }

        $errors[] = 'Unable to save expense. Please try again.';
    }
}
?>

<div class="max-w-4xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="index.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">Record New Expense</h2>
            <p class="text-sm text-gray-500">Capture expense details for reporting and tracking.</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php foreach ($errors as $error): ?>
            <li><?php echo sanitize($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php echo csrfField(); ?>
        <div class="p-6 grid grid-cols-1 lg:grid-cols-2 gap-4">
            <?php if ($isAdmin): ?>
            <div class="lg:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Vendor *</label>
                <select name="vendor_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Vendor --</option>
                    <?php foreach ($vendors as $vendor): ?>
                    <option value="<?php echo $vendor['id']; ?>" <?php echo (intval($_POST['vendor_id'] ?? 0) === intval($vendor['id'])) ? 'selected' : ''; ?>>
                        <?php echo sanitize($vendor['business_name']); ?> (<?php echo sanitize($vendor['vendor_code']); ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Expense Category</label>
                <select name="category_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Category --</option>
                    <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['id']; ?>" <?php echo (intval($_POST['category_id'] ?? 0) === intval($category['id'])) ? 'selected' : ''; ?>><?php echo sanitize($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Amount (UGX) *</label>
                <input type="number" name="amount" min="0" step="100" required value="<?php echo sanitize($_POST['amount'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Expense Date *</label>
                <input type="date" name="expense_date" required value="<?php echo sanitize($_POST['expense_date'] ?? date('Y-m-d')); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div class="lg:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
                <textarea name="description" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"><?php echo sanitize($_POST['description'] ?? ''); ?></textarea>
            </div>
            <div class="lg:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Receipt Reference</label>
                <input type="text" name="receipt_reference" value="<?php echo sanitize($_POST['receipt_reference'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="Receipt or voucher number">
            </div>
        </div>

        <div class="p-6 border-t border-gray-100 text-right">
            <button type="submit" class="inline-flex items-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('plus', 4, 'mr-2'); ?> Save Expense
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
