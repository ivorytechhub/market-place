<?php
/**
 * Kalerwe Market - Expense Management Module
 * 
 * Track and categorize business expenses including rent, utilities, levies.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('expense.view_own');

$pageTitle = 'Expenses';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

$categoryFilter = $_GET['category'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

$params = [];
$where = ['1=1'];
if (!$isAdmin && $vendorId) {
    $where[] = "e.vendor_id = ?";
    $params[] = $vendorId;
}
if ($categoryFilter) {
    $where[] = "e.category_id = ?";
    $params[] = $categoryFilter;
}
if ($dateFrom) {
    $where[] = "e.expense_date >= ?";
    $params[] = $dateFrom;
}
if ($dateTo) {
    $where[] = "e.expense_date <= ?";
    $params[] = $dateTo;
}

$whereSql = implode(' AND ', $where);

$expenses = $db->paginate(
    "SELECT e.*, ec.name as category_name, ec.name as expense_category, v.business_name
     FROM expenses e
     LEFT JOIN expense_categories ec ON e.category_id = ec.id
     LEFT JOIN vendors v ON e.vendor_id = v.id
     WHERE {$whereSql}
     ORDER BY e.expense_date DESC",
    $params, $page
);

$categories = $db->fetchAll("SELECT id, name FROM expense_categories WHERE is_active = 1 ORDER BY name");

// Summary
$monthTotal = $db->fetchOne("SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE MONTH(expense_date) = MONTH(CURDATE()) AND YEAR(expense_date) = YEAR(CURDATE())" . ($isAdmin ? "" : " AND vendor_id = {$vendorId}"))['total'] ?? 0;
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Expenses</h2>
        <p class="text-sm text-gray-500 mt-1">Track business expenses and costs</p>
    </div>
    <a href="create.php" class="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
        <?php echo icon('plus', 4, 'mr-2'); ?> New Expense
    </a>
</div>

<!-- Summary -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6 flex items-center justify-between">
    <div>
        <p class="text-sm text-gray-500">Total Expenses This Month</p>
        <p class="text-2xl font-bold text-red-600"><?php echo formatCurrency($monthTotal); ?></p>
    </div>
    <div class="p-3 bg-red-100 rounded-xl">
        <?php echo icon('receipt', 6, 'text-red-600'); ?>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="flex flex-col lg:flex-row gap-3">
        <select name="category" onchange="this.form.submit()" class="lg:w-48 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
            <option value="<?php echo $cat['id']; ?>" <?php echo $categoryFilter == $cat['id'] ? 'selected' : ''; ?>><?php echo sanitize($cat['name']); ?></option>
            <?php endforeach; ?>
        </select>
        <input type="date" name="date_from" value="<?php echo sanitize($dateFrom); ?>" class="lg:w-40 px-4 py-2.5 border border-gray-300 rounded-lg text-sm" placeholder="From">
        <input type="date" name="date_to" value="<?php echo sanitize($dateTo); ?>" class="lg:w-40 px-4 py-2.5 border border-gray-300 rounded-lg text-sm" placeholder="To">
        <button type="submit" class="px-6 py-2.5 bg-gray-800 text-white rounded-lg text-sm font-medium hover:bg-gray-900 transition touch-target">Filter</button>
        <?php if ($categoryFilter || $dateFrom || $dateTo): ?>
        <a href="?" class="px-6 py-2.5 border border-gray-300 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-50 transition text-center touch-target">Clear</a>
        <?php endif; ?>
    </form>
</div>

<!-- Expenses Table -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Expense #</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Category</th>
                    <?php if ($isAdmin): ?><th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th><?php endif; ?>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Description</th>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Amount</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($expenses['data'] as $exp): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4 font-medium text-emerald-600"><?php echo sanitize($exp['expense_number']); ?></td>
                    <td class="py-3 px-4"><span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700"><?php echo sanitize($exp['category_name'] ?? 'Other'); ?></span></td>
                    <?php if ($isAdmin): ?><td class="py-3 px-4 text-gray-600"><?php echo sanitize($exp['business_name'] ?? ''); ?></td><?php endif; ?>
                    <td class="py-3 px-4 text-gray-700"><?php echo sanitize($exp['description'] ?? '-'); ?></td>
                    <td class="py-3 px-4 text-right font-medium text-red-600"><?php echo formatCurrency($exp['amount']); ?></td>
                    <td class="py-3 px-4 text-gray-600"><?php echo formatDate($exp['expense_date']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($expenses['data'])): ?>
                <tr><td colspan="<?php echo $isAdmin ? 6 : 5; ?>" class="py-12 text-center text-gray-400">No expenses found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo renderPagination($expenses, '?' . http_build_query(array_filter(['category' => $categoryFilter, 'date_from' => $dateFrom, 'date_to' => $dateTo]))); ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
