<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('product.edit_own');

$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();
$productId = intval($_GET['id'] ?? 0);

if ($productId <= 0) {
    setFlash('error', 'Invalid product ID.');
    redirect(APP_URL . '/modules/products/index.php');
}

$product = $db->fetchOne("SELECT * FROM products WHERE id = ?", [$productId]);
if (!$product) {
    setFlash('error', 'Product not found.');
    redirect(APP_URL . '/modules/products/index.php');
}

if (!$isAdmin && $product['vendor_id'] !== $vendorId) {
    setFlash('error', 'You do not have permission to edit this product.');
    redirect(APP_URL . '/modules/products/index.php');
}

$categories = $db->fetchAll("SELECT id, name FROM categories WHERE is_active = 1 ORDER BY name");
$vendors = $isAdmin ? $db->fetchAll("SELECT id, business_name, vendor_code FROM vendors WHERE status = 'active' ORDER BY business_name") : [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }

    $selectedVendorId = $isAdmin ? intval($_POST['vendor_id'] ?? 0) : $vendorId;
    $sku = cleanInput($_POST['sku'] ?? '');
    $barcode = cleanInput($_POST['barcode'] ?? '');
    $name = cleanInput($_POST['name'] ?? '');
    $description = cleanInput($_POST['description'] ?? '');
    $categoryId = intval($_POST['category_id'] ?? 0);
    $costPrice = floatval($_POST['cost_price'] ?? 0);
    $sellingPrice = floatval($_POST['selling_price'] ?? 0);
    $taxRate = floatval($_POST['tax_rate'] ?? DEFAULT_TAX_RATE);
    $quantity = intval($_POST['quantity'] ?? 0);
    $minStockLevel = intval($_POST['min_stock_level'] ?? 0);
    $unit = cleanInput($_POST['unit'] ?? 'pieces');
    $hasVariants = isset($_POST['has_variants']) ? 1 : 0;
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    if ($selectedVendorId <= 0) {
        $errors[] = 'Please select a vendor.';
    }
    if ($sku === '') {
        $errors[] = 'SKU is required.';
    }
    if ($name === '') {
        $errors[] = 'Product name is required.';
    }
    if ($sellingPrice < 0) {
        $errors[] = 'Selling price must be a valid number.';
    }
    if ($quantity < 0) {
        $errors[] = 'Quantity must not be negative.';
    }

    if (empty($errors) && $db->exists('products', 'vendor_id = ? AND sku = ? AND id != ?', [$selectedVendorId, $sku, $productId])) {
        $errors[] = 'A product with this SKU already exists for the selected vendor.';
    }

    if (empty($errors)) {
        $updated = $db->execute(
            "UPDATE products SET sku = ?, barcode = ?, name = ?, description = ?, vendor_id = ?, category_id = ?, cost_price = ?, selling_price = ?, tax_rate = ?, quantity = ?, min_stock_level = ?, unit = ?, has_variants = ?, is_active = ?, updated_at = NOW() WHERE id = ?",
            [$sku, $barcode, $name, $description, $selectedVendorId, $categoryId ?: null, $costPrice, $sellingPrice, $taxRate, $quantity, $minStockLevel, $unit, $hasVariants, $isActive, $productId]
        );

        if ($updated !== false) {
            auth()->logActivity('update', 'products', "Updated product: {$name}");
            setFlash('success', 'Product updated successfully.');
            redirect(APP_URL . '/modules/products/view.php?id=' . $productId);
        }

        $errors[] = 'Unable to update product. Please try again.';
    }
}

$pageTitle = 'Edit Product';
?>

<div class="max-w-4xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="index.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">Edit Product</h2>
            <p class="text-sm text-gray-500">Update product details and inventory settings.</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php foreach ($errors as $error): ?>
            <li><?php echo sanitize($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php echo csrfField(); ?>
        <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <?php if ($isAdmin): ?>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Vendor *</label>
                <select name="vendor_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Vendor --</option>
                    <?php foreach ($vendors as $vendor): ?>
                    <option value="<?php echo $vendor['id']; ?>" <?php echo intval($_POST['vendor_id'] ?? $product['vendor_id']) === intval($vendor['id']) ? 'selected' : ''; ?>>
                        <?php echo sanitize($vendor['business_name']); ?> (<?php echo sanitize($vendor['vendor_code']); ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">SKU *</label>
                <input type="text" name="sku" required value="<?php echo sanitize($_POST['sku'] ?? $product['sku']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Barcode</label>
                <input type="text" name="barcode" value="<?php echo sanitize($_POST['barcode'] ?? $product['barcode']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Name *</label>
                <input type="text" name="name" required value="<?php echo sanitize($_POST['name'] ?? $product['name']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
                <textarea name="description" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"><?php echo sanitize($_POST['description'] ?? $product['description']); ?></textarea>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Category</label>
                <select name="category_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Category --</option>
                    <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['id']; ?>" <?php echo intval($_POST['category_id'] ?? $product['category_id']) === intval($category['id']) ? 'selected' : ''; ?>><?php echo sanitize($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Unit</label>
                <select name="unit" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <?php foreach (['pieces' => 'Pieces', 'kg' => 'Kilograms', 'liters' => 'Liters', 'meters' => 'Meters', 'boxes' => 'Boxes', 'bunches' => 'Bunches', 'bags' => 'Bags', 'bundles' => 'Bundles'] as $value => $label): ?>
                    <option value="<?php echo $value; ?>" <?php echo ($_POST['unit'] ?? $product['unit']) === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Cost Price (UGX)</label>
                <input type="number" name="cost_price" min="0" step="100" value="<?php echo sanitize($_POST['cost_price'] ?? $product['cost_price']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Selling Price (UGX) *</label>
                <input type="number" name="selling_price" min="0" step="100" required value="<?php echo sanitize($_POST['selling_price'] ?? $product['selling_price']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Tax Rate (%)</label>
                <input type="number" name="tax_rate" min="0" step="0.01" value="<?php echo sanitize($_POST['tax_rate'] ?? $product['tax_rate']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Quantity</label>
                <input type="number" name="quantity" min="0" step="1" value="<?php echo sanitize($_POST['quantity'] ?? $product['quantity']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Min Stock Level</label>
                <input type="number" name="min_stock_level" min="0" step="1" value="<?php echo sanitize($_POST['min_stock_level'] ?? $product['min_stock_level']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div class="md:col-span-2 flex items-center space-x-4">
                <label class="inline-flex items-center gap-2 text-sm text-gray-700">
                    <input type="checkbox" name="has_variants" value="1" <?php echo (isset($_POST['has_variants']) || (!isset($_POST['has_variants']) && $product['has_variants'])) ? 'checked' : ''; ?> class="h-4 w-4 text-emerald-600 border-gray-300 rounded">
                    Has variants
                </label>
                <label class="inline-flex items-center gap-2 text-sm text-gray-700">
                    <input type="checkbox" name="is_active" value="1" <?php echo (isset($_POST['is_active']) ? 'checked' : ($product['is_active'] ? 'checked' : '')); ?> class="h-4 w-4 text-emerald-600 border-gray-300 rounded">
                    Active product
                </label>
            </div>
        </div>

        <div class="p-6 border-t border-gray-100 text-right">
            <button type="submit" class="inline-flex items-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('check', 4, 'mr-2'); ?> Update Product
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>