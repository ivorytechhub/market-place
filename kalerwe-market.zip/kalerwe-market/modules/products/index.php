<?php
/**
 * Kalerwe Market - Product Catalog Module
 * 
 * Manage products with SKU, barcode, pricing, stock levels, and variants.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('product.view_own');

$pageTitle = 'Products';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

$search = $_GET['search'] ?? '';
$categoryFilter = $_GET['category'] ?? '';
$stockFilter = $_GET['stock'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

$params = [];
$where = ["p.is_active = 1"];

if (!$isAdmin && $vendorId) {
    $where[] = "p.vendor_id = ?";
    $params[] = $vendorId;
}

if ($search) {
    $where[] = "(p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)";
    $s = "%{$search}%";
    $params = array_merge($params, [$s, $s, $s]);
}

if ($categoryFilter) {
    $where[] = "p.category_id = ?";
    $params[] = $categoryFilter;
}

if ($stockFilter === 'low') {
    $where[] = "p.quantity <= p.min_stock_level";
} elseif ($stockFilter === 'out') {
    $where[] = "p.quantity = 0";
}

$whereSql = implode(' AND ', $where);

$products = $db->paginate(
    "SELECT p.*, c.name as category_name, v.business_name, v.stall_number,
            (SELECT COALESCE(SUM(quantity), 0) FROM transaction_items ti JOIN sales_transactions st ON ti.transaction_id = st.id WHERE ti.product_id = p.id AND MONTH(st.created_at) = MONTH(CURDATE())) as monthly_sales_qty
     FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     LEFT JOIN vendors v ON p.vendor_id = v.id
     WHERE {$whereSql}
     ORDER BY p.name ASC",
    $params, $page
);

$categories = $db->fetchAll("SELECT id, name FROM categories WHERE is_active = 1 ORDER BY name");

// Stats
$totalProducts = $db->count('products', $isAdmin ? 'is_active = 1' : 'vendor_id = ? AND is_active = 1', $isAdmin ? [] : [$vendorId]);
$lowStock = $db->count('products', ($isAdmin ? '' : 'vendor_id = ? AND ') . 'quantity <= min_stock_level AND is_active = 1', $isAdmin ? [] : [$vendorId]);
$outOfStock = $db->count('products', ($isAdmin ? '' : 'vendor_id = ? AND ') . 'quantity = 0 AND is_active = 1', $isAdmin ? [] : [$vendorId]);
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Product Catalog</h2>
        <p class="text-sm text-gray-500 mt-1">Manage your products and inventory</p>
    </div>
    <?php if (auth()->hasPermission('product.create')): ?>
    <a href="create.php" class="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
        <?php echo icon('plus', 4, 'mr-2'); ?> Add Product
    </a>
    <?php endif; ?>
</div>

<!-- Stats Cards -->
<div class="grid grid-cols-3 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Total Products</p>
        <p class="text-xl font-bold text-blue-600"><?php echo $totalProducts; ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Low Stock</p>
        <p class="text-xl font-bold text-orange-600"><?php echo $lowStock; ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Out of Stock</p>
        <p class="text-xl font-bold text-red-600"><?php echo $outOfStock; ?></p>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="flex flex-col lg:flex-row gap-3">
        <div class="flex-1 relative">
            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <?php echo icon('search', 4, 'text-gray-400'); ?>
            </div>
            <input type="text" name="search" value="<?php echo sanitize($search); ?>" placeholder="Search products..." class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
        </div>
        <select name="category" onchange="this.form.submit()" class="lg:w-44 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
            <option value="<?php echo $cat['id']; ?>" <?php echo $categoryFilter == $cat['id'] ? 'selected' : ''; ?>><?php echo sanitize($cat['name']); ?></option>
            <?php endforeach; ?>
        </select>
        <select name="stock" onchange="this.form.submit()" class="lg:w-40 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            <option value="">All Stock</option>
            <option value="low" <?php echo $stockFilter === 'low' ? 'selected' : ''; ?>>Low Stock</option>
            <option value="out" <?php echo $stockFilter === 'out' ? 'selected' : ''; ?>>Out of Stock</option>
        </select>
        <button type="submit" class="px-6 py-2.5 bg-gray-800 text-white rounded-lg text-sm font-medium hover:bg-gray-900 transition touch-target">Filter</button>
        <?php if ($search || $categoryFilter || $stockFilter): ?>
        <a href="?" class="px-6 py-2.5 border border-gray-300 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-50 transition text-center touch-target">Clear</a>
        <?php endif; ?>
    </form>
</div>

<!-- Products Table -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Product</th>
                    <?php if ($isAdmin): ?><th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th><?php endif; ?>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">SKU</th>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Price</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Stock</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Status</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($products['data'] as $product): 
                    $stockPercent = min(100, ($product['quantity'] / max(1, $product['min_stock_level'])) * 100);
                    $stockColor = $stockPercent <= 25 ? 'text-red-600 bg-red-50' : ($stockPercent <= 50 ? 'text-orange-600 bg-orange-50' : 'text-green-600 bg-green-50');
                    $isLowStock = $product['quantity'] <= $product['min_stock_level'];
                ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4">
                        <div class="flex items-center space-x-3">
                            <div class="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                <span class="text-xs font-bold text-gray-600"><?php echo strtoupper(substr($product['name'], 0, 2)); ?></span>
                            </div>
                            <div>
                                <p class="font-medium text-gray-800"><?php echo sanitize($product['name']); ?></p>
                                <p class="text-xs text-gray-500"><?php echo sanitize($product['category_name'] ?? 'Uncategorized'); ?></p>
                            </div>
                        </div>
                    </td>
                    <?php if ($isAdmin): ?>
                    <td class="py-3 px-4 text-gray-600"><?php echo sanitize($product['business_name'] ?? 'N/A'); ?></td>
                    <?php endif; ?>
                    <td class="py-3 px-4 font-mono text-gray-600"><?php echo sanitize($product['sku']); ?></td>
                    <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($product['selling_price']); ?></td>
                    <td class="py-3 px-4 text-center">
                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium <?php echo $stockColor; ?>">
                            <?php echo $product['quantity']; ?> <?php echo $product['unit']; ?>
                        </span>
                    </td>
                    <td class="py-3 px-4 text-center"><?php echo $isLowStock ? statusBadge('low') : statusBadge('active'); ?></td>
                    <td class="py-3 px-4">
                        <div class="flex items-center justify-center space-x-1">
                            <a href="view.php?id=<?php echo $product['id']; ?>" class="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition touch-target"><?php echo icon('eye', 4); ?></a>
                            <a href="edit.php?id=<?php echo $product['id']; ?>" class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition touch-target"><?php echo icon('edit', 4); ?></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($products['data'])): ?>
                <tr><td colspan="<?php echo $isAdmin ? 7 : 6; ?>" class="py-12 text-center text-gray-400">No products found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php 
$paginationBase = '?' . http_build_query(array_filter(['search' => $search, 'category' => $categoryFilter, 'stock' => $stockFilter]));
echo renderPagination($products, $paginationBase); 
?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
