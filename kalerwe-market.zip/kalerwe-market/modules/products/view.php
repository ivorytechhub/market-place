<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('product.view_own');

$pageTitle = 'Product Details';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();
$id = intval($_GET['id'] ?? 0);

if (!$id) {
    setFlash('error', 'Invalid product ID.');
    redirect(APP_URL . '/modules/products/index.php');
}

$product = $db->fetchOne(
    "SELECT p.*, c.name as category_name, v.business_name, v.stall_number FROM products p LEFT JOIN categories c ON p.category_id = c.id LEFT JOIN vendors v ON p.vendor_id = v.id WHERE p.id = ?",
    [$id]
);

if (!$product) {
    setFlash('error', 'Product not found.');
    redirect(APP_URL . '/modules/products/index.php');
}

if (!$isAdmin && $product['vendor_id'] !== $vendorId) {
    setFlash('error', 'You do not have permission to view this product.');
    redirect(APP_URL . '/modules/products/index.php');
}
?>

<div class="max-w-4xl mx-auto">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-gray-800"><?php echo sanitize($product['name']); ?></h2>
            <p class="text-sm text-gray-500 mt-1">Product details and inventory summary.</p>
        </div>
        <div class="flex items-center gap-2">
            <a href="edit.php?id=<?php echo $product['id']; ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('edit', 4, 'mr-2'); ?> Edit
            </a>
            <a href="index.php" class="inline-flex items-center px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('arrow-left', 4, 'mr-2'); ?> Back to List
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <p class="text-sm text-gray-500 mb-3">Identification</p>
            <div class="space-y-3 text-sm text-gray-700">
                <div><span class="font-medium">SKU:</span> <?php echo sanitize($product['sku']); ?></div>
                <div><span class="font-medium">Barcode:</span> <?php echo sanitize($product['barcode'] ?: 'N/A'); ?></div>
                <div><span class="font-medium">Category:</span> <?php echo sanitize($product['category_name'] ?: 'Uncategorized'); ?></div>
                <div><span class="font-medium">Vendor:</span> <?php echo sanitize($product['business_name'] ?? 'N/A'); ?></div>
                <div><span class="font-medium">Stall:</span> <?php echo sanitize($product['stall_number'] ?? 'N/A'); ?></div>
                <div><span class="font-medium">Status:</span> <?php echo statusBadge($product['is_active'] ? 'active' : 'inactive'); ?></div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 lg:col-span-2">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div class="bg-gray-50 rounded-2xl p-4">
                    <p class="text-xs uppercase tracking-wide text-gray-500 mb-2">Selling Price</p>
                    <p class="text-2xl font-bold text-emerald-600"><?php echo formatCurrency($product['selling_price']); ?></p>
                </div>
                <div class="bg-gray-50 rounded-2xl p-4">
                    <p class="text-xs uppercase tracking-wide text-gray-500 mb-2">Stock</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $product['quantity']; ?> <?php echo sanitize($product['unit']); ?></p>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 text-sm text-gray-700">
                <div class="bg-white border border-gray-100 rounded-xl p-4">
                    <p class="text-xs text-gray-500 mb-2">Cost Price</p>
                    <p class="font-medium"><?php echo formatCurrency($product['cost_price']); ?></p>
                </div>
                <div class="bg-white border border-gray-100 rounded-xl p-4">
                    <p class="text-xs text-gray-500 mb-2">Tax Rate</p>
                    <p class="font-medium"><?php echo sanitize($product['tax_rate']); ?>%</p>
                </div>
                <div class="bg-white border border-gray-100 rounded-xl p-4">
                    <p class="text-xs text-gray-500 mb-2">Min Stock Level</p>
                    <p class="font-medium"><?php echo sanitize($product['min_stock_level']); ?></p>
                </div>
                <div class="bg-white border border-gray-100 rounded-xl p-4">
                    <p class="text-xs text-gray-500 mb-2">Has Variants</p>
                    <p class="font-medium"><?php echo $product['has_variants'] ? 'Yes' : 'No'; ?></p>
                </div>
            </div>

            <div class="bg-white border border-gray-100 rounded-xl p-6">
                <h3 class="text-sm font-semibold text-gray-800 mb-3">Description</h3>
                <p class="text-sm text-gray-600 leading-relaxed"><?php echo sanitize($product['description'] ?: 'No description available.'); ?></p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
