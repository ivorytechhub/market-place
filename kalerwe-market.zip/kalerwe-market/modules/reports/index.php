<?php
/**
 * Kalerwe Market - Reporting & Analytics Module
 * 
 * Comprehensive reports: sales, inventory, financial, with visual charts.
 * Supports date range filtering and data export.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('report.view_own');

$pageTitle = 'Reports';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

$reportType = $_GET['type'] ?? 'sales';
$dateFrom = $_GET['date_from'] ?? date('Y-m-01');
$dateTo = $_GET['date_to'] ?? date('Y-m-t');

$vendorFilter = $isAdmin ? '' : ($vendorId ? "AND vendor_id = {$vendorId}" : 'AND 1=0');

// Sales Report Data
if ($reportType === 'sales') {
    // Daily sales in range
    $dailySales = $db->fetchAll(
        "SELECT DATE(created_at) as date, COALESCE(SUM(net_amount), 0) as total, COUNT(*) as transactions
         FROM sales_transactions 
         WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed' {$vendorFilter}
         GROUP BY DATE(created_at) ORDER BY date",
        [$dateFrom, $dateTo]
    );
    
    // Payment method breakdown
    $paymentBreakdown = $db->fetchAll(
        "SELECT payment_method, COALESCE(SUM(net_amount), 0) as total, COUNT(*) as count
         FROM sales_transactions 
         WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed' {$vendorFilter}
         GROUP BY payment_method",
        [$dateFrom, $dateTo]
    );
    
    // Top products
    $topProducts = $db->fetchAll(
        "SELECT p.name, SUM(ti.quantity) as qty, SUM(ti.total_amount) as revenue
         FROM transaction_items ti
         JOIN products p ON ti.product_id = p.id
         JOIN sales_transactions st ON ti.transaction_id = st.id
         WHERE DATE(st.created_at) BETWEEN ? AND ? AND st.status = 'completed' " . ($isAdmin ? "" : "AND st.vendor_id = {$vendorId}") . "
         GROUP BY p.id ORDER BY revenue DESC LIMIT 10",
        [$dateFrom, $dateTo]
    );
    
    $totalSales = array_sum(array_column($dailySales, 'total'));
    $totalTransactions = array_sum(array_column($dailySales, 'transactions'));
    $avgTransaction = $totalTransactions > 0 ? $totalSales / $totalTransactions : 0;
}

// Financial Report
if ($reportType === 'financial') {
    $totalRevenue = $db->fetchOne("SELECT COALESCE(SUM(net_amount), 0) as total FROM sales_transactions WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed' {$vendorFilter}", [$dateFrom, $dateTo])['total'] ?? 0;
    $totalExpenses = $db->fetchOne("SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE expense_date BETWEEN ? AND ? " . ($isAdmin ? "" : "AND vendor_id = {$vendorId}"), [$dateFrom, $dateTo])['total'] ?? 0;
    $totalTax = $db->fetchOne("SELECT COALESCE(SUM(tax_amount), 0) as total FROM sales_transactions WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed' {$vendorFilter}", [$dateFrom, $dateTo])['total'] ?? 0;
    
    // Expense breakdown
    $expenseBreakdown = $db->fetchAll(
        "SELECT ec.name, COALESCE(SUM(e.amount), 0) as total
         FROM expenses e
         JOIN expense_categories ec ON e.category_id = ec.id
         WHERE e.expense_date BETWEEN ? AND ? " . ($isAdmin ? "" : "AND e.vendor_id = {$vendorId}") . "
         GROUP BY ec.id ORDER BY total DESC",
        [$dateFrom, $dateTo]
    );
}
?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Reports & Analytics</h2>
        <p class="text-sm text-gray-500 mt-1">View detailed business reports and insights</p>
    </div>
</div>

<!-- Report Type Tabs -->
<div class="flex flex-wrap gap-2 mb-6">
    <a href="?type=sales&date_from=<?php echo $dateFrom; ?>&date_to=<?php echo $dateTo; ?>" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo $reportType === 'sales' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>"><?php echo icon('shopping-cart', 4, 'mr-1.5 inline'); ?> Sales</a>
    <a href="?type=financial&date_from=<?php echo $dateFrom; ?>&date_to=<?php echo $dateTo; ?>" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo $reportType === 'financial' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>"><?php echo icon('banknote', 4, 'mr-1.5 inline'); ?> Financial</a>
    <a href="?type=inventory&date_from=<?php echo $dateFrom; ?>&date_to=<?php echo $dateTo; ?>" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo $reportType === 'inventory' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>"><?php echo icon('warehouse', 4, 'mr-1.5 inline'); ?> Inventory</a>
</div>

<!-- Date Filter -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="flex flex-col sm:flex-row gap-3">
        <input type="hidden" name="type" value="<?php echo $reportType; ?>">
        <div class="flex items-center space-x-2">
            <label class="text-sm text-gray-600">From:</label>
            <input type="date" name="date_from" value="<?php echo sanitize($dateFrom); ?>" class="px-4 py-2 border border-gray-300 rounded-lg text-sm">
        </div>
        <div class="flex items-center space-x-2">
            <label class="text-sm text-gray-600">To:</label>
            <input type="date" name="date_to" value="<?php echo sanitize($dateTo); ?>" class="px-4 py-2 border border-gray-300 rounded-lg text-sm">
        </div>
        <button type="submit" class="px-6 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition touch-target">Generate Report</button>
    </form>
</div>

<?php if ($reportType === 'sales'): ?>
<!-- SALES REPORT -->
<div class="grid grid-cols-3 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Total Revenue</p>
        <p class="text-xl font-bold text-emerald-600"><?php echo formatCurrency($totalSales); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Transactions</p>
        <p class="text-xl font-bold text-blue-600"><?php echo formatNumber($totalTransactions); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Avg. Transaction</p>
        <p class="text-xl font-bold text-purple-600"><?php echo formatCurrency($avgTransaction); ?></p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Daily Sales Trend</h3>
        <div class="h-64">
            <canvas id="salesTrendChart"></canvas>
        </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Payment Method Breakdown</h3>
        <div class="h-48">
            <canvas id="paymentChart"></canvas>
        </div>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
    <h3 class="text-lg font-semibold text-gray-800 mb-4">Top Selling Products</h3>
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead><tr class="border-b border-gray-200"><th class="text-left py-2 px-3">Product</th><th class="text-right py-2 px-3">Qty Sold</th><th class="text-right py-2 px-3">Revenue</th></tr></thead>
            <tbody>
                <?php foreach ($topProducts as $p): ?>
                <tr class="border-b border-gray-50"><td class="py-2 px-3"><?php echo sanitize($p['name']); ?></td><td class="py-2 px-3 text-right"><?php echo $p['qty']; ?></td><td class="py-2 px-3 text-right font-medium"><?php echo formatCurrency($p['revenue']); ?></td></tr>
                <?php endforeach; ?>
                <?php if (empty($topProducts)): ?><tr><td colspan="3" class="py-8 text-center text-gray-400">No data</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
const salesCtx = document.getElementById('salesTrendChart').getContext('2d');
new Chart(salesCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_map(fn($d) => date('M d', strtotime($d['date'])), $dailySales)); ?>,
        datasets: [{
            label: 'Sales',
            data: <?php echo json_encode(array_map('floatval', array_column($dailySales, 'total'))); ?>,
            backgroundColor: '#059669',
            borderRadius: 4
        }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { callback: v => 'UGX ' + v.toLocaleString() } } } }
});

const payCtx = document.getElementById('paymentChart').getContext('2d');
new Chart(payCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_map(fn($p) => ucfirst(str_replace('_', ' ', $p['payment_method'])), $paymentBreakdown)); ?>,
        datasets: [{ data: <?php echo json_encode(array_map('floatval', array_column($paymentBreakdown, 'total'))); ?>, backgroundColor: ['#059669', '#3b82f6', '#f59e0b'] }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, cutout: '60%' }
});
</script>

<?php elseif ($reportType === 'financial'): ?>
<!-- FINANCIAL REPORT -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Revenue</p>
        <p class="text-xl font-bold text-emerald-600"><?php echo formatCurrency($totalRevenue); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Expenses</p>
        <p class="text-xl font-bold text-red-600"><?php echo formatCurrency($totalExpenses); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Net Profit</p>
        <p class="text-xl font-bold text-blue-600"><?php echo formatCurrency($totalRevenue - $totalExpenses); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Tax Collected</p>
        <p class="text-xl font-bold text-purple-600"><?php echo formatCurrency($totalTax); ?></p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Expense Breakdown</h3>
        <div class="h-64">
            <canvas id="expenseChart"></canvas>
        </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Profit Summary</h3>
        <div class="space-y-4">
            <div class="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
                <span class="text-sm text-emerald-800">Total Revenue</span>
                <span class="font-bold text-emerald-700"><?php echo formatCurrency($totalRevenue); ?></span>
            </div>
            <div class="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                <span class="text-sm text-red-800">Total Expenses</span>
                <span class="font-bold text-red-700">-<?php echo formatCurrency($totalExpenses); ?></span>
            </div>
            <div class="border-t-2 border-gray-200 pt-3 flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span class="text-sm font-medium text-blue-800">Net Profit/Loss</span>
                <span class="font-bold text-blue-700"><?php echo formatCurrency($totalRevenue - $totalExpenses); ?></span>
            </div>
            <div class="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span class="text-sm text-purple-800">Tax Collected</span>
                <span class="font-bold text-purple-700"><?php echo formatCurrency($totalTax); ?></span>
            </div>
        </div>
    </div>
</div>

<script>
const expCtx = document.getElementById('expenseChart').getContext('2d');
new Chart(expCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_column($expenseBreakdown, 'name')); ?>,
        datasets: [{ data: <?php echo json_encode(array_map('floatval', array_column($expenseBreakdown, 'total'))); ?>, backgroundColor: ['#ef4444', '#f97316', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#6b7280'] }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, cutout: '60%' }
});
</script>

<?php else: ?>
<!-- INVENTORY REPORT -->
<?php
$inventoryValue = $db->fetchAll("SELECT c.name as category, COALESCE(SUM(p.quantity * p.cost_price), 0) as value, COALESCE(SUM(p.quantity), 0) as qty, COUNT(*) as products FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1 " . ($isAdmin ? "" : "AND p.vendor_id = {$vendorId}") . " GROUP BY c.id ORDER BY value DESC");
$totalInvValue = array_sum(array_column($inventoryValue, 'value'));
?>
<div class="grid grid-cols-2 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Total Inventory Value</p>
        <p class="text-xl font-bold text-emerald-600"><?php echo formatCurrency($totalInvValue); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Categories</p>
        <p class="text-xl font-bold text-blue-600"><?php echo count($inventoryValue); ?></p>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
    <h3 class="text-lg font-semibold text-gray-800 mb-4">Inventory Value by Category</h3>
    <div class="h-64">
        <canvas id="invChart"></canvas>
    </div>
    <div class="table-wrapper mt-4">
        <table class="w-full text-sm">
            <thead><tr class="border-b border-gray-200"><th class="text-left py-2 px-3">Category</th><th class="text-right py-2 px-3">Products</th><th class="text-right py-2 px-3">Quantity</th><th class="text-right py-2 px-3">Value</th></tr></thead>
            <tbody>
                <?php foreach ($inventoryValue as $inv): ?>
                <tr class="border-b border-gray-50"><td class="py-2 px-3"><?php echo sanitize($inv['category'] ?? 'Uncategorized'); ?></td><td class="py-2 px-3 text-right"><?php echo $inv['products']; ?></td><td class="py-2 px-3 text-right"><?php echo formatNumber($inv['qty']); ?></td><td class="py-2 px-3 text-right font-medium"><?php echo formatCurrency($inv['value']); ?></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
new Chart(document.getElementById('invChart').getContext('2d'), {
    type: 'bar',
    data: { labels: <?php echo json_encode(array_column($inventoryValue, 'category')); ?>, datasets: [{ label: 'Value', data: <?php echo json_encode(array_map('floatval', array_column($inventoryValue, 'value'))); ?>, backgroundColor: '#059669', borderRadius: 4 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { callback: v => 'UGX ' + v.toLocaleString() } } } }
});
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
