<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requireRole('admin');

$pageTitle = 'Record Contribution';
$db = getDB();
$vendors = $db->fetchAll("SELECT id, business_name, vendor_code FROM vendors WHERE status = 'active' ORDER BY business_name");
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }

    $vendorId = intval($_POST['vendor_id'] ?? 0);
    $amount = floatval($_POST['amount'] ?? 0);
    $contributionDate = cleanInput($_POST['contribution_date'] ?? date('Y-m-d'));
    $paymentMethod = cleanInput($_POST['payment_method'] ?? 'cash');
    $receiptNumber = cleanInput($_POST['receipt_number'] ?? '');
    $status = cleanInput($_POST['status'] ?? 'pending');
    $notes = cleanInput($_POST['notes'] ?? '');

    if ($vendorId <= 0) {
        $errors[] = 'Please select a vendor.';
    }
    if ($amount <= 0) {
        $errors[] = 'Amount must be greater than zero.';
    }
    if (!validDate($contributionDate)) {
        $errors[] = 'Please enter a valid contribution date.';
    }

    if (empty($errors)) {
        $insertId = $db->insert(
            "INSERT INTO member_contributions (vendor_id, amount, contribution_date, payment_method, receipt_number, status, notes, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
            [$vendorId, $amount, $contributionDate, $paymentMethod, $receiptNumber, $status, $notes, auth()->getUserId()]
        );

        if ($insertId) {
            auth()->logActivity('create', 'contributions', "Recorded contribution for vendor ID {$vendorId}");
            setFlash('success', 'Contribution recorded successfully.');
            redirect(APP_URL . '/modules/contributions/index.php');
        }

        $errors[] = 'Unable to save contribution. Please try again.';
    }
}
?>

<div class="max-w-3xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="index.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">Record Member Contribution</h2>
            <p class="text-sm text-gray-500">Capture association dues and contribution payments.</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php foreach ($errors as $error): ?>
            <li><?php echo sanitize($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php echo csrfField(); ?>
        <div class="p-6 grid grid-cols-1 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Vendor *</label>
                <select name="vendor_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Vendor --</option>
                    <?php foreach ($vendors as $vendor): ?>
                    <option value="<?php echo $vendor['id']; ?>" <?php echo (intval($_POST['vendor_id'] ?? 0) === intval($vendor['id'])) ? 'selected' : ''; ?>>
                        <?php echo sanitize($vendor['business_name']); ?> (<?php echo sanitize($vendor['vendor_code']); ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Amount (UGX) *</label>
                    <input type="number" name="amount" min="0" step="100" required value="<?php echo sanitize($_POST['amount'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Contribution Date *</label>
                    <input type="date" name="contribution_date" required value="<?php echo sanitize($_POST['contribution_date'] ?? date('Y-m-d')); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Payment Method</label>
                    <select name="payment_method" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <?php foreach (['cash' => 'Cash', 'mobile_money' => 'Mobile Money', 'bank_transfer' => 'Bank Transfer'] as $value => $label): ?>
                        <option value="<?php echo $value; ?>" <?php echo ($_POST['payment_method'] ?? 'cash') === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <?php foreach (['pending' => 'Pending', 'confirmed' => 'Confirmed', 'rejected' => 'Rejected'] as $value => $label): ?>
                        <option value="<?php echo $value; ?>" <?php echo ($_POST['status'] ?? 'pending') === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Receipt Number</label>
                <input type="text" name="receipt_number" value="<?php echo sanitize($_POST['receipt_number'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="Receipt or reference number">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Notes</label>
                <textarea name="notes" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"><?php echo sanitize($_POST['notes'] ?? ''); ?></textarea>
            </div>
        </div>

        <div class="p-6 border-t border-gray-100 text-right">
            <button type="submit" class="inline-flex items-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('plus', 4, 'mr-2'); ?> Save Contribution
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
