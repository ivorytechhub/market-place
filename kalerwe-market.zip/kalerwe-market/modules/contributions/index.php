<?php
/**
 * Kalerwe Market - Member Contributions/Dues Module
 * 
 * Track monthly association dues and contributions from vendors.
 * Admin-only module for managing membership fees.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requireRole('admin');

$pageTitle = 'Member Contributions';
$db = getDB();

$statusFilter = $_GET['status'] ?? '';
$monthFilter = $_GET['month'] ?? date('Y-m');
$page = max(1, intval($_GET['page'] ?? 1));

$params = [];
$where = ['1=1'];
if ($statusFilter) {
    $where[] = "mc.status = ?";
    $params[] = $statusFilter;
}
if ($monthFilter) {
    $where[] = "DATE_FORMAT(mc.contribution_date, '%Y-%m') = ?";
    $params[] = $monthFilter;
}

$whereSql = implode(' AND ', $where);

$contributions = $db->paginate(
    "SELECT mc.*, v.business_name, v.stall_number, v.vendor_code, u.full_name as recorded_by_name
     FROM member_contributions mc
     LEFT JOIN vendors v ON mc.vendor_id = v.id
     LEFT JOIN users u ON mc.recorded_by = u.id
     WHERE {$whereSql}
     ORDER BY mc.contribution_date DESC",
    $params, $page
);

// Summary stats for current month
$monthTotal = $db->fetchOne("SELECT COALESCE(SUM(amount), 0) as total FROM member_contributions WHERE DATE_FORMAT(contribution_date, '%Y-%m') = ? AND status = 'confirmed'", [$monthFilter])['total'] ?? 0;
$pendingCount = $db->count('member_contributions', "DATE_FORMAT(contribution_date, '%Y-%m') = ? AND status = 'pending'", [$monthFilter]);
$totalVendors = $db->count('vendors', "status = 'active'");
$paidCount = $db->fetchOne("SELECT COUNT(DISTINCT vendor_id) as count FROM member_contributions WHERE DATE_FORMAT(contribution_date, '%Y-%m') = ? AND status = 'confirmed'", [$monthFilter])['count'] ?? 0;
$unpaidCount = max(0, $totalVendors - $paidCount);
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Member Contributions</h2>
        <p class="text-sm text-gray-500 mt-1">Track association dues and membership fees</p>
    </div>
    <a href="create.php" class="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
        <?php echo icon('plus', 4, 'mr-2'); ?> Record Contribution
    </a>
</div>

<!-- Summary Cards -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Month Total</p>
        <p class="text-xl font-bold text-emerald-600"><?php echo formatCurrency($monthTotal); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Paid</p>
        <p class="text-xl font-bold text-green-600"><?php echo $paidCount; ?>/<?php echo $totalVendors; ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Unpaid</p>
        <p class="text-xl font-bold text-red-600"><?php echo $unpaidCount; ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Pending</p>
        <p class="text-xl font-bold text-orange-600"><?php echo $pendingCount; ?></p>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="flex flex-col lg:flex-row gap-3">
        <input type="month" name="month" value="<?php echo sanitize($monthFilter); ?>" class="lg:w-44 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" onchange="this.form.submit()">
        <select name="status" onchange="this.form.submit()" class="lg:w-40 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            <option value="">All Status</option>
            <option value="confirmed" <?php echo $statusFilter === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
            <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="rejected" <?php echo $statusFilter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
        </select>
        <button type="submit" class="px-6 py-2.5 bg-gray-800 text-white rounded-lg text-sm font-medium hover:bg-gray-900 transition touch-target">Filter</button>
    </form>
</div>

<!-- Contributions Table -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Amount</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Method</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Status</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Receipt #</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($contributions['data'] as $c): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4">
                        <p class="font-medium text-gray-800"><?php echo sanitize($c['business_name']); ?></p>
                        <p class="text-xs text-gray-500"><?php echo sanitize($c['vendor_code']); ?> | <?php echo sanitize($c['stall_number']); ?></p>
                    </td>
                    <td class="py-3 px-4 text-right font-bold text-emerald-600"><?php echo formatCurrency($c['amount']); ?></td>
                    <td class="py-3 px-4 text-center"><span class="text-xs text-gray-600"><?php echo ucfirst(str_replace('_', ' ', $c['payment_method'])); ?></span></td>
                    <td class="py-3 px-4 text-center"><?php echo statusBadge($c['status']); ?></td>
                    <td class="py-3 px-4 text-gray-600"><?php echo formatDate($c['contribution_date']); ?></td>
                    <td class="py-3 px-4 font-mono text-gray-600"><?php echo sanitize($c['receipt_number'] ?? '-'); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($contributions['data'])): ?>
                <tr><td colspan="6" class="py-12 text-center text-gray-400">No contributions found for this period</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo renderPagination($contributions, '?' . http_build_query(array_filter(['status' => $statusFilter, 'month' => $monthFilter]))); ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
