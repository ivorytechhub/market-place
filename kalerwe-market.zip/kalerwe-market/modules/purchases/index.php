<?php
/**
 * Kalerwe Market - Purchase Order & Supplier Management Module
 * 
 * Create and track purchase orders to suppliers with delivery status.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('po.view_assigned');

$pageTitle = 'Purchase Orders';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

$statusFilter = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

$params = [];
$where = ['1=1'];

if (!$isAdmin && $vendorId) {
    $where[] = "po.vendor_id = ?";
    $params[] = $vendorId;
}
if ($statusFilter) {
    $where[] = "po.status = ?";
    $params[] = $statusFilter;
}

$whereSql = implode(' AND ', $where);

// Get total count
$countSql = "SELECT COUNT(*) as total FROM purchase_orders po WHERE {$whereSql}";
$countResult = $db->fetchOne($countSql, $params);
$total = $countResult ? (int)$countResult['total'] : 0;

// Get data with pagination
$perPage = ITEMS_PER_PAGE;
$offset = ($page - 1) * $perPage;

$sql = "SELECT po.*, 
        v.business_name, 
        v.vendor_code,
        s.company_name as supplier_name, 
        s.phone as supplier_phone,
        s.email as supplier_email
        FROM purchase_orders po
        LEFT JOIN vendors v ON po.vendor_id = v.id
        LEFT JOIN suppliers s ON po.supplier_id = s.id
        WHERE {$whereSql}
        ORDER BY po.created_at DESC
        LIMIT {$perPage} OFFSET {$offset}";

$data = $db->fetchAll($sql, $params);

// Build pagination array
$orders = [
    'data' => $data,
    'total' => $total,
    'page' => $page,
    'per_page' => $perPage,
    'total_pages' => $total > 0 ? ceil($total / $perPage) : 1,
    'has_next' => ($page * $perPage) < $total,
    'has_prev' => $page > 1
];

// Get item count for each order
foreach ($orders['data'] as &$order) {
    $itemCount = $db->fetchOne(
        "SELECT COUNT(*) as count FROM purchase_order_items WHERE po_id = ?",
        [$order['id']]
    );
    $order['item_count'] = $itemCount ? (int)$itemCount['count'] : 0;
}

$suppliers = $db->fetchAll("SELECT id, company_name FROM suppliers WHERE is_active = 1 ORDER BY company_name");

// Stats
$pendingCount = 0;
if ($isAdmin) {
    $pendingCount = $db->count('purchase_orders', "status IN ('draft', 'sent', 'partial')");
} else {
    $pendingCount = $db->count('purchase_orders', "vendor_id = ? AND status IN ('draft', 'sent', 'partial')", [$vendorId]);
}

// Total spent
$totalSpentResult = $db->fetchOne(
    "SELECT COALESCE(SUM(total_amount), 0) as total 
     FROM purchase_orders 
     WHERE " . ($isAdmin ? "1=1" : "vendor_id = ?") . " AND status = 'received'",
    $isAdmin ? [] : [$vendorId]
);
$totalSpent = $totalSpentResult ? $totalSpentResult['total'] : 0;
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Purchase Orders</h2>
        <p class="text-sm text-gray-500 mt-1">Manage supplier orders and deliveries</p>
    </div>
    <a href="create.php" class="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
        <?php echo icon('plus', 4, 'mr-2'); ?> New PO
    </a>
</div>

<!-- Stats -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Pending</p>
        <p class="text-xl font-bold text-orange-600"><?php echo $pendingCount; ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Suppliers</p>
        <p class="text-xl font-bold text-blue-600"><?php echo count($suppliers); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Total Orders</p>
        <p class="text-xl font-bold text-emerald-600"><?php echo $total; ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Total Spent</p>
        <p class="text-xl font-bold text-purple-600"><?php echo formatCurrency($totalSpent); ?></p>
    </div>
</div>

<!-- Filter Tabs -->
<div class="flex flex-wrap gap-2 mb-6">
    <a href="?" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo !$statusFilter ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>">All</a>
    <?php foreach (['draft' => 'Draft', 'sent' => 'Sent', 'partial' => 'Partial', 'received' => 'Received', 'cancelled' => 'Cancelled'] as $val => $label): ?>
    <a href="?status=<?php echo $val; ?>" class="px-4 py-2 rounded-lg text-sm font-medium transition <?php echo $statusFilter === $val ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'; ?>"><?php echo $label; ?></a>
    <?php endforeach; ?>
</div>

<!-- Orders Table -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">PO Number</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Supplier</th>
                    <?php if ($isAdmin): ?><th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th><?php endif; ?>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Items</th>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Total</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Notification</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Status</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Expected</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($orders['data'] as $order): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4 font-medium text-emerald-600"><?php echo sanitize($order['po_number']); ?></td>
                    <td class="py-3 px-4">
                        <p class="text-gray-800"><?php echo sanitize($order['supplier_name'] ?? 'N/A'); ?></p>
                        <p class="text-xs text-gray-500"><?php echo sanitize($order['supplier_phone'] ?? ''); ?></p>
                    </td>
                    <?php if ($isAdmin): ?><td class="py-3 px-4 text-gray-600"><?php echo sanitize($order['business_name'] ?? ''); ?></td><?php endif; ?>
                    <td class="py-3 px-4 text-center"><?php echo $order['item_count'] ?? 0; ?></td>
                    <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($order['total_amount']); ?></td>
                    <td class="py-3 px-4 text-center">
                        <?php if (!empty($order['notification_sent_at'])): ?>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700">
                                <?php echo strtoupper(sanitize($order['notification_channel'] ?? 'email')); ?>
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-600">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 px-4 text-center"><?php echo statusBadge($order['status']); ?></td>
                    <td class="py-3 px-4 text-gray-600"><?php echo $order['expected_delivery'] ? formatDate($order['expected_delivery']) : '-'; ?></td>
                    <td class="py-3 px-4 text-center">
                        <a href="view.php?id=<?php echo $order['id']; ?>" class="inline-flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-xs font-semibold transition">View</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($orders['data'])): ?>
                <tr>
                    <td colspan="<?php echo $isAdmin ? 9 : 8; ?>" class="py-12 text-center text-gray-400">
                        <div class="flex flex-col items-center">
                            <?php echo icon('clipboard-list', 10, 'text-gray-300 mb-3'); ?>
                            <p class="text-lg font-medium text-gray-500">No purchase orders found</p>
                            <p class="text-sm text-gray-400 mt-1">Create your first purchase order to get started.</p>
                            <a href="create.php" class="mt-4 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition">
                                <?php echo icon('plus', 4, 'mr-2'); ?> Create PO
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<?php if (!empty($orders['data'])): ?>
<div class="mt-4">
    <?php 
    $paginationBase = '?' . ($statusFilter ? "status={$statusFilter}&" : '');
    echo renderPagination($orders, $paginationBase); 
    ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>