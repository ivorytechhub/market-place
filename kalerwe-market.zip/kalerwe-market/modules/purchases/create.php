<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requireAuth();

$pageTitle = 'New Purchase Order';
$db = getDB();
$isAdmin = auth()->isAdmin();
$vendorId = auth()->getVendorId();

if (!$isAdmin && !$vendorId) {
    setFlash('error', 'Unable to determine vendor profile.');
    redirect(APP_URL . '/dashboard.php');
}

$suppliers = $db->fetchAll("SELECT id, company_name, email, phone FROM suppliers WHERE is_active = 1 ORDER BY company_name");
$vendors = $isAdmin ? $db->fetchAll("SELECT id, business_name, vendor_code FROM vendors WHERE status = 'active' ORDER BY business_name") : [];
$errors = [];
$showNotification = false;
$notificationData = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }

    $selectedVendorId = $isAdmin ? intval($_POST['vendor_id'] ?? 0) : $vendorId;
    $supplierId = intval($_POST['supplier_id'] ?? 0);
    $poDate = cleanInput($_POST['po_date'] ?? date('Y-m-d'));
    $expectedDelivery = cleanInput($_POST['expected_delivery'] ?? '');
    $status = cleanInput($_POST['status'] ?? 'draft');
    $notes = cleanInput($_POST['notes'] ?? '');
    $notificationChannel = cleanInput($_POST['notification_channel'] ?? 'email');

    $descriptions = $_POST['item_description'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $unitPrices = $_POST['unit_price'] ?? [];

    if ($selectedVendorId <= 0) {
        $errors[] = 'Please select a vendor.';
    }
    if ($supplierId <= 0) {
        $errors[] = 'Please select a supplier.';
    }
    if (!validDate($poDate)) {
        $errors[] = 'Please enter a valid PO date.';
    }
    if ($expectedDelivery && !validDate($expectedDelivery)) {
        $errors[] = 'Please enter a valid expected delivery date.';
    }

    $items = [];
    $totalAmount = 0;

    foreach ($descriptions as $index => $description) {
        $description = cleanInput($description);
        $quantity = floatval($quantities[$index] ?? 0);
        $unitPrice = floatval($unitPrices[$index] ?? 0);

        if ($description === '') {
            continue;
        }
        if ($quantity <= 0) {
            $errors[] = 'Each item must have a quantity greater than zero.';
            break;
        }
        if ($unitPrice < 0) {
            $errors[] = 'Each item must have a valid unit price.';
            break;
        }

        $lineTotal = $quantity * $unitPrice;
        $items[] = [
            'description' => $description,
            'quantity' => $quantity,
            'unit_price' => $unitPrice,
            'total' => $lineTotal
        ];
        $totalAmount += $lineTotal;
    }

    if (empty($items)) {
        $errors[] = 'Please add at least one purchase item.';
    }
    if ($totalAmount <= 0) {
        $errors[] = 'Total order amount must be greater than zero.';
    }

    if (empty($errors)) {
    $poNumber = generatePONumber();
    $poId = $db->insert(
        "INSERT INTO purchase_orders (po_number, vendor_id, supplier_id, po_date, expected_delivery, status, total_amount, tax_amount, notification_channel, notification_sent_at, notes, created_by, created_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?, 0.00, ?, NOW(), ?, ?, NOW())",
        [$poNumber, $selectedVendorId, $supplierId, $poDate, $expectedDelivery ?: null, $status, $totalAmount, $notificationChannel, $notes, auth()->getUserId()]
    );

        if ($poId) {
            foreach ($items as $item) {
                $db->insert(
                    "INSERT INTO purchase_order_items (po_id, product_id, item_description, quantity, unit_price, total_amount) VALUES (?, NULL, ?, ?, ?, ?)",
                    [$poId, $item['description'], $item['quantity'], $item['unit_price'], $item['total']]
                );
            }

            $supplier = $db->fetchOne(
                "SELECT company_name, email, phone FROM suppliers WHERE id = ?",
                [$supplierId]
            );

            auth()->logActivity('create', 'purchases', "Created purchase order: {$poNumber}");
            setFlash('success', 'Purchase order created successfully.');

            $notificationData = [
                'po_number' => $poNumber,
                'supplier_name' => $supplier['company_name'] ?? 'Supplier',
                'channel' => $notificationChannel,
                'contact' => $notificationChannel === 'email' ? ($supplier['email'] ?? 'N/A') : ($supplier['phone'] ?? 'N/A'),
                'items_count' => count($items),
                'total_amount' => $totalAmount
            ];
            $showNotification = true;
        } else {
            $errors[] = 'Unable to save purchase order. Please try again.';
        }
    }
}
?>

<div class="max-w-5xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="index.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">Create Purchase Order</h2>
            <p class="text-sm text-gray-500">Generate a purchase order for supplier procurement.</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php foreach ($errors as $error): ?>
            <li><?php echo sanitize($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" class="space-y-6">
        <?php echo csrfField(); ?>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 grid grid-cols-1 lg:grid-cols-2 gap-4">
            <?php if ($isAdmin): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Vendor *</label>
                <select name="vendor_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Vendor --</option>
                    <?php foreach ($vendors as $vendor): ?>
                    <option value="<?php echo $vendor['id']; ?>" <?php echo intval($_POST['vendor_id'] ?? 0) === intval($vendor['id']) ? 'selected' : ''; ?>>
                        <?php echo sanitize($vendor['business_name']); ?> (<?php echo sanitize($vendor['vendor_code']); ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Supplier *</label>
                <select name="supplier_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Supplier --</option>
                    <?php foreach ($suppliers as $supplier): ?>
                    <option value="<?php echo $supplier['id']; ?>" <?php echo intval($_POST['supplier_id'] ?? 0) === intval($supplier['id']) ? 'selected' : ''; ?>><?php echo sanitize($supplier['company_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">PO Date *</label>
                <input type="date" name="po_date" required value="<?php echo sanitize($_POST['po_date'] ?? date('Y-m-d')); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Expected Delivery</label>
                <input type="date" name="expected_delivery" value="<?php echo sanitize($_POST['expected_delivery'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Status</label>
                <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <?php foreach (['draft' => 'Draft', 'sent' => 'Sent', 'partial' => 'Partial', 'received' => 'Received', 'cancelled' => 'Cancelled'] as $value => $label): ?>
                    <option value="<?php echo $value; ?>" <?php echo ($_POST['status'] ?? 'draft') === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Notify Supplier</h3>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                <label class="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition">
                    <input type="radio" name="notification_channel" value="email" <?php echo ($_POST['notification_channel'] ?? 'email') === 'email' ? 'checked' : ''; ?>>
                    <span><?php echo icon('mail', 4, 'text-emerald-600'); ?> Email</span>
                </label>
                <label class="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition">
                    <input type="radio" name="notification_channel" value="sms" <?php echo ($_POST['notification_channel'] ?? '') === 'sms' ? 'checked' : ''; ?>>
                    <span><?php echo icon('phone', 4, 'text-emerald-600'); ?> SMS</span>
                </label>
                <label class="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition">
                    <input type="radio" name="notification_channel" value="whatsapp" <?php echo ($_POST['notification_channel'] ?? '') === 'whatsapp' ? 'checked' : ''; ?>>
                    <span><?php echo icon('message-circle', 4, 'text-emerald-600'); ?> WhatsApp</span>
                </label>
            </div>
            <p class="text-xs text-gray-500">This is a simulated notification. No email, SMS, or WhatsApp will actually be sent.</p>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Order Items</h3>
            <div id="purchaseItems" class="space-y-4">
                <?php
                $rows = max(1, count($_POST['item_description'] ?? ['']));
                for ($i = 0; $i < $rows; $i++):
                ?>
                <div class="grid grid-cols-1 xl:grid-cols-5 gap-4 items-end border-b border-gray-100 pb-4">
                    <div class="xl:col-span-3">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Item Description</label>
                        <input type="text" name="item_description[]" value="<?php echo sanitize($_POST['item_description'][$i] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="Item description">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Quantity</label>
                        <input type="number" name="quantity[]" min="1" step="1" value="<?php echo sanitize($_POST['quantity'][$i] ?? '1'); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Unit Price</label>
                        <input type="number" name="unit_price[]" min="0" step="100" value="<?php echo sanitize($_POST['unit_price'][$i] ?? '0'); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    </div>
                    <div class="flex items-center justify-end xl:justify-center">
                        <button type="button" onclick="removePurchaseItem(this)" class="px-3 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition touch-target">Remove</button>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
            <button type="button" onclick="addPurchaseItem()" class="mt-4 inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition touch-target">
                <?php echo icon('plus', 4, 'mr-2'); ?> Add Item
            </button>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Notes</label>
            <textarea name="notes" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"><?php echo sanitize($_POST['notes'] ?? ''); ?></textarea>
        </div>

        <div class="text-right">
            <button type="submit" class="inline-flex items-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('plus', 4, 'mr-2'); ?> Create Purchase Order
            </button>
        </div>
    </form>
</div>

<?php if ($showNotification && $notificationData): ?>
<div id="notificationModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
    <div class="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 text-left">
        <div class="text-center mb-4">
            <div class="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <?php echo icon('check-circle', 8, 'text-emerald-600'); ?>
            </div>
            <h3 class="text-xl font-bold text-gray-800">Order Submitted!</h3>
            <p class="text-sm text-gray-500 mt-1">Your purchase order has been submitted to the supplier.</p>
        </div>

        <div class="bg-gray-50 rounded-2xl p-4 mb-4 space-y-3">
            <div class="flex items-center justify-between text-sm text-gray-600">
                <span>PO Number</span>
                <span class="font-semibold text-emerald-600"><?php echo sanitize($notificationData['po_number']); ?></span>
            </div>
            <div class="flex items-center justify-between text-sm text-gray-600">
                <span>Supplier</span>
                <span class="font-medium"><?php echo sanitize($notificationData['supplier_name']); ?></span>
            </div>
            <div class="flex items-center justify-between text-sm text-gray-600">
                <span>Items</span>
                <span class="font-medium"><?php echo $notificationData['items_count']; ?></span>
            </div>
            <div class="flex items-center justify-between text-sm text-gray-600">
                <span>Total</span>
                <span class="font-semibold text-emerald-600"><?php echo formatCurrency($notificationData['total_amount']); ?></span>
            </div>
        </div>

        <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 mb-4">
            <p class="text-sm font-semibold text-emerald-800">Mock Notification Sent</p>
            <p class="text-sm text-emerald-700 mt-2">Your order has been submitted to <strong><?php echo sanitize($notificationData['supplier_name']); ?></strong> via <strong><?php echo strtoupper(sanitize($notificationData['channel'])); ?></strong> (<strong><?php echo sanitize($notificationData['contact']); ?></strong>).</p>
            <p class="text-xs text-emerald-600 italic mt-3">This is a simulated notification. No actual email, SMS, or WhatsApp was sent.</p>
        </div>

        <button type="button" onclick="closeNotification()" class="w-full inline-flex items-center justify-center px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-sm font-medium transition">View Order</button>
    </div>
</div>

<style>
#notificationModal { animation: fadeIn 0.25s ease-in-out; }
@keyframes fadeIn { from { opacity: 0; transform: scale(0.98); } to { opacity: 1; transform: scale(1); } }
</style>

<script>
function closeNotification() {
    window.location.href = '<?php echo APP_URL; ?>/modules/purchases/view.php?id=' + <?php echo intval($notificationData['id']); ?>;
}
setTimeout(function() {
    closeNotification();
}, 6500);
</script>
<?php endif; ?>

<script>
function addPurchaseItem() {
    const container = document.getElementById('purchaseItems');
    const template = document.createElement('div');
    template.className = 'grid grid-cols-1 xl:grid-cols-5 gap-4 items-end border-b border-gray-100 pb-4';
    template.innerHTML = `
        <div class="xl:col-span-3">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Item Description</label>
            <input type="text" name="item_description[]" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="Item description">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Quantity</label>
            <input type="number" name="quantity[]" min="1" step="1" value="1" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Unit Price</label>
            <input type="number" name="unit_price[]" min="0" step="100" value="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
        </div>
        <div class="flex items-center justify-end xl:justify-center">
            <button type="button" onclick="removePurchaseItem(this)" class="px-3 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition touch-target">Remove</button>
        </div>
    `;
    container.appendChild(template);
}

function removePurchaseItem(button) {
    const row = button.closest('div.grid');
    if (row) {
        row.remove();
    }
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
