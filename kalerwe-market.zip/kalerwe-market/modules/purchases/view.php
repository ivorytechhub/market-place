<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('po.view_assigned');

$pageTitle = 'Purchase Order Details';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();
$id = intval($_GET['id'] ?? 0);

if (!$id) {
    setFlash('error', 'Invalid purchase order ID.');
    redirect(APP_URL . '/modules/purchases/index.php');
}

$order = $db->fetchOne(
    "SELECT po.*, v.business_name AS vendor_name, v.vendor_code, s.company_name AS supplier_name, s.phone AS supplier_phone, s.email AS supplier_email
     FROM purchase_orders po
     LEFT JOIN vendors v ON po.vendor_id = v.id
     LEFT JOIN suppliers s ON po.supplier_id = s.id
     WHERE po.id = ?",
    [$id]
);

if (!$order) {
    setFlash('error', 'Purchase order not found.');
    redirect(APP_URL . '/modules/purchases/index.php');
}

if (!$isAdmin && $order['vendor_id'] !== $vendorId) {
    setFlash('error', 'You do not have permission to view this purchase order.');
    redirect(APP_URL . '/modules/purchases/index.php');
}

$items = $db->fetchAll(
    "SELECT * FROM purchase_order_items WHERE po_id = ?",
    [$id]
);

$errors = [];
$successMessage = '';
$allowedStatuses = ['draft', 'sent', 'partial', 'received', 'cancelled'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }

    if (!auth()->hasPermission('po.update_status')) {
        setFlash('error', 'You do not have permission to update purchase order status.');
        redirect(currentUrl());
    }

    $newStatus = cleanInput($_POST['status'] ?? $order['status']);
    if (!in_array($newStatus, $allowedStatuses, true)) {
        $errors[] = 'Please select a valid status.';
    }

    if (empty($errors) && $newStatus !== $order['status']) {
        $updated = $db->execute(
            "UPDATE purchase_orders SET status = ?, updated_at = NOW() WHERE id = ?",
            [$newStatus, $id]
        );

        if ($updated !== false) {
            auth()->logActivity('update', 'purchases', "Updated purchase order {$order['po_number']} status to {$newStatus}");
            setFlash('success', 'Purchase order status updated successfully.');
            redirect(APP_URL . '/modules/purchases/view.php?id=' . $id);
        }

        $errors[] = 'Unable to update the purchase order status. Please try again.';
    }
}
?>

<div class="max-w-5xl mx-auto">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-gray-800"><?php echo sanitize($order['po_number']); ?></h2>
            <p class="text-sm text-gray-500 mt-1">Purchase order details and status updates.</p>
        </div>
        <a href="index.php" class="inline-flex items-center px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-medium transition touch-target">
            <?php echo icon('arrow-left', 4, 'mr-2'); ?> Back to Orders
        </a>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php foreach ($errors as $error): ?>
            <li><?php echo sanitize($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php if ($successMessage): ?>
    <div class="bg-emerald-50 border-l-4 border-emerald-400 text-emerald-800 p-4 mb-6 rounded-r">
        <?php echo sanitize($successMessage); ?>
    </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <p class="text-sm text-gray-500 mb-3">PO Information</p>
            <div class="space-y-2 text-sm text-gray-700">
                <div><span class="font-medium">PO Number:</span> <?php echo sanitize($order['po_number']); ?></div>
                <div><span class="font-medium">Status:</span> <?php echo statusBadge($order['status']); ?></div>
                <div><span class="font-medium">Created:</span> <?php echo formatDate($order['created_at']); ?></div>
                <div><span class="font-medium">Expected Delivery:</span> <?php echo $order['expected_delivery'] ? formatDate($order['expected_delivery']) : 'Not set'; ?></div>
                <div><span class="font-medium">Notification:</span> <?php echo $order['notification_sent_at'] ? strtoupper(sanitize($order['notification_channel'])) : 'None'; ?></div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 xl:col-span-2">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div class="bg-gray-50 rounded-2xl p-4">
                    <p class="text-xs uppercase tracking-wide text-gray-500 mb-2">Vendor</p>
                    <p class="font-medium text-gray-900"><?php echo sanitize($order['vendor_name'] ?? 'N/A'); ?></p>
                    <p class="text-sm text-gray-600">Code: <?php echo sanitize($order['vendor_code'] ?? '-'); ?></p>
                </div>
                <div class="bg-gray-50 rounded-2xl p-4">
                    <p class="text-xs uppercase tracking-wide text-gray-500 mb-2">Supplier</p>
                    <p class="font-medium text-gray-900"><?php echo sanitize($order['supplier_name'] ?? 'N/A'); ?></p>
                    <p class="text-sm text-gray-600"><?php echo sanitize($order['supplier_phone'] ?? '-'); ?></p>
                    <p class="text-sm text-gray-600"><?php echo sanitize($order['supplier_email'] ?? '-'); ?></p>
                </div>
            </div>

            <div class="bg-white border border-gray-100 rounded-2xl p-4">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="text-sm font-semibold text-gray-700">Order Summary</h3>
                    <span class="text-sm text-gray-500"><?php echo $items ? count($items) . ' item' . (count($items) === 1 ? '' : 's') : 'No items'; ?></span>
                </div>
                <div class="grid grid-cols-2 gap-4 text-sm text-gray-700">
                    <div><span class="font-medium">Total Amount:</span> <?php echo formatCurrency($order['total_amount']); ?></div>
                    <div><span class="font-medium">Tax Amount:</span> <?php echo formatCurrency($order['tax_amount']); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="table-wrapper">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="text-left py-3 px-4 font-medium text-gray-600">Description</th>
                        <th class="text-center py-3 px-4 font-medium text-gray-600">Quantity</th>
                        <th class="text-right py-3 px-4 font-medium text-gray-600">Unit Price</th>
                        <th class="text-right py-3 px-4 font-medium text-gray-600">Total</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php if ($items): ?>
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td class="py-3 px-4"><?php echo sanitize($item['item_description']); ?></td>
                            <td class="py-3 px-4 text-center"><?php echo sanitize($item['quantity']); ?></td>
                            <td class="py-3 px-4 text-right"><?php echo formatCurrency($item['unit_price']); ?></td>
                            <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($item['total_amount']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="py-12 text-center text-gray-400">No items added to this order.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (auth()->hasPermission('po.update_status')): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Update Order Status</h3>
        <form method="POST" action="">
            <?php echo csrfField(); ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <?php foreach ($allowedStatuses as $statusOption): ?>
                        <option value="<?php echo sanitize($statusOption); ?>" <?php echo $order['status'] === $statusOption ? 'selected' : ''; ?>><?php echo ucfirst($statusOption); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="text-right">
                    <button type="submit" class="inline-flex items-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">
                        <?php echo icon('refresh-cw', 4, 'mr-2'); ?> Update Status
                    </button>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>