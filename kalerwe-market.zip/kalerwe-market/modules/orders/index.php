<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('order.view_own');
$pageTitle = 'Customer Orders';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

$statusFilter = $_GET['status'] ?? '';
$where = '1=1';
if (!$isAdmin && $vendorId) $where .= " AND co.vendor_id = {$vendorId}";
if ($statusFilter) $where .= " AND co.status = '{$statusFilter}'";

$orders = $db->fetchAll(
    "SELECT co.*, v.business_name, (SELECT COUNT(*) FROM customer_order_items WHERE order_id = co.id) as item_count
     FROM customer_orders co
     LEFT JOIN vendors v ON co.vendor_id = v.id
     WHERE {$where}
     ORDER BY co.created_at DESC LIMIT 50"
);

$pendingCount = $db->count('customer_orders', ($isAdmin ? "" : "vendor_id = {$vendorId} AND ") . "status = 'pending'");
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Customer Orders</h2>
        <p class="text-sm text-gray-500 mt-1">Manage customer orders and fulfillment</p>
    </div>
    <a href="create.php" class="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> New Order
    </a>
</div>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500">Pending</p>
        <p class="text-xl font-bold text-orange-600"><?php echo $pendingCount; ?></p>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Order #</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Customer</th>
                    <?php if ($isAdmin): ?><th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th><?php endif; ?>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Amount</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Status</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($orders as $o): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4 font-medium text-emerald-600"><?php echo sanitize($o['order_number']); ?></td>
                    <td class="py-3 px-4">
                        <p class="text-gray-800"><?php echo sanitize($o['customer_name'] ?? 'Walk-in'); ?></p>
                        <p class="text-xs text-gray-500"><?php echo sanitize($o['customer_phone'] ?? ''); ?></p>
                    </td>
                    <?php if ($isAdmin): ?><td class="py-3 px-4 text-gray-600"><?php echo sanitize($o['business_name'] ?? ''); ?></td><?php endif; ?>
                    <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($o['total_amount']); ?></td>
                    <td class="py-3 px-4 text-center"><?php echo statusBadge($o['status']); ?></td>
                    <td class="py-3 px-4 text-gray-600"><?php echo formatDate($o['created_at']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($orders)): ?>
                <tr><td colspan="<?php echo $isAdmin ? 6 : 5; ?>" class="py-12 text-center text-gray-400">No orders found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
