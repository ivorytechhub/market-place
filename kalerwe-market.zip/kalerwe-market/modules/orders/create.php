<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('order.create');

$pageTitle = 'New Customer Order';
$db = getDB();
$isAdmin = auth()->isAdmin();
$vendorId = auth()->getVendorId();
$vendors = $db->fetchAll("SELECT id, business_name, vendor_code, stall_number FROM vendors WHERE status = 'active' ORDER BY business_name");
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }

    $selectedVendorId = $isAdmin ? intval($_POST['vendor_id'] ?? 0) : $vendorId;
    $customerName = cleanInput($_POST['customer_name'] ?? '');
    $customerPhone = cleanInput($_POST['customer_phone'] ?? '');
    $status = cleanInput($_POST['status'] ?? 'pending');
    $deliveryDate = cleanInput($_POST['delivery_date'] ?? '');
    $notes = cleanInput($_POST['notes'] ?? '');

    $itemDescriptions = $_POST['item_description'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $unitPrices = $_POST['unit_price'] ?? [];

    if ($selectedVendorId <= 0) {
        $errors[] = 'Please select a vendor.';
    }
    if ($deliveryDate && !validDate($deliveryDate)) {
        $errors[] = 'Please enter a valid delivery date.';
    }

    $items = [];
    $totalAmount = 0;

    foreach ($itemDescriptions as $index => $description) {
        $description = cleanInput($description);
        $quantity = floatval($quantities[$index] ?? 0);
        $unitPrice = floatval($unitPrices[$index] ?? 0);

        if ($description === '') {
            continue;
        }
        if ($quantity <= 0) {
            $errors[] = 'Each item must have a quantity greater than zero.';
            break;
        }
        if ($unitPrice < 0) {
            $errors[] = 'Each item must have a valid unit price.';
            break;
        }

        $lineTotal = $quantity * $unitPrice;
        $items[] = [
            'description' => $description,
            'quantity' => $quantity,
            'unit_price' => $unitPrice,
            'total' => $lineTotal
        ];
        $totalAmount += $lineTotal;
    }

    if (empty($items)) {
        $errors[] = 'Please add at least one order item.';
    }
    if ($totalAmount <= 0) {
        $errors[] = 'Total order amount must be greater than zero.';
    }

    if (empty($errors)) {
        $orderNumber = generateOrderNumber();
        $orderId = $db->insert(
            "INSERT INTO customer_orders (order_number, customer_name, customer_phone, vendor_id, total_amount, status, delivery_date, notes, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())",
            [$orderNumber, $customerName, $customerPhone, $selectedVendorId, $totalAmount, $status, $deliveryDate ?: null, $notes, auth()->getUserId()]
        );

        if ($orderId) {
            foreach ($items as $item) {
                $db->insert(
                    "INSERT INTO customer_order_items (order_id, product_id, item_description, quantity, unit_price, total_amount) VALUES (?, NULL, ?, ?, ?, ?)",
                    [$orderId, $item['description'], $item['quantity'], $item['unit_price'], $item['total']]
                );
            }

            auth()->logActivity('create', 'orders', "Created customer order: {$orderNumber}");
            setFlash('success', 'Order created successfully.');
            redirect(APP_URL . '/modules/orders/index.php');
        }

        $errors[] = 'Unable to save order. Please try again.';
    }
}
?>

<div class="max-w-5xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="index.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">Create Customer Order</h2>
            <p class="text-sm text-gray-500">Add a new customer order to the system.</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php foreach ($errors as $error): ?>
            <li><?php echo sanitize($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" class="space-y-6">
        <?php echo csrfField(); ?>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Order Details</h3>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <?php if ($isAdmin): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Vendor *</label>
                    <select name="vendor_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <option value="">-- Select Vendor --</option>
                        <?php foreach ($vendors as $vendor): ?>
                        <option value="<?php echo $vendor['id']; ?>" <?php echo intval($_POST['vendor_id'] ?? 0) === intval($vendor['id']) ? 'selected' : ''; ?>>
                            <?php echo sanitize($vendor['business_name']); ?> (<?php echo sanitize($vendor['stall_number']); ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Customer Name</label>
                    <input type="text" name="customer_name" value="<?php echo sanitize($_POST['customer_name'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="Customer full name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Customer Phone</label>
                    <input type="tel" name="customer_phone" value="<?php echo sanitize($_POST['customer_phone'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="+2567XXXXXXXX">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Delivery Date</label>
                    <input type="date" name="delivery_date" value="<?php echo sanitize($_POST['delivery_date'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <?php foreach (['pending' => 'Pending', 'processing' => 'Processing', 'ready' => 'Ready', 'completed' => 'Completed', 'cancelled' => 'Cancelled'] as $value => $label): ?>
                        <option value="<?php echo $value; ?>" <?php echo ($_POST['status'] ?? 'pending') === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Order Items</h3>
            <div id="orderItems" class="space-y-4">
                <?php
                $rows = max(1, count($_POST['item_description'] ?? ['']));
                for ($i = 0; $i < $rows; $i++):
                ?>
                <div class="grid grid-cols-1 xl:grid-cols-5 gap-4 items-end border-b border-gray-100 pb-4">
                    <div class="xl:col-span-3">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Item Description</label>
                        <input type="text" name="item_description[]" value="<?php echo sanitize($_POST['item_description'][$i] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="e.g., 10kg maize">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Quantity</label>
                        <input type="number" name="quantity[]" min="1" step="1" value="<?php echo sanitize($_POST['quantity'][$i] ?? '1'); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Unit Price</label>
                        <input type="number" name="unit_price[]" min="0" step="100" value="<?php echo sanitize($_POST['unit_price'][$i] ?? '0'); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    </div>
                    <div class="flex items-center justify-end xl:justify-center">
                        <button type="button" onclick="removeOrderItem(this)" class="px-3 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition touch-target">Remove</button>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
            <button type="button" onclick="addOrderItem()" class="mt-4 inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition touch-target">
                <?php echo icon('plus', 4, 'mr-2'); ?> Add Item
            </button>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Notes</label>
            <textarea name="notes" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"><?php echo sanitize($_POST['notes'] ?? ''); ?></textarea>
        </div>

        <div class="text-right">
            <button type="submit" class="inline-flex items-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('plus', 4, 'mr-2'); ?> Create Order
            </button>
        </div>
    </form>
</div>

<script>
function addOrderItem() {
    const container = document.getElementById('orderItems');
    const template = document.createElement('div');
    template.className = 'grid grid-cols-1 xl:grid-cols-5 gap-4 items-end border-b border-gray-100 pb-4';
    template.innerHTML = `
        <div class="xl:col-span-3">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Item Description</label>
            <input type="text" name="item_description[]" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="e.g., 10kg maize">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Quantity</label>
            <input type="number" name="quantity[]" min="1" step="1" value="1" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Unit Price</label>
            <input type="number" name="unit_price[]" min="0" step="100" value="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
        </div>
        <div class="flex items-center justify-end xl:justify-center">
            <button type="button" onclick="removeOrderItem(this)" class="px-3 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition touch-target">Remove</button>
        </div>
    `;
    container.appendChild(template);
}

function removeOrderItem(button) {
    const row = button.closest('div.grid');
    if (row) {
        row.remove();
    }
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
