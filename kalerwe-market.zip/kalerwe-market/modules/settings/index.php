<?php
/**
 * Kalerwe Market - System Settings Module
 * 
 * Configure association details, financial settings, receipt templates.
 * Admin-only access.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requireRole('admin');

$pageTitle = 'Settings';
$db = getDB();

$settings = $db->fetchOne("SELECT * FROM company_settings LIMIT 1");
if (!$settings) {
    $db->execute("INSERT INTO company_settings (association_name) VALUES ('Kalerwe Market Vendors Association')");
    $settings = $db->fetchOne("SELECT * FROM company_settings LIMIT 1");
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        $errors[] = 'Invalid form submission.';
    } else {
        $data = [
            'association_name' => cleanInput($_POST['association_name'] ?? ''),
            'tagline' => cleanInput($_POST['tagline'] ?? ''),
            'address' => cleanInput($_POST['address'] ?? ''),
            'phone' => cleanInput($_POST['phone'] ?? ''),
            'email' => cleanInput($_POST['email'] ?? ''),
            'website' => cleanInput($_POST['website'] ?? ''),
            'currency_symbol' => cleanInput($_POST['currency_symbol'] ?? 'UGX'),
            'currency_code' => cleanInput($_POST['currency_code'] ?? 'UGX'),
            'tax_rate' => floatval($_POST['tax_rate'] ?? 18),
            'registration_number' => cleanInput($_POST['registration_number'] ?? ''),
            'kcca_license' => cleanInput($_POST['kcca_license'] ?? ''),
            'receipt_footer' => cleanInput($_POST['receipt_footer'] ?? ''),
            'timezone' => cleanInput($_POST['timezone'] ?? 'Africa/Kampala'),
            'date_format' => cleanInput($_POST['date_format'] ?? 'd/m/Y'),
            'session_timeout' => intval($_POST['session_timeout'] ?? 30),
            'low_stock_threshold' => intval($_POST['low_stock_threshold'] ?? 10),
        ];
        
        if (empty($data['association_name'])) {
            $errors[] = 'Association name is required.';
        }
        
        if (empty($errors)) {
            $db->execute(
                "UPDATE company_settings SET 
                    association_name = ?, tagline = ?, address = ?, phone = ?, email = ?, website = ?,
                    currency_symbol = ?, currency_code = ?, tax_rate = ?, registration_number = ?,
                    kcca_license = ?, receipt_footer = ?, timezone = ?, date_format = ?,
                    session_timeout = ?, low_stock_threshold = ?, updated_at = NOW()
                 WHERE id = ?",
                array_merge(array_values($data), [$settings['id']])
            );
            
            auth()->logActivity('update', 'settings', 'Updated system settings');
            setFlash('success', 'Settings updated successfully.');
            redirect(currentUrl());
        }
    }
}
?>

<div class="max-w-4xl mx-auto">
    <div class="flex items-center mb-6">
        <div>
            <h2 class="text-xl font-bold text-gray-800">System Settings</h2>
            <p class="text-sm text-gray-500 mt-1">Configure association and system preferences</p>
        </div>
    </div>
    
    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm"><?php foreach ($errors as $e): ?><li><?php echo sanitize($e); ?></li><?php endforeach; ?></ul>
    </div>
    <?php endif; ?>
    
    <form method="POST" action="" class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php echo csrfField(); ?>
        
        <!-- Association Details -->
        <div class="p-6 border-b border-gray-100">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <span class="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center mr-3"><?php echo icon('layout-dashboard', 4, 'text-emerald-600'); ?></span>
                Association Details
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Association Name *</label>
                    <input type="text" name="association_name" value="<?php echo sanitize($settings['association_name']); ?>" required class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tagline</label>
                    <input type="text" name="tagline" value="<?php echo sanitize($settings['tagline'] ?? ''); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="e.g., Unity, Progress & Prosperity">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
                    <textarea name="address" rows="2" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"><?php echo sanitize($settings['address'] ?? ''); ?></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="text" name="phone" value="<?php echo sanitize($settings['phone'] ?? ''); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" value="<?php echo sanitize($settings['email'] ?? ''); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Website</label>
                    <input type="text" name="website" value="<?php echo sanitize($settings['website'] ?? ''); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Registration/TIN</label>
                    <input type="text" name="registration_number" value="<?php echo sanitize($settings['registration_number'] ?? ''); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
            </div>
        </div>
        
        <!-- Financial Settings -->
        <div class="p-6 border-b border-gray-100">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <span class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3"><?php echo icon('dollar-sign', 4, 'text-blue-600'); ?></span>
                Financial Settings
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Currency Symbol</label>
                    <input type="text" name="currency_symbol" value="<?php echo sanitize($settings['currency_symbol'] ?? 'UGX'); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Currency Code</label>
                    <input type="text" name="currency_code" value="<?php echo sanitize($settings['currency_code'] ?? 'UGX'); ?>" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Default Tax Rate (%)</label>
                    <input type="number" name="tax_rate" value="<?php echo $settings['tax_rate'] ?? 18; ?>" step="0.01" min="0" max="100" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
            </div>
        </div>
        
        <!-- Receipt Settings -->
        <div class="p-6 border-b border-gray-100">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <span class="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3"><?php echo icon('receipt', 4, 'text-purple-600'); ?></span>
                Receipt Settings
            </h3>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Receipt Footer Message</label>
                <textarea name="receipt_footer" rows="4" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm font-mono"><?php echo sanitize($settings['receipt_footer'] ?? ''); ?></textarea>
                <p class="text-xs text-gray-500 mt-1">This appears at the bottom of every receipt.</p>
            </div>
        </div>
        
        <!-- System Settings -->
        <div class="p-6 border-b border-gray-100">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <span class="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mr-3"><?php echo icon('settings', 4, 'text-orange-600'); ?></span>
                System Preferences
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Timezone</label>
                    <select name="timezone" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <option value="Africa/Kampala" <?php echo ($settings['timezone'] ?? '') === 'Africa/Kampala' ? 'selected' : ''; ?>>Africa/Kampala (EAT)</option>
                        <option value="Africa/Nairobi" <?php echo ($settings['timezone'] ?? '') === 'Africa/Nairobi' ? 'selected' : ''; ?>>Africa/Nairobi (EAT)</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date Format</label>
                    <select name="date_format" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <option value="d/m/Y" <?php echo ($settings['date_format'] ?? '') === 'd/m/Y' ? 'selected' : ''; ?>>DD/MM/YYYY</option>
                        <option value="m/d/Y" <?php echo ($settings['date_format'] ?? '') === 'm/d/Y' ? 'selected' : ''; ?>>MM/DD/YYYY</option>
                        <option value="Y-m-d" <?php echo ($settings['date_format'] ?? '') === 'Y-m-d' ? 'selected' : ''; ?>>YYYY-MM-DD</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Session Timeout (minutes)</label>
                    <input type="number" name="session_timeout" value="<?php echo $settings['session_timeout'] ?? 30; ?>" min="5" max="120" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
            </div>
        </div>
        
        <!-- Actions -->
        <div class="p-6 bg-gray-50 flex justify-end">
            <button type="submit" class="px-8 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
                Save Settings
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
