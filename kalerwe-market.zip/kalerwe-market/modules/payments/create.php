<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('payment.create');

$pageTitle = 'Record Payment';
$db = getDB();
$isAdmin = auth()->isAdmin();
$vendorId = auth()->getVendorId();
$referenceType = cleanInput($_POST['reference_type'] ?? $_GET['reference_type'] ?? '');
$referenceId = intval($_POST['reference_id'] ?? 0);
$errors = [];
$references = [];

$referenceOptions = [
    'sale' => 'Sale',
    'purchase' => 'Purchase Order',
    'contribution' => 'Contribution',
    'expense' => 'Expense',
    'customer_order' => 'Customer Order'
];

function loadReferences($db, $type, $vendorId, $isAdmin) {
    $sql = '';
    $params = [];
    switch ($type) {
        case 'sale':
            $sql = "SELECT id, transaction_number AS label, vendor_id FROM sales_transactions";
            break;
        case 'purchase':
            $sql = "SELECT id, po_number AS label, vendor_id FROM purchase_orders";
            break;
        case 'contribution':
            $sql = "SELECT id, COALESCE(receipt_number, CONCAT('Contribution #', id)) AS label, vendor_id FROM member_contributions";
            break;
        case 'expense':
            $sql = "SELECT id, expense_number AS label, vendor_id FROM expenses";
            break;
        case 'customer_order':
            $sql = "SELECT id, order_number AS label, vendor_id FROM customer_orders";
            break;
        default:
            return [];
    }
    if (!$isAdmin && $vendorId) {
        $sql .= " WHERE vendor_id = ?";
        $params[] = $vendorId;
    }
    $sql .= " ORDER BY id DESC LIMIT 200";
    return $db->fetchAll($sql, $params);
}

if ($referenceType) {
    $references = loadReferences($db, $referenceType, $vendorId, $isAdmin);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }

    $paymentDate = cleanInput($_POST['payment_date'] ?? date('Y-m-d'));
    $amount = floatval($_POST['amount'] ?? 0);
    $paymentMethod = cleanInput($_POST['payment_method'] ?? 'cash');
    $notes = cleanInput($_POST['notes'] ?? '');
    $referenceType = cleanInput($_POST['reference_type'] ?? '');
    $referenceId = intval($_POST['reference_id'] ?? 0);

    if (!array_key_exists($referenceType, $referenceOptions)) {
        $errors[] = 'Please select a valid reference type.';
    }
    if ($referenceId <= 0) {
        $errors[] = 'Please select a reference record.';
    }
    if ($amount <= 0) {
        $errors[] = 'Amount must be greater than zero.';
    }
    if (!validDate($paymentDate)) {
        $errors[] = 'Please enter a valid payment date.';
    }

    if (empty($errors)) {
        $reference = $db->fetchOne("SELECT * FROM " . (
            $referenceType === 'sale' ? 'sales_transactions' :
            ($referenceType === 'purchase' ? 'purchase_orders' :
            ($referenceType === 'contribution' ? 'member_contributions' :
            ($referenceType === 'expense' ? 'expenses' : 'customer_orders')))) . " WHERE id = ? LIMIT 1", [$referenceId]);

        if (!$reference) {
            $errors[] = 'The selected reference record does not exist.';
        } else {
            $paymentVendorId = $reference['vendor_id'] ?? null;
            if (!$paymentVendorId) {
                $errors[] = 'Unable to determine vendor for this reference.';
            }
        }
    }

    if (empty($errors)) {
        $paymentNumber = generatePaymentNumber();
        $insertId = $db->insert(
            "INSERT INTO payments (payment_number, reference_type, reference_id, vendor_id, amount, payment_method, payment_date, notes, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())",
            [$paymentNumber, $referenceType, $referenceId, $paymentVendorId, $amount, $paymentMethod, $paymentDate, $notes, auth()->getUserId()]
        );

        if ($insertId) {
            auth()->logActivity('create', 'payments', "Recorded payment: {$paymentNumber}");
            setFlash('success', 'Payment recorded successfully.');
            redirect(APP_URL . '/modules/payments/index.php');
        }

        $errors[] = 'Unable to save payment. Please try again.';
    }
}
?>

<div class="max-w-4xl mx-auto">
    <div class="flex items-center mb-6">
        <a href="index.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">Record Payment</h2>
            <p class="text-sm text-gray-500">Capture payments against sales, purchases, expenses, or contributions.</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 mb-6 rounded-r">
        <ul class="list-disc list-inside text-sm space-y-1">
            <?php foreach ($errors as $error): ?>
            <li><?php echo sanitize($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php echo csrfField(); ?>
        <div class="p-6 grid grid-cols-1 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Reference Type *</label>
                <select name="reference_type" onchange="this.form.submit()" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Reference Type --</option>
                    <?php foreach ($referenceOptions as $value => $label): ?>
                    <option value="<?php echo $value; ?>" <?php echo $referenceType === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <?php if ($referenceType): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Reference Record *</label>
                <select name="reference_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <option value="">-- Select Record --</option>
                    <?php foreach ($references as $reference): ?>
                    <option value="<?php echo $reference['id']; ?>" <?php echo $referenceId === intval($reference['id']) ? 'selected' : ''; ?>>
                        <?php echo sanitize($reference['label']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Amount (UGX) *</label>
                    <input type="number" name="amount" min="0" step="100" required value="<?php echo sanitize($_POST['amount'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Payment Date *</label>
                    <input type="date" name="payment_date" required value="<?php echo sanitize($_POST['payment_date'] ?? date('Y-m-d')); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Payment Method</label>
                <select name="payment_method" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                    <?php foreach (['cash' => 'Cash', 'mobile_money' => 'Mobile Money', 'bank_transfer' => 'Bank Transfer'] as $value => $label): ?>
                    <option value="<?php echo $value; ?>" <?php echo ($_POST['payment_method'] ?? 'cash') === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Notes</label>
                <textarea name="notes" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none"><?php echo sanitize($_POST['notes'] ?? ''); ?></textarea>
            </div>
        </div>

        <div class="p-6 border-t border-gray-100 text-right">
            <button type="submit" class="inline-flex items-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('plus', 4, 'mr-2'); ?> Record Payment
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
