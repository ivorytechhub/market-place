<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('payment.view_own');
$pageTitle = 'Payments';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

$where = '1=1';
if (!$isAdmin && $vendorId) $where .= " AND p.vendor_id = {$vendorId}";

$payments = $db->fetchAll(
    "SELECT p.*, v.business_name FROM payments p LEFT JOIN vendors v ON p.vendor_id = v.id WHERE {$where} ORDER BY p.created_at DESC LIMIT 50"
);

// Summary
$monthTotal = $db->fetchOne("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE MONTH(payment_date) = MONTH(CURDATE()) AND YEAR(payment_date) = YEAR(CURDATE())" . ($isAdmin ? "" : " AND vendor_id = {$vendorId}"))['total'] ?? 0;
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Payments</h2>
        <p class="text-sm text-gray-500 mt-1">Track payments received and made</p>
    </div>
    <a href="create.php" class="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> Record Payment
    </a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6 flex items-center justify-between">
    <div>
        <p class="text-sm text-gray-500">Total Payments This Month</p>
        <p class="text-2xl font-bold text-emerald-600"><?php echo formatCurrency($monthTotal); ?></p>
    </div>
    <div class="p-3 bg-emerald-100 rounded-xl">
        <svg class="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Payment #</th>
                    <?php if ($isAdmin): ?><th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th><?php endif; ?>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Amount</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Method</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Reference</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($payments as $p): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4 font-medium text-emerald-600"><?php echo sanitize($p['payment_number']); ?></td>
                    <?php if ($isAdmin): ?><td class="py-3 px-4 text-gray-600"><?php echo sanitize($p['business_name'] ?? ''); ?></td><?php endif; ?>
                    <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($p['amount']); ?></td>
                    <td class="py-3 px-4 text-center"><span class="text-xs text-gray-600"><?php echo ucfirst(str_replace('_', ' ', $p['payment_method'])); ?></span></td>
                    <td class="py-3 px-4 text-gray-600"><?php echo formatDate($p['payment_date']); ?></td>
                    <td class="py-3 px-4 text-gray-600"><?php echo sanitize($p['reference_type']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($payments)): ?>
                <tr><td colspan="<?php echo $isAdmin ? 6 : 5; ?>" class="py-12 text-center text-gray-400">No payments found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
