<?php
/**
 * Kalerwe Market - Create Sale (POS Interface)
 * 
 * Mobile-first Point of Sale interface for recording sales transactions.
 * Supports multiple items, auto-tax calculation, and digital receipt generation.
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('sale.create');

$pageTitle = 'New Sale';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

// Get vendor's products for the dropdown
$productWhere = $isAdmin ? "p.is_active = 1" : "p.vendor_id = ? AND p.is_active = 1";
$productParams = $isAdmin ? [] : [$vendorId];
$products = $db->fetchAll(
    "SELECT p.id, p.sku, p.name, p.selling_price, p.tax_rate, p.quantity as stock, p.unit, c.name as category
     FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     WHERE {$productWhere}
     ORDER BY p.name",
    $productParams
);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        setFlash('error', 'Invalid form submission.');
        redirect(currentUrl());
    }
    
    $saleVendorId = $isAdmin ? intval($_POST['vendor_id'] ?? 0) : $vendorId;
    $customerName = cleanInput($_POST['customer_name'] ?? '');
    $customerPhone = cleanInput($_POST['customer_phone'] ?? '');
    $paymentMethod = cleanInput($_POST['payment_method'] ?? 'cash');
    $discount = floatval($_POST['discount'] ?? 0);
    $notes = cleanInput($_POST['notes'] ?? '');
    
    $itemIds = $_POST['product_id'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $prices = $_POST['unit_price'] ?? [];
    
    if (empty($itemIds) || empty(array_filter($itemIds))) {
        setFlash('error', 'Please add at least one item to the sale.');
        redirect(currentUrl());
    }
    
    $db->beginTransaction();
    
    try {
        $subtotal = 0;
        $totalTax = 0;
        $items = [];
        
        // Calculate totals
        foreach ($itemIds as $idx => $productId) {
            if (empty($productId)) continue;
            $qty = floatval($quantities[$idx] ?? 1);
            $price = floatval($prices[$idx] ?? 0);
            $product = $db->fetchOne("SELECT * FROM products WHERE id = ?", [$productId]);
            
            if (!$product) continue;
            if ($qty <= 0) continue;
            
            $itemTotal = $qty * $price;
            $taxRate = floatval($product['tax_rate'] ?? DEFAULT_TAX_RATE);
            $itemTax = $itemTotal * ($taxRate / 100);
            
            $subtotal += $itemTotal;
            $totalTax += $itemTax;
            
            $items[] = [
                'product_id' => $productId,
                'quantity' => $qty,
                'unit_price' => $price,
                'total_amount' => $itemTotal,
                'stock' => $product['quantity']
            ];
        }
        
        if (empty($items)) {
            throw new Exception('No valid items in the transaction.');
        }
        
        $netAmount = $subtotal + $totalTax - $discount;
        $transactionNumber = generateTransactionNumber();
        
        // Insert transaction
        $txnId = $db->insert(
            "INSERT INTO sales_transactions (transaction_number, vendor_id, customer_name, customer_phone, 
             total_amount, tax_amount, discount, net_amount, payment_method, payment_status, amount_paid, 
             status, notes, created_by, created_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'paid', ?, 'completed', ?, ?, NOW())",
            [$transactionNumber, $saleVendorId, $customerName, $customerPhone,
             $subtotal, $totalTax, $discount, $netAmount, $paymentMethod, $netAmount, $notes, auth()->getUserId()]
        );
        
        if (!$txnId) throw new Exception('Failed to create transaction.');
        
        // Insert items and update stock
        foreach ($items as $item) {
            $db->insert(
                "INSERT INTO transaction_items (transaction_id, product_id, quantity, unit_price, total_amount)
                 VALUES (?, ?, ?, ?, ?)",
                [$txnId, $item['product_id'], $item['quantity'], $item['unit_price'], $item['total_amount']]
            );
            
            // Update product stock
            $newStock = max(0, $item['stock'] - $item['quantity']);
            $db->execute(
                "UPDATE products SET quantity = ? WHERE id = ?",
                [$newStock, $item['product_id']]
            );
            
            // Log inventory movement
            $db->insert(
                "INSERT INTO inventory_movements (product_id, movement_type, quantity, reference_type, reference_id, notes, created_by, created_at)
                 VALUES (?, 'sale', ?, 'sale', ?, ?, ?, NOW())",
                [$item['product_id'], -$item['quantity'], $txnId, 'Sale transaction', auth()->getUserId()]
            );
        }
        
        $db->commit();
        
        auth()->logActivity('create', 'sales', "Created sale: {$transactionNumber}");
        setFlash('success', "Sale recorded successfully! Transaction: {$transactionNumber}");
        redirect(APP_URL . '/modules/sales/receipt.php?id=' . $txnId);
        
    } catch (Exception $e) {
        $db->rollback();
        setFlash('error', $e->getMessage());
        redirect(currentUrl());
    }
}
?>

<div class="max-w-5xl mx-auto">
    <!-- Header -->
    <div class="flex items-center mb-6">
        <a href="index.php" class="mr-4 p-2 rounded-lg hover:bg-gray-100 transition touch-target">
            <?php echo icon('arrow-left', 5, 'text-gray-600'); ?>
        </a>
        <div>
            <h2 class="text-xl font-bold text-gray-800">New Sale</h2>
            <p class="text-sm text-gray-500">Record a new sales transaction</p>
        </div>
    </div>
    
    <form method="POST" action="" id="saleForm" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <?php echo csrfField(); ?>
        
        <!-- Left Column: Sale Details -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Product Selector -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <h3 class="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">Add Products</h3>
                
                <div id="productRows">
                    <!-- Template row -->
                    <div class="product-row grid grid-cols-12 gap-3 mb-3 pb-3 border-b border-gray-100 items-end" data-row="0">
                        <div class="col-span-6 sm:col-span-5">
                            <label class="block text-xs text-gray-500 mb-1">Product</label>
                            <select name="product_id[]" class="product-select w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" onchange="updatePrice(this)">
                                <option value="">-- Select Product --</option>
                                <?php foreach ($products as $p): ?>
                                <option value="<?php echo $p['id']; ?>" data-price="<?php echo $p['selling_price']; ?>" data-stock="<?php echo $p['stock']; ?>" data-tax="<?php echo $p['tax_rate']; ?>">
                                    <?php echo sanitize($p['name']); ?> (<?php echo sanitize($p['sku']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-span-3 sm:col-span-2">
                            <label class="block text-xs text-gray-500 mb-1">Qty</label>
                            <input type="number" name="quantity[]" value="1" min="1" step="1" class="quantity-input w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm text-center" onchange="calculateRow(this)">
                        </div>
                        <div class="col-span-3 sm:col-span-2">
                            <label class="block text-xs text-gray-500 mb-1">Price</label>
                            <input type="number" name="unit_price[]" value="0" min="0" step="100" class="price-input w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm text-right">
                        </div>
                        <div class="col-span-6 sm:col-span-2">
                            <label class="block text-xs text-gray-500 mb-1">Total</label>
                            <input type="text" readonly class="row-total w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-right font-medium text-gray-600" value="UGX 0">
                        </div>
                        <div class="col-span-6 sm:col-span-1 flex justify-end">
                            <button type="button" onclick="removeRow(this)" class="p-2 text-red-500 hover:bg-red-50 rounded-lg transition touch-target" title="Remove">
                                <?php echo icon('trash', 4); ?>
                            </button>
                        </div>
                    </div>
                </div>
                
                <button type="button" onclick="addRow()" class="mt-2 inline-flex items-center px-4 py-2 border border-emerald-300 text-emerald-700 rounded-lg text-sm font-medium hover:bg-emerald-50 transition touch-target">
                    <?php echo icon('plus', 4, 'mr-2'); ?> Add Another Product
                </button>
            </div>
            
            <!-- Customer Info -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <h3 class="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">Customer Information (Optional)</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Customer Name</label>
                        <input type="text" name="customer_name" 
                               class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm"
                               placeholder="Walk-in customer">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Phone Number</label>
                        <input type="tel" name="customer_phone" 
                               class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm"
                               placeholder="+2567XXXXXXXX">
                    </div>
                </div>
                <?php if ($isAdmin): ?>
                <div class="mt-4">
                    <label class="block text-xs text-gray-500 mb-1">Vendor *</label>
                    <select name="vendor_id" required class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
                        <option value="">-- Select Vendor --</option>
                        <?php 
                        $allVendors = $db->fetchAll("SELECT id, business_name, stall_number FROM vendors WHERE status = 'active' ORDER BY business_name");
                        foreach ($allVendors as $v): 
                        ?>
                        <option value="<?php echo $v['id']; ?>"><?php echo sanitize($v['business_name']); ?> (<?php echo sanitize($v['stall_number']); ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Notes -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <label class="block text-xs text-gray-500 mb-1">Notes</label>
                <textarea name="notes" rows="2" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm resize-none" placeholder="Any additional notes..."></textarea>
            </div>
        </div>
        
        <!-- Right Column: Summary & Checkout -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 sticky top-20">
                <h3 class="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">Payment Summary</h3>
                
                <div class="space-y-3 mb-6">
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Subtotal</span>
                        <span class="font-medium" id="summarySubtotal">UGX 0</span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Tax (<?php echo DEFAULT_TAX_RATE; ?>%)</span>
                        <span class="font-medium" id="summaryTax">UGX 0</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-sm text-gray-600">Discount</span>
                        <input type="number" name="discount" id="discountInput" value="0" min="0" step="100"
                               class="w-24 px-2 py-1 border border-gray-300 rounded text-sm text-right" onchange="calculateTotals()">
                    </div>
                    <div class="border-t border-gray-200 pt-3 flex justify-between">
                        <span class="text-base font-semibold text-gray-800">Total</span>
                        <span class="text-xl font-bold text-emerald-600" id="summaryTotal">UGX 0</span>
                    </div>
                </div>
                
                <!-- Payment Method -->
                <div class="mb-6">
                    <label class="block text-xs text-gray-500 mb-2">Payment Method</label>
                    <div class="grid grid-cols-3 gap-2">
                        <label class="cursor-pointer">
                            <input type="radio" name="payment_method" value="cash" checked class="sr-only peer">
                            <div class="peer-checked:bg-emerald-600 peer-checked:text-white peer-checked:border-emerald-600 border border-gray-300 rounded-lg p-3 text-center text-xs font-medium text-gray-600 hover:bg-gray-50 transition">
                                Cash
                            </div>
                        </label>
                        <label class="cursor-pointer">
                            <input type="radio" name="payment_method" value="mobile_money" class="sr-only peer">
                            <div class="peer-checked:bg-emerald-600 peer-checked:text-white peer-checked:border-emerald-600 border border-gray-300 rounded-lg p-3 text-center text-xs font-medium text-gray-600 hover:bg-gray-50 transition">
                                Mobile Money
                            </div>
                        </label>
                        <label class="cursor-pointer">
                            <input type="radio" name="payment_method" value="bank_transfer" class="sr-only peer">
                            <div class="peer-checked:bg-emerald-600 peer-checked:text-white peer-checked:border-emerald-600 border border-gray-300 rounded-lg p-3 text-center text-xs font-medium text-gray-600 hover:bg-gray-50 transition">
                                Bank
                            </div>
                        </label>
                    </div>
                </div>
                
                <!-- Submit -->
                <button type="submit" class="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-base transition shadow-lg touch-target">
                    Complete Sale
                </button>
                <a href="index.php" class="block w-full py-2.5 mt-2 text-center text-sm text-gray-500 hover:text-gray-700 transition touch-target">
                    Cancel
                </a>
            </div>
        </div>
    </form>
</div>

<script>
let rowCount = 1;

function addRow() {
    const container = document.getElementById('productRows');
    const template = container.querySelector('.product-row').cloneNode(true);
    
    // Reset values
    template.querySelector('.product-select').value = '';
    template.querySelector('.quantity-input').value = '1';
    template.querySelector('.price-input').value = '0';
    template.querySelector('.row-total').value = 'UGX 0';
    template.dataset.row = rowCount++;
    
    container.appendChild(template);
}

function removeRow(btn) {
    const rows = document.querySelectorAll('.product-row');
    if (rows.length > 1) {
        btn.closest('.product-row').remove();
        calculateTotals();
    }
}

function updatePrice(select) {
    const option = select.options[select.selectedIndex];
    const row = select.closest('.product-row');
    const priceInput = row.querySelector('.price-input');
    
    if (option.value) {
        priceInput.value = option.dataset.price || 0;
    }
    calculateRow(select);
}

function calculateRow(input) {
    const row = input.closest('.product-row');
    const qty = parseFloat(row.querySelector('.quantity-input').value) || 0;
    const price = parseFloat(row.querySelector('.price-input').value) || 0;
    const total = qty * price;
    
    row.querySelector('.row-total').value = 'UGX ' + total.toLocaleString();
    calculateTotals();
}

function calculateTotals() {
    let subtotal = 0;
    let totalTax = 0;
    
    document.querySelectorAll('.product-row').forEach(row => {
        const select = row.querySelector('.product-select');
        const qty = parseFloat(row.querySelector('.quantity-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        const option = select.options[select.selectedIndex];
        
        if (select.value) {
            const itemTotal = qty * price;
            const taxRate = parseFloat(option.dataset.tax) || <?php echo DEFAULT_TAX_RATE; ?>;
            subtotal += itemTotal;
            totalTax += itemTotal * (taxRate / 100);
        }
    });
    
    const discount = parseFloat(document.getElementById('discountInput').value) || 0;
    const total = subtotal + totalTax - discount;
    
    document.getElementById('summarySubtotal').textContent = 'UGX ' + subtotal.toLocaleString();
    document.getElementById('summaryTax').textContent = 'UGX ' + totalTax.toLocaleString();
    document.getElementById('summaryTotal').textContent = 'UGX ' + Math.max(0, total).toLocaleString();
}

// Calculate on any input change
document.addEventListener('input', function(e) {
    if (e.target.classList.contains('quantity-input') || e.target.classList.contains('price-input')) {
        calculateRow(e.target);
    }
});

// Initial calculation
calculateTotals();
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
