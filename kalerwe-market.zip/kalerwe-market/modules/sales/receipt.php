<?php
/**
 * Kalerwe Market - Digital Receipt
 * 
 * Displays and prints a digital receipt for a sales transaction.
 * Optimized for thermal printer output (58mm/80mm).
 */

require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('sale.view_own');

$db = getDB();
$txnId = intval($_GET['id'] ?? 0);
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

// Get transaction
$txn = $db->fetchOne(
    "SELECT st.*, v.business_name, v.stall_number, v.contact_phone as vendor_phone, v.kcca_permit_number
     FROM sales_transactions st
     LEFT JOIN vendors v ON st.vendor_id = v.id
     WHERE st.id = ?" . ($isAdmin ? "" : " AND st.vendor_id = {$vendorId}"),
    [$txnId]
);

if (!$txn) {
    setFlash('error', 'Transaction not found.');
    redirect(APP_URL . '/modules/sales/index.php');
}

// Get items
$items = $db->fetchAll(
    "SELECT ti.*, p.name as product_name, p.sku, p.unit
     FROM transaction_items ti
     JOIN products p ON ti.product_id = p.id
     WHERE ti.transaction_id = ?",
    [$txnId]
);

$settings = $db->fetchOne("SELECT * FROM company_settings LIMIT 1");
?>

<!-- Receipt Container -->
<div class="max-w-md mx-auto" id="receiptContent">
    <div class="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
        <!-- Receipt Header -->
        <div class="p-6 text-center border-b border-dashed border-gray-300">
            <?php if ($settings['logo']): ?>
            <img src="<?php echo APP_URL . '/uploads/logos/' . $settings['logo']; ?>" alt="Logo" class="h-16 mx-auto mb-3">
            <?php else: ?>
            <div class="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <?php echo icon('shopping-cart', 8, 'text-emerald-600'); ?>
            </div>
            <?php endif; ?>
            <h2 class="text-lg font-bold text-gray-800"><?php echo sanitize($settings['association_name'] ?? APP_NAME); ?></h2>
            <p class="text-xs text-gray-500"><?php echo sanitize($settings['address'] ?? 'Gayaza Road, Kampala'); ?></p>
            <p class="text-xs text-gray-500"><?php echo sanitize($settings['phone'] ?? ''); ?></p>
            <p class="text-xs text-gray-500 mt-1">TIN: <?php echo sanitize($settings['registration_number'] ?? 'N/A'); ?></p>
        </div>
        
        <!-- Receipt Info -->
        <div class="px-6 py-4 border-b border-dashed border-gray-300">
            <div class="flex justify-between text-xs mb-1">
                <span class="text-gray-600">Receipt #:</span>
                <span class="font-mono font-medium"><?php echo sanitize($txn['transaction_number']); ?></span>
            </div>
            <div class="flex justify-between text-xs mb-1">
                <span class="text-gray-600">Date:</span>
                <span><?php echo formatDateTime($txn['created_at']); ?></span>
            </div>
            <div class="flex justify-between text-xs mb-1">
                <span class="text-gray-600">Vendor:</span>
                <span><?php echo sanitize($txn['business_name'] ?? 'N/A'); ?></span>
            </div>
            <div class="flex justify-between text-xs mb-1">
                <span class="text-gray-600">Stall:</span>
                <span><?php echo sanitize($txn['stall_number'] ?? 'N/A'); ?></span>
            </div>
            <?php if ($txn['customer_name']): ?>
            <div class="flex justify-between text-xs">
                <span class="text-gray-600">Customer:</span>
                <span><?php echo sanitize($txn['customer_name']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Items -->
        <div class="px-6 py-4 border-b border-dashed border-gray-300">
            <table class="w-full text-xs">
                <thead>
                    <tr class="border-b border-gray-200">
                        <th class="text-left py-1 font-medium text-gray-600">Item</th>
                        <th class="text-center py-1 font-medium text-gray-600">Qty</th>
                        <th class="text-right py-1 font-medium text-gray-600">Price</th>
                        <th class="text-right py-1 font-medium text-gray-600">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td class="py-1.5 text-gray-800"><?php echo sanitize($item['product_name']); ?></td>
                        <td class="py-1.5 text-center text-gray-600"><?php echo $item['quantity']; ?></td>
                        <td class="py-1.5 text-right text-gray-600"><?php echo formatCurrency($item['unit_price']); ?></td>
                        <td class="py-1.5 text-right font-medium"><?php echo formatCurrency($item['total_amount']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Totals -->
        <div class="px-6 py-4 border-b border-dashed border-gray-300">
            <div class="flex justify-between text-xs mb-1">
                <span class="text-gray-600">Subtotal:</span>
                <span><?php echo formatCurrency($txn['total_amount']); ?></span>
            </div>
            <div class="flex justify-between text-xs mb-1">
                <span class="text-gray-600">Tax:</span>
                <span><?php echo formatCurrency($txn['tax_amount']); ?></span>
            </div>
            <?php if ($txn['discount'] > 0): ?>
            <div class="flex justify-between text-xs mb-1">
                <span class="text-gray-600">Discount:</span>
                <span class="text-red-600">-<?php echo formatCurrency($txn['discount']); ?></span>
            </div>
            <?php endif; ?>
            <div class="flex justify-between text-base font-bold mt-2 pt-2 border-t border-gray-200">
                <span>TOTAL:</span>
                <span class="text-emerald-600"><?php echo formatCurrency($txn['net_amount']); ?></span>
            </div>
            <div class="flex justify-between text-xs mt-2">
                <span class="text-gray-600">Payment:</span>
                <span class="font-medium"><?php echo ucfirst(str_replace('_', ' ', $txn['payment_method'])); ?></span>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="px-6 py-4 text-center">
            <?php if ($settings['receipt_footer']): ?>
            <p class="text-xs text-gray-500 whitespace-pre-line"><?php echo nl2br(sanitize($settings['receipt_footer'])); ?></p>
            <?php else: ?>
            <p class="text-xs text-gray-500">Thank you for your business!</p>
            <p class="text-xs text-gray-400 mt-1">Kalerwe Market Vendors Association</p>
            <?php endif; ?>
            <div class="mt-3">
                <svg class="mx-auto h-8 w-32" id="barcode"></svg>
            </div>
        </div>
    </div>
    
    <!-- Actions -->
    <div class="flex items-center justify-center space-x-4 mt-6 no-print">
        <button onclick="window.print()" class="inline-flex items-center px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition shadow-sm touch-target">
            <?php echo icon('printer', 5, 'mr-2'); ?> Print Receipt
        </button>
        <a href="index.php" class="inline-flex items-center px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition touch-target">
            Back to Sales
        </a>
    </div>
</div>

<!-- JsBarcode for barcode generation -->
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
<script>
JsBarcode("#barcode", "<?php echo $txn['transaction_number']; ?>", {
    format: "CODE128",
    width: 2,
    height: 40,
    displayValue: true,
    fontSize: 10
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
