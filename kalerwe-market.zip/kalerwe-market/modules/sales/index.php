<?php
/**
 * Kalerwe Market - Sales & Transactions Module
 * 
 * List all sales transactions with search, filter, and export options.
 * View transaction details and print receipts.
 */

require_once __DIR__ . '/../../includes/header.php';

auth()->requirePermission('sale.view_own');

$pageTitle = 'Sales';
$db = getDB();
$userRole = auth()->getRole();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();

// Filters
$search = $_GET['search'] ?? '';
$statusFilter = $_GET['status'] ?? '';
$paymentFilter = $_GET['payment_method'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

// Build query
$params = [];
$where = ['1=1'];

if (!$isAdmin && $vendorId) {
    $where[] = "st.vendor_id = ?";
    $params[] = $vendorId;
}

if ($search) {
    $where[] = "(st.transaction_number LIKE ? OR st.customer_name LIKE ? OR st.customer_phone LIKE ?)";
    $s = "%{$search}%";
    $params = array_merge($params, [$s, $s, $s]);
}

if ($statusFilter) {
    $where[] = "st.status = ?";
    $params[] = $statusFilter;
}

if ($paymentFilter) {
    $where[] = "st.payment_method = ?";
    $params[] = $paymentFilter;
}

if ($dateFrom) {
    $where[] = "DATE(st.created_at) >= ?";
    $params[] = $dateFrom;
}

if ($dateTo) {
    $where[] = "DATE(st.created_at) <= ?";
    $params[] = $dateTo;
}

$whereSql = implode(' AND ', $where);

// Get transactions
$transactions = $db->paginate(
    "SELECT st.*, v.business_name, v.stall_number
     FROM sales_transactions st
     LEFT JOIN vendors v ON st.vendor_id = v.id
     WHERE {$whereSql}
     ORDER BY st.created_at DESC",
    $params, $page
);

// Summary stats
$todayTotal = $db->fetchOne("SELECT COALESCE(SUM(net_amount), 0) as total FROM sales_transactions WHERE DATE(created_at) = CURDATE() AND status = 'completed'" . ($isAdmin ? "" : " AND vendor_id = {$vendorId}"))['total'] ?? 0;
$weekTotal = $db->fetchOne("SELECT COALESCE(SUM(net_amount), 0) as total FROM sales_transactions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND status = 'completed'" . ($isAdmin ? "" : " AND vendor_id = {$vendorId}"))['total'] ?? 0;
$monthTotal = $db->fetchOne("SELECT COALESCE(SUM(net_amount), 0) as total FROM sales_transactions WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) AND status = 'completed'" . ($isAdmin ? "" : " AND vendor_id = {$vendorId}"))['total'] ?? 0;
?>

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800">Sales Transactions</h2>
        <p class="text-sm text-gray-500 mt-1">Record and manage all sales transactions</p>
    </div>
    <?php if (auth()->hasPermission('sale.create')): ?>
    <a href="create.php" class="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition shadow-sm touch-target">
        <?php echo icon('plus', 4, 'mr-2'); ?> New Sale
    </a>
    <?php endif; ?>
</div>

<!-- Summary Cards -->
<div class="grid grid-cols-3 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500 mb-1">Today</p>
        <p class="text-lg font-bold text-emerald-600"><?php echo formatCurrency($todayTotal); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500 mb-1">This Week</p>
        <p class="text-lg font-bold text-blue-600"><?php echo formatCurrency($weekTotal); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 text-center">
        <p class="text-xs text-gray-500 mb-1">This Month</p>
        <p class="text-lg font-bold text-purple-600"><?php echo formatCurrency($monthTotal); ?></p>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="flex flex-col lg:flex-row gap-3">
        <div class="flex-1 relative">
            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <?php echo icon('search', 4, 'text-gray-400'); ?>
            </div>
            <input type="text" name="search" value="<?php echo sanitize($search); ?>" 
                   placeholder="Search transactions..." class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
        </div>
        <select name="status" onchange="this.form.submit()" class="lg:w-36 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            <option value="">All Status</option>
            <option value="completed" <?php echo $statusFilter === 'completed' ? 'selected' : ''; ?>>Completed</option>
            <option value="refunded" <?php echo $statusFilter === 'refunded' ? 'selected' : ''; ?>>Refunded</option>
            <option value="cancelled" <?php echo $statusFilter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
        </select>
        <select name="payment_method" onchange="this.form.submit()" class="lg:w-40 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm">
            <option value="">All Payments</option>
            <option value="cash" <?php echo $paymentFilter === 'cash' ? 'selected' : ''; ?>>Cash</option>
            <option value="mobile_money" <?php echo $paymentFilter === 'mobile_money' ? 'selected' : ''; ?>>Mobile Money</option>
            <option value="bank_transfer" <?php echo $paymentFilter === 'bank_transfer' ? 'selected' : ''; ?>>Bank Transfer</option>
        </select>
        <input type="date" name="date_from" value="<?php echo sanitize($dateFrom); ?>" class="lg:w-40 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="From">
        <input type="date" name="date_to" value="<?php echo sanitize($dateTo); ?>" class="lg:w-40 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="To">
        <button type="submit" class="px-6 py-2.5 bg-gray-800 text-white rounded-lg text-sm font-medium hover:bg-gray-900 transition touch-target">Filter</button>
        <?php if ($search || $statusFilter || $paymentFilter || $dateFrom || $dateTo): ?>
        <a href="?" class="px-6 py-2.5 border border-gray-300 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-50 transition text-center touch-target">Clear</a>
        <?php endif; ?>
    </form>
</div>

<!-- Transactions Table -->
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="table-wrapper">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Transaction #</th>
                    <?php if ($isAdmin): ?>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Vendor</th>
                    <?php endif; ?>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Customer</th>
                    <th class="text-right py-3 px-4 font-medium text-gray-600">Amount</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Payment</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Status</th>
                    <th class="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                    <th class="text-center py-3 px-4 font-medium text-gray-600">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php foreach ($transactions['data'] as $txn): ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-4 font-medium text-emerald-600"><?php echo sanitize($txn['transaction_number']); ?></td>
                    <?php if ($isAdmin): ?>
                    <td class="py-3 px-4">
                        <p class="text-gray-800"><?php echo sanitize($txn['business_name'] ?? 'N/A'); ?></p>
                        <p class="text-xs text-gray-500"><?php echo sanitize($txn['stall_number'] ?? ''); ?></p>
                    </td>
                    <?php endif; ?>
                    <td class="py-3 px-4">
                        <p class="text-gray-800"><?php echo sanitize($txn['customer_name'] ?? 'Walk-in'); ?></p>
                        <?php if ($txn['customer_phone']): ?>
                        <p class="text-xs text-gray-500"><?php echo formatPhone($txn['customer_phone']); ?></p>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($txn['net_amount']); ?></td>
                    <td class="py-3 px-4 text-center">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                            <?php echo ucfirst(str_replace('_', ' ', $txn['payment_method'])); ?>
                        </span>
                    </td>
                    <td class="py-3 px-4 text-center"><?php echo statusBadge($txn['status']); ?></td>
                    <td class="py-3 px-4 text-gray-600"><?php echo formatDateTime($txn['created_at']); ?></td>
                    <td class="py-3 px-4">
                        <div class="flex items-center justify-center space-x-2">
                            <a href="view.php?id=<?php echo $txn['id']; ?>" class="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition touch-target" title="View">
                                <?php echo icon('eye', 4); ?>
                            </a>
                            <a href="receipt.php?id=<?php echo $txn['id']; ?>" class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition touch-target" title="Print Receipt">
                                <?php echo icon('printer', 4); ?>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($transactions['data'])): ?>
                <tr>
                    <td colspan="<?php echo $isAdmin ? 8 : 7; ?>" class="py-12 text-center text-gray-400">
                        <?php echo icon('shopping-cart', 8, 'mx-auto mb-2'); ?>
                        <p>No transactions found</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php 
$paginationBase = '?' . http_build_query(array_filter(['search' => $search, 'status' => $statusFilter, 'payment_method' => $paymentFilter, 'date_from' => $dateFrom, 'date_to' => $dateTo]));
echo renderPagination($transactions, $paginationBase); 
?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
