<?php
require_once __DIR__ . '/../../includes/header.php';
auth()->requirePermission('sale.view_own');

$pageTitle = 'Sale Details';
$db = getDB();
$vendorId = auth()->getVendorId();
$isAdmin = auth()->isAdmin();
$id = intval($_GET['id'] ?? 0);

if (!$id) {
    setFlash('error', 'Invalid transaction ID.');
    redirect(APP_URL . '/modules/sales/index.php');
}

$transaction = $db->fetchOne(
    "SELECT st.*, v.business_name, v.stall_number FROM sales_transactions st LEFT JOIN vendors v ON st.vendor_id = v.id WHERE st.id = ?" . ($isAdmin ? '' : " AND st.vendor_id = {$vendorId}"),
    [$id]
);

if (!$transaction) {
    setFlash('error', 'Transaction not found.');
    redirect(APP_URL . '/modules/sales/index.php');
}

$items = $db->fetchAll(
    "SELECT ti.*, p.name as product_name, p.sku, p.unit FROM transaction_items ti JOIN products p ON ti.product_id = p.id WHERE ti.transaction_id = ?",
    [$id]
);
?>

<div class="max-w-5xl mx-auto">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-gray-800"><?php echo sanitize($transaction['transaction_number']); ?></h2>
            <p class="text-sm text-gray-500 mt-1">Sales transaction details and item breakdown.</p>
        </div>
        <div class="flex items-center gap-2">
            <a href="receipt.php?id=<?php echo $transaction['id']; ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('printer', 4, 'mr-2'); ?> Receipt
            </a>
            <a href="index.php" class="inline-flex items-center px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-medium transition touch-target">
                <?php echo icon('arrow-left', 4, 'mr-2'); ?> Back to Sales
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <p class="text-sm text-gray-500 mb-3">Customer & Payment</p>
            <div class="space-y-2 text-sm text-gray-700">
                <div><span class="font-medium">Customer:</span> <?php echo sanitize($transaction['customer_name'] ?: 'Walk-in'); ?></div>
                <div><span class="font-medium">Phone:</span> <?php echo sanitize($transaction['customer_phone'] ?: 'N/A'); ?></div>
                <div><span class="font-medium">Payment:</span> <?php echo ucfirst(str_replace('_', ' ', $transaction['payment_method'])); ?></div>
                <div><span class="font-medium">Status:</span> <?php echo statusBadge($transaction['status']); ?></div>
                <div><span class="font-medium">Date:</span> <?php echo formatDateTime($transaction['created_at']); ?></div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 xl:col-span-2">
            <p class="text-sm text-gray-500 mb-3">Vendor</p>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-700">
                <div>
                    <p class="font-medium"><?php echo sanitize($transaction['business_name'] ?? 'N/A'); ?></p>
                </div>
                <div>
                    <p class="font-medium"><?php echo sanitize($transaction['stall_number'] ?? 'N/A'); ?></p>
                </div>
                <div class="md:col-span-2">
                    <p class="text-gray-600"><?php echo sanitize($transaction['notes'] ?: 'No additional notes.'); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="table-wrapper">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="text-left py-3 px-4 font-medium text-gray-600">Item</th>
                        <th class="text-center py-3 px-4 font-medium text-gray-600">SKU</th>
                        <th class="text-center py-3 px-4 font-medium text-gray-600">Qty</th>
                        <th class="text-right py-3 px-4 font-medium text-gray-600">Price</th>
                        <th class="text-right py-3 px-4 font-medium text-gray-600">Total</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td class="py-3 px-4"><?php echo sanitize($item['product_name']); ?></td>
                        <td class="py-3 px-4 text-center text-gray-600"><?php echo sanitize($item['sku']); ?></td>
                        <td class="py-3 px-4 text-center"><?php echo $item['quantity']; ?></td>
                        <td class="py-3 px-4 text-right"><?php echo formatCurrency($item['unit_price']); ?></td>
                        <td class="py-3 px-4 text-right font-medium"><?php echo formatCurrency($item['total_amount']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($items)): ?>
                    <tr>
                        <td colspan="5" class="py-12 text-center text-gray-400">No items found for this transaction.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 text-sm text-gray-700">
        <div class="grid grid-cols-2 gap-4">
            <div>
                <p class="text-gray-500">Subtotal</p>
                <p class="font-medium text-gray-900"><?php echo formatCurrency($transaction['total_amount']); ?></p>
            </div>
            <div>
                <p class="text-gray-500">Tax</p>
                <p class="font-medium text-gray-900"><?php echo formatCurrency($transaction['tax_amount']); ?></p>
            </div>
            <div>
                <p class="text-gray-500">Discount</p>
                <p class="font-medium text-gray-900"><?php echo formatCurrency($transaction['discount']); ?></p>
            </div>
            <div>
                <p class="text-gray-500">Total Paid</p>
                <p class="text-xl font-bold text-emerald-600"><?php echo formatCurrency($transaction['net_amount']); ?></p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
