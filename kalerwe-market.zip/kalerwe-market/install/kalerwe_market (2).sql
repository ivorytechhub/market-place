-- XAMPP-Lite
-- version 8.5.5
-- https://xampplite.sf.net/
--
-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2026 at 03:22 PM
-- Server version: 11.4.10-MariaDB-log
-- PHP Version: 8.5.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kalerwe_market`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='System activity audit trail';

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `module`, `description`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 07:58:17'),
(2, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 07:58:31'),
(3, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 08:03:23'),
(4, 1, 'update', 'settings', 'Updated system settings', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 08:33:51'),
(5, 1, 'update', 'settings', 'Updated system settings', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 08:35:14'),
(6, 1, 'update', 'settings', 'Updated system settings', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 08:35:31'),
(7, 1, 'update', 'settings', 'Updated system settings', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 08:37:40'),
(8, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 08:43:23'),
(9, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 08:46:48'),
(10, 1, 'create', 'vendors', 'Created vendor: Emmanuel Niringiyimaana Maize Store (V0010)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:09:19'),
(11, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:20:40'),
(12, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:20:45'),
(13, 2, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:52:15'),
(14, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:52:19'),
(15, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:59:20'),
(16, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:59:24'),
(17, 2, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 09:59:32'),
(18, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:11:42'),
(19, 2, 'create', 'purchases', 'Created purchase order: PO-2026-CF4089', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:28:13'),
(20, 2, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:29:14'),
(21, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:29:17'),
(22, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:29:46'),
(23, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:29:52'),
(24, 2, 'update', 'purchases', 'Updated purchase order PO-2026-CF4089 status to received', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:46:02'),
(25, 2, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:46:28'),
(26, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:46:32'),
(27, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:57:02'),
(28, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:57:07'),
(29, 2, 'create', 'products', 'Added product: Maize', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 10:59:38'),
(30, 2, 'create', 'sales', 'Created sale: TXN-202671A509', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:01:27'),
(31, 2, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:20:53'),
(32, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:20:56'),
(33, 1, 'create', 'announcements', 'Created announcement: Weekly Meeting', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:22:29'),
(34, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:22:39'),
(35, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:22:43'),
(36, 2, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:23:33'),
(37, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 11:24:15'),
(38, 2, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 13:50:53'),
(39, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-18 13:50:55'),
(40, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-19 05:07:43'),
(41, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-19 06:44:50'),
(42, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-19 06:44:56'),
(43, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-19 09:08:59'),
(44, 1, 'logout', 'auth', 'User logged out', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-19 09:09:17'),
(45, 2, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-19 09:09:21'),
(46, 2, 'create', 'sales', 'Created sale: TXN-202691F5E7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-19 09:10:17'),
(47, 1, 'login', 'auth', 'User logged in successfully', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-26 13:46:39');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `is_active` tinyint(1) DEFAULT 1,
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Association announcements and notices';

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `priority`, `is_active`, `valid_from`, `valid_until`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'KCCA Market Cleaning Day', 'All vendors are reminded that the monthly market cleaning day is scheduled for this Sunday. Please ensure your stalls are cleared by 6:00 AM.', 'high', 1, '2024-01-15', '2024-01-21', 1, '2024-01-15 06:00:00', '2026-06-18 07:58:04'),
(2, 'Monthly Meeting', 'The monthly vendors meeting will be held on the 25th of this month at 2:00 PM in the association office. All members are required to attend.', 'urgent', 1, '2024-01-15', '2024-01-25', 1, '2024-01-15 06:30:00', '2026-06-18 07:58:04'),
(3, 'New Digital Payment System', 'We are introducing a new mobile money collection system for association dues. Please visit the office for registration.', 'normal', 1, '2024-01-10', '2024-02-10', 1, '2024-01-10 07:00:00', '2026-06-18 07:58:04'),
(4, 'Security Notice', 'All vendors are advised to secure their stalls properly. Recent incidents of theft have been reported. Contact security immediately if you notice suspicious activity.', 'urgent', 1, '2024-01-12', '2024-01-31', 1, '2024-01-12 11:00:00', '2026-06-18 07:58:04'),
(5, 'Holiday Schedule', 'The market will operate on reduced hours during the upcoming public holiday. Opening hours will be 6:00 AM to 2:00 PM.', 'normal', 1, '2024-01-20', '2024-01-26', 1, '2024-01-20 05:00:00', '2026-06-18 07:58:04'),
(6, 'Weekly Meeting', 'This is to inform you that we have a meeting on Sunday 21/06/2026. Everyone should attend in person', 'normal', 1, '2026-06-18', '2026-06-21', 1, '2026-06-18 11:22:29', '2026-06-18 11:22:29');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Product/business categories';

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `parent_id`, `is_active`, `created_at`) VALUES
(1, 'Fresh Produce', 'Fresh fruits and vegetables', NULL, 1, '2026-06-18 07:58:04'),
(2, 'Dry Goods', 'Grains, pulses, and dry food items', NULL, 1, '2026-06-18 07:58:04'),
(3, 'Meat & Fish', 'Fresh and processed meat and fish products', NULL, 1, '2026-06-18 07:58:04'),
(4, 'Spices & Herbs', 'Cooking spices, herbs, and flavorings', NULL, 1, '2026-06-18 07:58:04'),
(5, 'Cooking Oils & Fats', 'Vegetable oils, animal fats, and shortenings', NULL, 1, '2026-06-18 07:58:04'),
(6, 'Dairy Products', 'Milk, cheese, yogurt, and other dairy', NULL, 1, '2026-06-18 07:58:04'),
(7, 'Beverages', 'Soft drinks, water, and traditional drinks', NULL, 1, '2026-06-18 07:58:04'),
(8, 'Household Items', 'Cleaning supplies and household goods', NULL, 1, '2026-06-18 07:58:04'),
(9, 'Textiles & Clothing', 'Fabrics, clothes, and apparel', NULL, 1, '2026-06-18 07:58:04'),
(10, 'Electronics', 'Small electronics and accessories', NULL, 1, '2026-06-18 07:58:04'),
(11, 'Hardware & Tools', 'Building materials and hand tools', NULL, 1, '2026-06-18 07:58:04'),
(12, 'Cosmetics & Personal Care', 'Beauty and personal hygiene products', NULL, 1, '2026-06-18 07:58:04');

-- --------------------------------------------------------

--
-- Table structure for table `company_settings`
--

CREATE TABLE `company_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `association_name` varchar(200) NOT NULL DEFAULT 'Kalerwe Market Vendors Association',
  `tagline` varchar(200) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `currency_symbol` varchar(10) DEFAULT 'UGX',
  `currency_code` varchar(3) DEFAULT 'UGX',
  `tax_rate` decimal(5,2) DEFAULT 18.00,
  `registration_number` varchar(50) DEFAULT NULL,
  `kcca_license` varchar(50) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `receipt_footer` text DEFAULT NULL,
  `smtp_host` varchar(100) DEFAULT NULL,
  `smtp_port` int(11) DEFAULT 587,
  `smtp_username` varchar(100) DEFAULT NULL,
  `smtp_password` varchar(100) DEFAULT NULL,
  `smtp_encryption` varchar(10) DEFAULT 'tls',
  `timezone` varchar(50) DEFAULT 'Africa/Kampala',
  `date_format` varchar(20) DEFAULT 'd/m/Y',
  `time_format` varchar(20) DEFAULT 'H:i',
  `low_stock_threshold` int(11) DEFAULT 10,
  `session_timeout` int(11) DEFAULT 30,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Association settings and configuration';

--
-- Dumping data for table `company_settings`
--

INSERT INTO `company_settings` (`id`, `association_name`, `tagline`, `address`, `phone`, `email`, `website`, `currency_symbol`, `currency_code`, `tax_rate`, `registration_number`, `kcca_license`, `logo`, `receipt_footer`, `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `smtp_encryption`, `timezone`, `date_format`, `time_format`, `low_stock_threshold`, `session_timeout`, `created_at`, `updated_at`) VALUES
(1, 'Kalerwe Market Vendors', 'Unity, Progress & Prosperity', 'Gayaza Road, Kalerwe Market, Kampala, Uganda', '+256-414-000000', 'info@kalerwevendors.co.ug', '', 'UGX', 'UGX', 18.00, '', '', NULL, 'Thank you for supporting Kalerwe Market!\r\nKalerwe Market Vendors Association\r\nGayaza Road, Kampala\r\nTIN: 000000000', NULL, 587, NULL, NULL, 'tls', 'Africa/Kampala', 'd/m/Y', 'H:i', 10, 30, '2026-06-18 07:58:04', '2026-06-18 08:37:40');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `credit_limit` decimal(12,2) DEFAULT 0.00,
  `balance` decimal(12,2) DEFAULT 0.00,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Customers for order management';

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_number` varchar(30) NOT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','processing','ready','completed','cancelled') DEFAULT 'pending',
  `delivery_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Customer orders';

-- --------------------------------------------------------

--
-- Table structure for table `customer_order_items`
--

CREATE TABLE `customer_order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `item_description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Items in a customer order';

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL,
  `document_type` enum('kcca_permit','meeting_minutes','regulation','financial_report','other') DEFAULT 'other',
  `file_path` varchar(255) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `vendor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `uploaded_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Document management';

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `expense_number` varchar(30) NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `vendor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `expense_date` date NOT NULL,
  `receipt_reference` varchar(100) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Expense records';

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `expense_number`, `category_id`, `vendor_id`, `amount`, `description`, `expense_date`, `receipt_reference`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'EXP-20240001', 1, 1, 50000.00, 'January stall rent', '2024-01-01', NULL, NULL, '2024-01-01 07:00:00', '2026-06-18 07:58:04'),
(2, 'EXP-20240002', 7, 1, 10000.00, 'Monthly association dues', '2024-01-01', NULL, NULL, '2024-01-01 07:05:00', '2026-06-18 07:58:04'),
(3, 'EXP-20240003', 1, 2, 50000.00, 'January stall rent', '2024-01-01', NULL, NULL, '2024-01-01 07:10:00', '2026-06-18 07:58:04'),
(4, 'EXP-20240004', 3, 3, 15000.00, 'Water and electricity', '2024-01-05', NULL, NULL, '2024-01-05 06:00:00', '2026-06-18 07:58:04'),
(5, 'EXP-20240005', 4, 4, 25000.00, 'Transport for spice delivery', '2024-01-10', NULL, NULL, '2024-01-10 11:00:00', '2026-06-18 07:58:04'),
(6, 'EXP-20240006', 1, 5, 60000.00, 'January stall rent - larger unit', '2024-01-01', NULL, NULL, '2024-01-01 07:15:00', '2026-06-18 07:58:04'),
(7, 'EXP-20240007', 6, 6, 20000.00, 'Fridge repair', '2024-01-12', NULL, NULL, '2024-01-12 08:00:00', '2026-06-18 07:58:04'),
(8, 'EXP-20240008', 7, 7, 10000.00, 'Monthly association dues', '2024-01-01', NULL, NULL, '2024-01-01 07:20:00', '2026-06-18 07:58:04'),
(9, 'EXP-20240009', 3, 8, 12000.00, 'Electricity bill', '2024-01-08', NULL, NULL, '2024-01-08 13:00:00', '2026-06-18 07:58:04'),
(10, 'EXP-20240010', 2, 2, 8000.00, 'KCCA market levy', '2024-01-15', NULL, NULL, '2024-01-15 06:30:00', '2026-06-18 07:58:04');

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Expense category definitions';

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES
(1, 'Stall Rent', 'Monthly stall rental payments to KCCA', 1, '2026-06-18 07:58:04'),
(2, 'KCCA Market Dues', 'KCCA market fees and levies', 1, '2026-06-18 07:58:04'),
(3, 'Utilities', 'Water, electricity, and sanitation fees', 1, '2026-06-18 07:58:04'),
(4, 'Transport', 'Transportation costs for goods', 1, '2026-06-18 07:58:04'),
(5, 'Staff Wages', 'Salaries for hired help', 1, '2026-06-18 07:58:04'),
(6, 'Maintenance', 'Stall repairs and maintenance', 1, '2026-06-18 07:58:04'),
(7, 'Association Dues', 'Monthly association membership fees', 1, '2026-06-18 07:58:04'),
(8, 'Advertising', 'Marketing and promotional expenses', 1, '2026-06-18 07:58:04'),
(9, 'Miscellaneous', 'Other uncategorized expenses', 1, '2026-06-18 07:58:04');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_movements`
--

CREATE TABLE `inventory_movements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `movement_type` enum('sale','purchase','adjustment','return_in','return_out','transfer_in','transfer_out') NOT NULL,
  `quantity` int(11) NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` bigint(20) UNSIGNED DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stock movement history';

--
-- Dumping data for table `inventory_movements`
--

INSERT INTO `inventory_movements` (`id`, `product_id`, `variant_id`, `movement_type`, `quantity`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES
(1, 16, NULL, 'sale', -10, 'sale', 11, 'Sale transaction', 2, '2026-06-18 11:01:27'),
(2, 16, NULL, 'sale', -15, 'sale', 12, 'Sale transaction', 2, '2026-06-19 09:10:17');

-- --------------------------------------------------------

--
-- Table structure for table `member_contributions`
--

CREATE TABLE `member_contributions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `contribution_date` date NOT NULL,
  `payment_method` enum('cash','mobile_money','bank_transfer') DEFAULT 'cash',
  `receipt_number` varchar(30) DEFAULT NULL,
  `status` enum('pending','confirmed','rejected') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `recorded_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Member contribution/dues tracking';

--
-- Dumping data for table `member_contributions`
--

INSERT INTO `member_contributions` (`id`, `vendor_id`, `amount`, `contribution_date`, `payment_method`, `receipt_number`, `status`, `notes`, `recorded_by`, `created_at`) VALUES
(1, 1, 10000.00, '2024-01-01', 'cash', 'RCP-2024-001', 'confirmed', NULL, 1, '2024-01-01 05:00:00'),
(2, 2, 10000.00, '2024-01-01', 'mobile_money', 'RCP-2024-002', 'confirmed', NULL, 1, '2024-01-01 05:30:00'),
(3, 3, 10000.00, '2024-01-02', 'cash', 'RCP-2024-003', 'confirmed', NULL, 1, '2024-01-02 06:00:00'),
(4, 4, 10000.00, '2024-01-03', 'cash', 'RCP-2024-004', 'confirmed', NULL, 1, '2024-01-03 05:15:00'),
(5, 5, 10000.00, '2024-01-05', 'mobile_money', 'RCP-2024-005', 'confirmed', NULL, 1, '2024-01-05 07:00:00'),
(6, 6, 10000.00, '2024-01-08', 'cash', 'RCP-2024-006', 'confirmed', NULL, 1, '2024-01-08 06:30:00'),
(7, 7, 10000.00, '2024-01-10', 'bank_transfer', 'RCP-2024-007', 'confirmed', NULL, 1, '2024-01-10 08:00:00'),
(8, 8, 10000.00, '2024-01-12', 'cash', 'RCP-2024-008', 'confirmed', NULL, 1, '2024-01-12 05:45:00');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_number` varchar(30) NOT NULL,
  `reference_type` enum('sale','purchase','contribution','expense','customer_order') NOT NULL,
  `reference_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','mobile_money','bank_transfer') DEFAULT 'cash',
  `payment_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Payments received and made';

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sku` varchar(50) NOT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `cost_price` decimal(12,2) DEFAULT 0.00,
  `selling_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) DEFAULT 10.00,
  `quantity` int(11) DEFAULT 0,
  `min_stock_level` int(11) DEFAULT 10,
  `unit` enum('pieces','kg','liters','meters','boxes','bunches','bags','bundles') DEFAULT 'pieces',
  `has_variants` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Product catalog per vendor';

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `sku`, `barcode`, `name`, `description`, `vendor_id`, `category_id`, `cost_price`, `selling_price`, `tax_rate`, `quantity`, `min_stock_level`, `unit`, `has_variants`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'PRD001', '7600123456789', 'Matooke (Bunch)', 'Fresh green matooke bananas', 1, 1, 8000.00, 12000.00, 18.00, 50, 20, 'bunches', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(2, 'PRD002', '7600123456790', 'Sweet Potatoes', 'Orange sweet potatoes', 1, 1, 2000.00, 3500.00, 18.00, 100, 30, 'kg', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(3, 'PRD003', '7600123456791', 'Beans (Nambale)', 'Nambale beans, 1kg pack', 2, 2, 3000.00, 4500.00, 18.00, 200, 50, 'kg', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(4, 'PRD004', '7600123456792', 'Maize Flour', 'Super maize flour, 1kg', 2, 2, 2500.00, 3800.00, 18.00, 150, 40, 'kg', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(5, 'PRD005', '7600123456793', 'Beef Fresh', 'Fresh beef meat', 3, 3, 12000.00, 18000.00, 18.00, 30, 10, 'kg', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(6, 'PRD006', '7600123456794', 'Goat Meat', 'Fresh goat meat', 3, 3, 14000.00, 20000.00, 18.00, 20, 8, 'kg', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(7, 'PRD007', '7600123456795', 'Curry Powder', 'Mixed curry powder, 100g', 4, 4, 1500.00, 2500.00, 18.00, 80, 25, 'pieces', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(8, 'PRD008', '7600123456796', 'SimSim Paste', 'Ground simsim paste', 4, 4, 4000.00, 6000.00, 18.00, 40, 15, 'pieces', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(9, 'PRD009', '7600123456797', 'Phone Charger', 'Universal phone charger', 5, 10, 8000.00, 15000.00, 18.00, 25, 10, 'pieces', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(10, 'PRD010', '7600123456798', 'Earphones', 'Wired earphones', 5, 10, 5000.00, 10000.00, 18.00, 35, 15, 'pieces', 1, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(11, 'PRD011', '7600123456799', 'Fresh Milk', 'Fresh cow milk, 1 litre', 6, 6, 2000.00, 3000.00, 18.00, 60, 20, 'liters', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(12, 'PRD012', '7600123456800', 'Yogurt', 'Plain yogurt, 500ml', 6, 6, 1500.00, 2500.00, 18.00, 45, 15, 'pieces', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(13, 'PRD013', '7600123456801', 'Nails (4-inch)', 'Steel nails, 1kg pack', 7, 11, 6000.00, 9000.00, 18.00, 40, 15, 'kg', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(14, 'PRD014', '7600123456802', 'Hammer', 'Claw hammer', 7, 11, 15000.00, 25000.00, 18.00, 15, 5, 'pieces', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(15, 'PRD015', '7600123456803', 'Hair Oil', 'Natural hair oil, 200ml', 8, 12, 5000.00, 8500.00, 18.00, 30, 10, 'pieces', 0, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(16, 'Maize-0059', '0059028374', 'Maize', 'We sale maize', 9, 2, 2000.00, 3000.00, 18.00, 975, 10, 'kg', 0, 1, '2026-06-18 10:59:38', '2026-06-19 09:10:17');

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

CREATE TABLE `product_variants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_name` varchar(50) NOT NULL,
  `variant_value` varchar(50) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `cost_price` decimal(12,2) DEFAULT 0.00,
  `selling_price` decimal(12,2) DEFAULT 0.00,
  `quantity` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Product variants (size, color, etc.)';

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `po_number` varchar(30) NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `supplier_id` bigint(20) UNSIGNED NOT NULL,
  `po_date` date NOT NULL,
  `expected_delivery` date DEFAULT NULL,
  `status` enum('draft','sent','partial','received','cancelled') DEFAULT 'draft',
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) DEFAULT 0.00,
  `notification_channel` varchar(20) DEFAULT 'email',
  `notification_sent_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Purchase orders to suppliers';

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `po_number`, `vendor_id`, `supplier_id`, `po_date`, `expected_delivery`, `status`, `total_amount`, `tax_amount`, `notification_channel`, `notification_sent_at`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'PO-2026-CF4089', 9, 5, '2026-06-18', '2026-06-19', 'received', 2000000.00, 0.00, 'email', NULL, 'Purchase Order submitted', 2, '2026-06-18 10:28:13', '2026-06-18 10:46:02');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_items`
--

CREATE TABLE `purchase_order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `po_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `item_description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `received_qty` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Items in a purchase order';

--
-- Dumping data for table `purchase_order_items`
--

INSERT INTO `purchase_order_items` (`id`, `po_id`, `product_id`, `item_description`, `quantity`, `unit_price`, `total_amount`, `received_qty`) VALUES
(1, 1, NULL, 'Maize', 20, 100000.00, 2000000.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales_transactions`
--

CREATE TABLE `sales_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_number` varchar(30) NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) DEFAULT 0.00,
  `discount` decimal(12,2) DEFAULT 0.00,
  `net_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','mobile_money','bank_transfer') DEFAULT 'cash',
  `payment_status` enum('pending','partial','paid') DEFAULT 'paid',
  `amount_paid` decimal(12,2) DEFAULT 0.00,
  `status` enum('completed','refunded','cancelled') DEFAULT 'completed',
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Sales transactions';

--
-- Dumping data for table `sales_transactions`
--

INSERT INTO `sales_transactions` (`id`, `transaction_number`, `vendor_id`, `customer_name`, `customer_phone`, `total_amount`, `tax_amount`, `discount`, `net_amount`, `payment_method`, `payment_status`, `amount_paid`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'TXN-20240001', 1, 'Customer A', '+256700000001', 24000.00, 3661.02, 0.00, 24000.00, 'cash', 'paid', 24000.00, 'completed', NULL, NULL, '2024-01-15 05:30:00', '2026-06-18 07:58:04'),
(2, 'TXN-20240002', 1, 'Customer B', '+256700000002', 35000.00, 5338.98, 500.00, 35000.00, 'mobile_money', 'paid', 35000.00, 'completed', NULL, NULL, '2024-01-15 06:15:00', '2026-06-18 07:58:04'),
(3, 'TXN-20240003', 2, 'Customer C', NULL, 18000.00, 2745.76, 0.00, 18000.00, 'cash', 'paid', 18000.00, 'completed', NULL, NULL, '2024-01-15 07:00:00', '2026-06-18 07:58:04'),
(4, 'TXN-20240004', 3, 'Customer D', '+256700000004', 54000.00, 8237.29, 0.00, 54000.00, 'mobile_money', 'paid', 54000.00, 'completed', NULL, NULL, '2024-01-15 08:30:00', '2026-06-18 07:58:04'),
(5, 'TXN-20240005', 4, 'Customer E', NULL, 8500.00, 1296.61, 0.00, 8500.00, 'cash', 'paid', 8500.00, 'completed', NULL, NULL, '2024-01-15 09:00:00', '2026-06-18 07:58:04'),
(6, 'TXN-20240006', 1, 'Customer F', '+256700000006', 15500.00, 2364.41, 0.00, 15500.00, 'cash', 'paid', 15500.00, 'completed', NULL, NULL, '2024-01-16 05:45:00', '2026-06-18 07:58:04'),
(7, 'TXN-20240007', 5, 'Customer G', NULL, 30000.00, 4576.27, 0.00, 30000.00, 'mobile_money', 'paid', 30000.00, 'completed', NULL, NULL, '2024-01-16 06:30:00', '2026-06-18 07:58:04'),
(8, 'TXN-20240008', 6, 'Customer H', '+256700000008', 8500.00, 1296.61, 0.00, 8500.00, 'cash', 'paid', 8500.00, 'completed', NULL, NULL, '2024-01-16 07:15:00', '2026-06-18 07:58:04'),
(9, 'TXN-20240009', 2, 'Customer I', NULL, 22500.00, 3432.20, 0.00, 22500.00, 'cash', 'paid', 22500.00, 'completed', NULL, NULL, '2024-01-16 08:00:00', '2026-06-18 07:58:04'),
(10, 'TXN-20240010', 7, 'Customer J', '+256700000010', 34000.00, 5186.44, 0.00, 34000.00, 'bank_transfer', 'paid', 34000.00, 'completed', NULL, NULL, '2024-01-16 11:00:00', '2026-06-18 07:58:04'),
(11, 'TXN-202671A509', 9, 'Emma Loic', '+25670964538', 30000.00, 5400.00, 0.00, 35400.00, 'cash', 'paid', 35400.00, 'completed', 'Sold', 2, '2026-06-18 11:01:27', '2026-06-18 11:01:27'),
(12, 'TXN-202691F5E7', 9, 'Emma Loic', '+25670964538', 45000.00, 8100.00, 0.00, 53100.00, 'cash', 'paid', 53100.00, 'completed', '', 2, '2026-06-19 09:10:17', '2026-06-19 09:10:17');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `supplier_code` varchar(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `company_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT 'Uganda',
  `payment_terms` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Suppliers for purchase orders';

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_code`, `user_id`, `company_name`, `contact_person`, `phone`, `email`, `address`, `city`, `country`, `payment_terms`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'SUP001', NULL, 'Nakasero Suppliers Ltd', 'James Okello', '+256701111111', 'info@nakasero.co.ug', 'Nakasero Market', 'Kampala', 'Uganda', NULL, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(2, 'SUP002', NULL, 'Uganda Grain Millers', 'Patricia Auma', '+256702222222', 'orders@ugandagrain.co.ug', 'Industrial Area', 'Kampala', 'Uganda', NULL, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(3, 'SUP003', NULL, 'Fresh Farm Meats', 'Henry Musoke', '+256703333333', 'sales@freshfarm.co.ug', 'Wandegeya', 'Kampala', 'Uganda', NULL, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(4, 'SUP004', NULL, 'Spice World Importers', 'Fatima Ali', '+256704444444', 'info@spiceworld.co.ug', 'Kikuubo', 'Kampala', 'Uganda', NULL, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(5, 'SUP005', NULL, 'TechHub Distributors', 'Daniel Kigozi', '+256705555555', 'orders@techhub.co.ug', 'Nakawa', 'Kampala', 'Uganda', NULL, 1, '2026-06-18 07:58:04', '2026-06-18 07:58:04');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_items`
--

CREATE TABLE `transaction_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Individual items in a transaction';

--
-- Dumping data for table `transaction_items`
--

INSERT INTO `transaction_items` (`id`, `transaction_id`, `product_id`, `variant_id`, `quantity`, `unit_price`, `total_amount`) VALUES
(1, 1, 1, NULL, 2, 12000.00, 24000.00),
(2, 2, 2, NULL, 10, 3500.00, 35000.00),
(3, 3, 3, NULL, 5, 4500.00, 18000.00),
(4, 4, 5, NULL, 3, 18000.00, 54000.00),
(5, 5, 7, NULL, 2, 2500.00, 5000.00),
(6, 5, 8, NULL, 1, 6000.00, 6000.00),
(7, 6, 1, NULL, 1, 12000.00, 12000.00),
(8, 6, 2, NULL, 1, 3500.00, 3500.00),
(9, 7, 9, NULL, 2, 15000.00, 30000.00),
(10, 8, 11, NULL, 2, 3000.00, 6000.00),
(11, 8, 12, NULL, 1, 2500.00, 2500.00),
(12, 9, 4, NULL, 5, 3800.00, 19000.00),
(13, 9, 3, NULL, 1, 4500.00, 4500.00),
(14, 10, 13, NULL, 3, 9000.00, 27000.00),
(15, 10, 14, NULL, 1, 25000.00, 25000.00),
(16, 11, 16, NULL, 10, 3000.00, 30000.00),
(17, 12, 16, NULL, 15, 3000.00, 45000.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('admin','vendor','supplier','buyer','cashier') DEFAULT 'vendor',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='System users with role-based access';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `phone`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@kalerwe.co.ug', '+256700000001', 'admin', 1, '2026-06-26 16:46:39', '2026-06-18 07:58:04', '2026-06-26 13:46:39'),
(2, 'eniringiyimaana', '$2y$12$tznJZotO6RA/p0ZuF6gCnOptzjQb/0AkhVZ.7VpJi3QYRt6xSXs1S', 'Emmanuel Niringiyimaana', 'emmanuelniringiyimaana@kalerwevendors.co.ug', '+256-414-096000', 'vendor', 1, '2026-06-19 12:09:21', '2026-06-18 09:09:19', '2026-06-19 09:09:21');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_code` varchar(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `stall_number` varchar(30) NOT NULL,
  `stall_location` varchar(100) DEFAULT NULL,
  `business_name` varchar(100) NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `business_description` text DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `kcca_permit_number` varchar(50) DEFAULT NULL,
  `kcca_permit_expiry` date DEFAULT NULL,
  `date_joined` date NOT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `profile_photo` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Market vendors/members';

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `vendor_code`, `user_id`, `stall_number`, `stall_location`, `business_name`, `category_id`, `business_description`, `contact_person`, `contact_phone`, `contact_email`, `kcca_permit_number`, `kcca_permit_expiry`, `date_joined`, `status`, `profile_photo`, `notes`, `created_at`, `updated_at`) VALUES
(1, 'V001', NULL, 'A-12', 'Block A, Row 1', 'Mukasa Fresh Produce', 1, NULL, 'John Mukasa', '+256701234567', NULL, NULL, NULL, '2023-01-15', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(2, 'V002', NULL, 'B-05', 'Block B, Row 2', 'Nakato Grain Supplies', 2, NULL, 'Mary Nakato', '+256702345678', NULL, NULL, NULL, '2023-02-20', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(3, 'V003', NULL, 'C-08', 'Block C, Row 1', 'Kato Meat Centre', 3, NULL, 'Peter Kato', '+256703456789', NULL, NULL, NULL, '2023-03-10', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(4, 'V004', NULL, 'A-25', 'Block A, Row 3', 'Amina Spice World', 4, NULL, 'Amina Hassan', '+256704567890', NULL, NULL, NULL, '2023-04-05', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(5, 'V005', NULL, 'D-15', 'Block D, Row 2', 'Otim Electronics', 10, NULL, 'David Otim', '+256705678901', NULL, NULL, NULL, '2023-05-12', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(6, 'V006', NULL, 'B-18', 'Block B, Row 3', 'Nambi Dairy Products', 6, NULL, 'Sarah Nambi', '+256706789012', NULL, NULL, NULL, '2023-06-18', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(7, 'V007', NULL, 'C-22', 'Block C, Row 3', 'Ssemanda Hardware', 11, NULL, 'Robert Ssemanda', '+256707890123', NULL, NULL, NULL, '2023-07-22', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(8, 'V008', NULL, 'A-30', 'Block A, Row 4', 'Namuli Beauty Shop', 12, NULL, 'Grace Namuli', '+256708901234', NULL, NULL, NULL, '2023-08-30', 'active', NULL, NULL, '2026-06-18 07:58:04', '2026-06-18 07:58:04'),
(9, 'V0010', 2, 'A-23', 'Block A, Row 3', 'Emmanuel Niringiyimaana Maize Store', 2, 'I Sell Dry Maize', 'Emmanuel Niringiyimaana', '+256-414-096000', 'emmanuelniringiyimaana@kalerwevendors.co.ug', '006864', '2030-06-18', '2026-06-18', 'active', NULL, 'I Sell Dry Maize', '2026-06-18 09:09:19', '2026-06-18 09:09:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_module` (`module`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_priority` (`priority`),
  ADD KEY `idx_is_active` (`is_active`),
  ADD KEY `idx_valid_dates` (`valid_from`,`valid_until`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `idx_name` (`name`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `company_settings`
--
ALTER TABLE `company_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_phone` (`phone`),
  ADD KEY `idx_name` (`full_name`);

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_order_number` (`order_number`),
  ADD KEY `idx_customer` (`customer_id`),
  ADD KEY `idx_vendor` (`vendor_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `customer_order_items`
--
ALTER TABLE `customer_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_order` (`order_id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploaded_by` (`uploaded_by`),
  ADD KEY `idx_document_type` (`document_type`),
  ADD KEY `idx_vendor` (`vendor_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `expense_number` (`expense_number`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_expense_number` (`expense_number`),
  ADD KEY `idx_category` (`category_id`),
  ADD KEY `idx_vendor` (`vendor_id`),
  ADD KEY `idx_expense_date` (`expense_date`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_name` (`name`);

--
-- Indexes for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `variant_id` (`variant_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_product` (`product_id`),
  ADD KEY `idx_movement_type` (`movement_type`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_reference` (`reference_type`,`reference_id`);

--
-- Indexes for table `member_contributions`
--
ALTER TABLE `member_contributions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recorded_by` (`recorded_by`),
  ADD KEY `idx_vendor` (`vendor_id`),
  ADD KEY `idx_contribution_date` (`contribution_date`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_number` (`payment_number`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_payment_number` (`payment_number`),
  ADD KEY `idx_reference` (`reference_type`,`reference_id`),
  ADD KEY `idx_vendor` (`vendor_id`),
  ADD KEY `idx_payment_date` (`payment_date`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_vendor_sku` (`vendor_id`,`sku`),
  ADD KEY `idx_barcode` (`barcode`),
  ADD KEY `idx_name` (`name`),
  ADD KEY `idx_is_active` (`is_active`),
  ADD KEY `idx_quantity` (`quantity`),
  ADD KEY `idx_category` (`category_id`);

--
-- Indexes for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product` (`product_id`),
  ADD KEY `idx_sku` (`sku`),
  ADD KEY `idx_barcode` (`barcode`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `po_number` (`po_number`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_po_number` (`po_number`),
  ADD KEY `idx_vendor` (`vendor_id`),
  ADD KEY `idx_supplier` (`supplier_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_po_date` (`po_date`);

--
-- Indexes for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_po` (`po_id`);

--
-- Indexes for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_number` (`transaction_number`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_transaction_number` (`transaction_number`),
  ADD KEY `idx_vendor` (`vendor_id`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_payment_status` (`payment_status`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `supplier_code` (`supplier_code`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_supplier_code` (`supplier_code`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `variant_id` (`variant_id`),
  ADD KEY `idx_transaction` (`transaction_id`),
  ADD KEY `idx_product` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vendor_code` (`vendor_code`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_vendor_code` (`vendor_code`),
  ADD KEY `idx_stall_number` (`stall_number`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_category` (`category_id`),
  ADD KEY `idx_date_joined` (`date_joined`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `company_settings`
--
ALTER TABLE `company_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_order_items`
--
ALTER TABLE `customer_order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `member_contributions`
--
ALTER TABLE `member_contributions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction_items`
--
ALTER TABLE `transaction_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD CONSTRAINT `customer_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `customer_orders_ibfk_2` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `customer_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `customer_order_items`
--
ALTER TABLE `customer_order_items`
  ADD CONSTRAINT `customer_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `customer_orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `customer_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `expense_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `expenses_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  ADD CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `inventory_movements_ibfk_2` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `inventory_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `member_contributions`
--
ALTER TABLE `member_contributions`
  ADD CONSTRAINT `member_contributions_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_contributions_ibfk_2` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD CONSTRAINT `product_variants_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `purchase_orders_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  ADD CONSTRAINT `purchase_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  ADD CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  ADD CONSTRAINT `sales_transactions_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_transactions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD CONSTRAINT `suppliers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD CONSTRAINT `transaction_items_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `sales_transactions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaction_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `transaction_items_ibfk_3` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `vendors`
--
ALTER TABLE `vendors`
  ADD CONSTRAINT `vendors_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
